import "./App.css";
import "./assets/css/custom.css";
import { Route, Routes, Navigate } from "react-router-dom";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";

import LoginPage from "./pages/Auth/Login/LoginPage";
import Signup from "./pages/Auth/SignUp";
import SelectCategory from "./pages/Auth/SelectCategory/SelectCategory";
import OTPVerificationPage from "./pages/Auth/OTPVerification/OTPVerificationPage";
import CongratulationsPage from "./pages/Auth/OTPVerificationResult/CongratulationsPage";

import ResetPasswordPage from "./pages/Auth/Reset/ResetPasswordPage";
import ResetPasswordConfirmPage from "./pages/Auth/Reset/ResetPasswordConfirmPage";
import ResetPasswordOTPPage from "./pages/Auth/Reset/ResetPasswordOTPPage";
import GetVai from "./pages/VAI Module/GetVai";
import Terms from "./pages/VAI Module/Terms";
import Subscription from "./pages/VAI Module/Subscription";
import DiscountCoupon from "./pages/VAI Module/DiscountCoupon";
import Payment from "./pages/VAI Module/Payment";
import PaymentSuccess from "./pages/VAI Module/PaymentSuccess";
import Migration from "./pages/VAI Module/Migration";
import BussinessVai from "./pages/VAI Module/BussinessVai";
import VaiCodes from "./pages/VAI Module/VaiCodes";
import AgencyBusiness from "./pages/Auth/BusinessService/AgencyBusiness";
import MyVairipay from "./pages/MyVairipay/MyVairipay";
import MyVairipayAdd from "./pages/MyVairipay/MyVairipayAdd";
import BusinessProfileQRCode from "./pages/MyVairipay/MyVairipayQR";
import MyVairipayRequest from "./pages/MyVairipay/MyVairipayRequest";
import MyVairipayRequestSecond from "./pages/MyVairipay/MyVairipayRequestSecond";
import MyVairipayAppleRequestQR from "./pages/MyVairipay/MyVairipayAppleRequestQR";
import MyVairipayRequestConfirm from "./pages/MyVairipay/MyVairipayRequestConfirm";
import MyVairipaySearch from "./pages/MyVairipay/MyVairipaySearch";
import MyVairipayCountrySearch from "./pages/MyVairipay/MyVairipayCountrySearch";
import Language from "./pages/Setup/Language";
import GoldenToken from "./pages/Setup/Varipay/GoldenToken";
import TokenCheckout from "./pages/Setup/Varipay/TokenCheckout";
import TokenCongratulation from "./pages/Setup/Varipay/TokenCongratulation";
import UserProfile from "./pages/User/UserProfile";
import PersonalInformationOrientation from "./pages/PersonalInformationOrientation/PersonalInformationOrientation";
import Services from "./pages/Setup/Services/Home";
import Massage from "./components/Services/Massage";
import HotRod from "./pages/User/HotRod";
import Varipay from "./pages/Setup/Varipay/Varipay";
import ServiceExtra from "./pages/Setup/Services/ServiceExtra";
import HourlyRates from "./pages/Setup/Services/HourlyRates";
import SetupProfile from "./pages/Setup/SetupProfile";
import MutalConsent from "./pages/Setup/MutalConsent";
import Gallery from "./pages/Setup/Gallery";
import DateGuardSetup from "./pages/Setup/Dateguard/DateGuardSetup";
import Codes from "./pages/Setup/Dateguard/Codes";
import Groups from "./pages/Setup/Dateguard/Groups";
import DateGuardSelectGroup from './pages/Setup/Dateguard/DateGuardSelectGroup';
import DateGuardEditGroup from './pages/Setup/Dateguard/DateGuardEditGroup';
import DateGuardAddMember from './pages/Setup/Dateguard/DateGuardAddMember';
import InviteMemberToGroup from './pages/Setup/Dateguard/InviteMemberToGroup';
import DateGuardPasswordInput from './pages/Setup/Dateguard/DateGuardPasswordInput';
import PasswordSuccessChanged from './pages/Setup/Dateguard/PasswordSuccessChanged';
import DateGuardInvitedMembers from './pages/Setup/Dateguard/InviteMemberToGroup';
import DateGuardCountUp from './pages/Setup/Dateguard/DateGuardCountUp';
import DateGuardPhotoTake from './pages/Setup/Dateguard/DateGuardPhotoTake';
import DateGuardSendMessage from './pages/Setup/Dateguard/DateGuardSendMessage';
import DateGuardAlarm from './pages/Setup/Dateguard/DateGuardAlarm';
import SuccessChangedCode from './pages/Setup/Dateguard/SuccessChangedCode'
import DateGuardSetTimeAlarm from './pages/Setup/Dateguard/DateGuardSetTimeAlarm'
import JoinMemberToGroup from './pages/Setup/Dateguard/JoinMemberToGroup'
import SocialSearch from "./pages/Setup/Social/SocialSearch";
import AddSocial from "./pages/Setup/Social/AddSocial";
import UploadProfile from "./pages/Setup/UploadProfile";
import UserGallery from "./pages/User/UserGallery";
import GalleryComment from "./pages/User/GalleryComment";
import SetupFacial from "./pages/Setup/InAppFacialRec/SetupFacial";
import UploadFacial from "./pages/Setup/InAppFacialRec/UploadFacial";
import ActiveInvitation from "./pages/Setup/Marketplace/ActiveInvitations";
import PostReview from "./pages/Setup/Marketplace/PostReview";
import PostAnnouncement from "./pages/Setup/Marketplace/PostAnnouncement";
import MarketplacePosts from "./pages/Setup/Marketplace/MarketplacePosts";
import SetDateGuardDisarmDecoyCode from "./pages/Setup/Dateguard/SetDateGuardDisarmDecoyCode";
import MyCalendar from "./pages/Setup/Marketplace/MyCalendar";
import CalendarSchedules from "./pages/Setup/Calendar/Calendar";
import Schedule from "./pages/Setup/Calendar/Schedule";
import SetSchedule from "./pages/Setup/Calendar/SetSchedule";
import SetRules from "./pages/Setup/Calendar/SetRules";
import CalendarSetting from "./pages/Setup/Calendar/CalendarSetting";
import SyncCalendar from "./pages/Setup/Calendar/SyncCalendar";
import EscortType from "./pages/Setup/Marketplace/EscortType";
import EscortResults from "./pages/Setup/Marketplace/EscortResults";
import AdvancedSearch from "./pages/Setup/Marketplace/AdvancedSearch";
import VerifyMarketplace from "./pages/Setup/Marketplace/VerifyMarketplace";
import Invite from "./pages/Setup/Marketplace/Invite";
import Invitations from "./pages/Setup/Marketplace/Invitations";
import Featured from "./pages/Setup/Home/Featured";
import Comments from "./pages/Setup/Home/Comments";
import PostDetails from "./pages/Setup/Home/PostDetails";

function App() {
  const stripePromise = loadStripe(
    `${import.meta.env.VITE_APP_STRIPE_CLIENT_KEY}`
  );

  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Navigate to="/login" />}></Route>
        <Route path="/login" element={<LoginPage />}></Route>
        <Route path="/selectcategory" element={<SelectCategory />}></Route>
        <Route path="/signup" element={<Signup />}></Route>
        <Route
          path="/otp-verification"
          element={<OTPVerificationPage />}
        ></Route>
        <Route
          path="/otp-congratulations"
          element={<CongratulationsPage />}
        ></Route>
        <Route path="/reset-password" element={<ResetPasswordPage />}></Route>
        <Route
          path="/reset-password-otp"
          element={<ResetPasswordOTPPage />}
        ></Route>
        <Route element={<ResetPasswordConfirmPage />}></Route>
        <Route path="/agencybusiness" element={<AgencyBusiness />}></Route>
        {/* VAI MODULE STATRS HERE */}
        <Route path="/get-vai" element={<GetVai />}></Route>
        <Route path="/terms" element={<Terms />}></Route>
        <Route path="/subscription" element={<Subscription />}></Route>
        <Route path="/discount-coupon" element={<DiscountCoupon />}></Route>
        <Route path="/migration" element={<Migration />}></Route>
        <Route
          path="/payment"
          element={
            <Elements stripe={stripePromise}>
              <Payment />
            </Elements>
          }
        ></Route>
        <Route path="/payment-success" element={<PaymentSuccess />}></Route>
        <Route path="/bussiness-vai" element={<BussinessVai />}></Route>{" "}
        <Route path="/bussiness-vai-codes" element={<VaiCodes />}></Route>{" "}
        {/* VAI MODULE ENDS HERE */}
        {/*Vairipay*/}
        <Route path="/user/profile" element={<UserProfile />}></Route>
        <Route path="/my-vairipay" element={<MyVairipay />}></Route>
        <Route path="/vairipay-add" element={<MyVairipayAdd />}></Route>
        <Route path="/vairipay-qr" element={<BusinessProfileQRCode />}></Route>
        <Route path="/vairipay-request" element={<MyVairipayRequest />}></Route>
        <Route
          path="/user/my-vairipay-request-second"
          element={<MyVairipayRequestSecond />}
        ></Route>
        <Route
          path="/my-vairipay-apple-request-qr"
          element={<MyVairipayAppleRequestQR />}
        ></Route>
        <Route
          path="/user/my-vairipay-request-confirm"
          element={<MyVairipayRequestConfirm />}
        ></Route>
        <Route
          path="/vairipay-options"
          element={<MyVairipayRequestSecond />}
        ></Route>
        <Route path="/vairipay-search" element={<MyVairipaySearch />}></Route>
        <Route
          path="/my-vairipay-country-search"
          element={<MyVairipayCountrySearch />}
        ></Route>
        {/*Vairipay Ends*/}
        {/* setup starts from here */}
        <Route path="/setup" element={<SetupProfile />}></Route>
        <Route path="/language" element={<Language />}></Route>
        <Route path="/goldentoken" element={<GoldenToken />}></Route>
        <Route
          path="/grt-checkout"
          element={
            <Elements stripe={stripePromise}>
              <TokenCheckout />
            </Elements>
          }
        ></Route>
        <Route
          path="/grt-congratulation"
          element={<TokenCongratulation />}
        ></Route>
        <Route
          path="/personal-information"
          element={<PersonalInformationOrientation />}
        ></Route>
        <Route path="/mutalconsent" element={<MutalConsent />}></Route>
        <Route path="/photogallery" element={<Gallery />}></Route>
        <Route path="/uploadProfile" element={<UploadProfile />}></Route>
        <Route path="/search-social" element={<SocialSearch />}></Route>
        <Route path="/add-social" element={<AddSocial />}></Route>
        <Route path="/setup-facial" element={<SetupFacial />}></Route>
        <Route path="/facial-recognition" element={<UploadFacial />}></Route>

       

        {/* services */}
        <Route path="/services" element={<Services />}></Route>
        <Route path="/services/massage" element={<Massage />}></Route>
        <Route path="/service/extras" element={<ServiceExtra />}></Route>
        <Route path="/hourly-rates" element={<HourlyRates />}></Route>
        {/* Market */}
        <Route path="/verify-marketplace" element={<VerifyMarketplace />}></Route>
        <Route path="/escort-type" element={<EscortType />}></Route>
        <Route path="/escort-results" element={<EscortResults />}></Route>
        <Route path="/advance/search" element={<AdvancedSearch />}></Route>

        <Route path="/invitations" element={<Invitations />}></Route>
        <Route path="/active-invitation" element={<ActiveInvitation />}></Route>
        <Route path="/myinvitation" element={<Invite />}></Route>

        <Route path='/post' element={<PostAnnouncement />}></Route>
        <Route path='/marketplace-post' element={<MarketplacePosts />}></Route>
        <Route path='/marketplace/post/review' element={<PostReview />}></Route>
        <Route path='/my-calendar' element={<MyCalendar />}></Route>
        {/* Home page */}
        <Route path="/featured" element={<Featured />}></Route>
        <Route path='/user/details' element={<PostDetails />}></Route>
        <Route path='/user/comments' element={<Comments />}></Route>


        {/*calendar*/}
        <Route path='/calendar' element={<CalendarSchedules />}></Route>
        <Route path="/schedule" element={<Schedule />}></Route>
        <Route path="/set-schedule" element={<SetSchedule />}></Route>
        <Route path="/set-rules" element={<SetRules />}></Route>
        <Route path='/sync-calendar' element={<SyncCalendar />}></Route>
        <Route path='/cal-setting' element={<CalendarSetting />}></Route>

        {/*Profile Request*/}
        <Route path="/setup-varipay" element={<Varipay />}></Route>
        <Route path="/user/profile/request" element={<HotRod />}></Route>
        {/* User */}
        <Route path="/user/gallery" element={<UserGallery />}></Route>
        <Route path="/user/gallerycomment" element={<GalleryComment />}></Route>
        {/*dateguard*/}
        <Route path="/dateguard-setup" element={<DateGuardSetup />}></Route>
        <Route path="/dateguard/codes" element={<Codes />}></Route>
        <Route path="/dateguard/groups" element={<Groups />}></Route>
        <Route path='/dateguard/set-code' element={<SetDateGuardDisarmDecoyCode />}></Route>
        <Route path='/dateguard/success-code-changed' element={<SuccessChangedCode />}></Route>
        <Route path='/dateguard/password-input' element={<DateGuardPasswordInput />}></Route>
        <Route path='/dateguard/password-success-changed' element={<PasswordSuccessChanged />}></Route>
        <Route path='/dateguard/select-group' element={<DateGuardSelectGroup />}></Route>
        <Route path='/dateguard/edit-group' element={<DateGuardEditGroup />}></Route>
        <Route path='/dateguard/add-member' element={<DateGuardAddMember />}></Route>

        <Route path='/dateguard/invite-member' element={<InviteMemberToGroup />}></Route>

        <Route path='/dateguard/join-member-to-group' element={<JoinMemberToGroup />}></Route>
        
        <Route path='/dateguard/invited-members' element={<DateGuardInvitedMembers />}></Route>
        <Route path='/dateguard/set-time-alarm' element={<DateGuardSetTimeAlarm />}></Route>
        <Route path='/dateguard/count-up' element={<DateGuardCountUp />}></Route>
        <Route path='/dateguard/photo-take' element={<DateGuardPhotoTake />}></Route>
        <Route path='/dateguard/send-message' element={<DateGuardSendMessage />}></Route>
        <Route path='/dateguard/alarm' element={<DateGuardAlarm />}></Route>
      </Routes>
    </div>
  );
}

export default App;
