import React from 'react';

const SelectBox_ = ({ className, options, onChange, borderWidth, arrowColor, iconColor, customization, className2, setRules, value }) => {
    return (
        <select onChange={onChange} value={value} className={`bg-transparent rounded-full ${className}`}>
            {options.map(option => (
                <option key={option} value={option}>
                    {option}
                </option>
            ))}
        </select>
    );
};

export default SelectBox_;
