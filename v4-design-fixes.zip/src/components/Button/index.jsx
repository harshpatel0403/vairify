function Button({
  id,
  text,
  onClick,
  className,
  size,
  bgColor,
  itemsStart,
  disabled,
}) {
  console.log("🚀 ~ file: index.jsx:2 ~ Button ~ size:", size);
  return (
    <button
      id={id}
      className={`bg-gradient-to-b w-full rounded-2xl text-center shadow-2xl ${
        className ? className : ""
      } ${size ? `h-[${size}]` : "h-[50px] hover:bg-blue-700"}  ${
        bgColor ? `bg-${bgColor}` : "bg-[#05B7FD]"
      } ${itemsStart == "true" ? "items-start" : "items-center"}`}
      onClick={onClick}
      style={{ height: size ? `${size}` : "" }}
      disabled={disabled && disabled}
    >
      {text}
    </button>
  );
}

export default Button;
