import axios from "axios";
import BaseAPI from "../../BaseAPI";

export const HandleCreateMarketPlace = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/market/create`,
        data
      );
      return dispatch({
        type: "CREATE_MARKETPLACE",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleEditMarketPlace = (id, data) => {
  return async (dispatch) => {
    try {
      const response = await axios.put(
        `${BaseAPI}/api/v1/market/edit/${id}`,
        data
      );
      return dispatch({
        type: "CREATE_MARKETPLACE",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleResultMarketPlace = (id, status) => {
  return async (dispatch) => {
    try {
      const apiUrl = status
        ? `${BaseAPI}/api/v1/market/get/${id}?status=${status}`
        : `${BaseAPI}/api/v1/market/get/${id}`;

      const response = await axios.get(apiUrl);
      return dispatch({
        type: "RESULT_MARKETPLACE",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleGetMarketPlace = (data, inquiry) => {
  return async (dispatch) => {
    try {
      // Check if 'inquiry' is defined before including it in the URL
      const apiUrl = inquiry
        ? `${BaseAPI}/api/v1/market/get-market/${data}?inquiry=${inquiry}`
        : `${BaseAPI}/api/v1/market/get-market/${data}`;

      const response = await axios.get(apiUrl);

      return dispatch({
        type: "GET_MARKETPLACE",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleInvitation = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/market/invitation`,
        data
      );
      return dispatch({
        type: "SEND_INVITATION",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleDeleteInvitation = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.delete(
        `${BaseAPI}/api/v1/market/delete/${data}`
      );
      return dispatch({
        type: "DELETE_INVITATION",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleMyInvitation = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(
        `${BaseAPI}/api/v1/market/invitation/${data}`
      );
      return dispatch({
        type: "MY_INVITATION",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleCreateNewPost = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/market/post/create`,
        data
      );
      return dispatch({
        type: "CREATE_POST",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleGetNewPost = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(
        `${BaseAPI}/api/v1/market/post/get/${data}`
      );
      return dispatch({
        type: "GET_POST",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleDeletePost = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.delete(
        `${BaseAPI}/api/v1/market/post/delete/${data}`
      );
      return dispatch({
        type: "DELETE_POST",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleGetAllPost = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${BaseAPI}/api/v1/market/post/getallpost`);
      return dispatch({
        type: "GETALL_POST",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleCommentsPost = (postId, data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(`${BaseAPI}/api/v1/market/post/comment/${postId}`, data);
      return dispatch({
        type: "CREATE_POST_COMMENT",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleLikePost = (postId, data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(`${BaseAPI}/api/v1/market/post/like/${postId}`, data);
      return dispatch({
        type: "CREATE_POST_LIKE",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleGetCommentsPost = (postId) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${BaseAPI}/api/v1/market/post/get/comment/${postId}`);
      return dispatch({
        type: "GETALL_POST_COMMENT",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};