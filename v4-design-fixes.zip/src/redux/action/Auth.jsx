import axios from "axios";
import BaseAPI from "../../BaseAPI";
console.log("🚀 ~ file: Auth.jsx:3 ~ BaseAPI:", BaseAPI);

export const HandleSignUp = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(`${BaseAPI}/api/v1/users/create`, data);
      return dispatch({
        type: "CREATE_USER",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleLogIn = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(`${BaseAPI}/api/v1/users/login`, data);
      localStorage.setItem("authorization", response.data.token);
      return dispatch({
        type: "LOGIN",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleUser = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${BaseAPI}/api/v1/users/user/${data}`);
      localStorage.setItem("authorization", response.data.token);
      return dispatch({
        type: "LOGIN",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const SendOTP = (data) => {
  console.log("🚀 ~ file: Auth.jsx:43 ~ SendOTP ~ data:", data);
  return async (dispatch) => {
    try {
      const response = await axios.post(`${BaseAPI}/api/v1/users/sendOtpCode`, {
        email: data,
      });
      response.email = data;
      return dispatch({
        type: "SEND_OTP",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const VerifyOTP = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/users/verifyOtpCode`,
        data
      );
      return dispatch({
        type: "VERIFY_OTP",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const ResetPassword = (data) => {
  console.log(data, "datasdkfhkl");
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/users/forgotpassword`,
        { email: data?.email }
      );
      return dispatch({
        type: "RESET_PASSWORD",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const VerifyResetPassword = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/users/verifypassword`,
        data
      );
      return dispatch({
        type: "VERIFY_RESET_PASSWORD",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};

export const HandleLanguage = (data) => {
  return async (dispatch) => {
    try {
      return dispatch({
        type: "LANGUAGE_STATE",
        payload: data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleCountry = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${BaseAPI}/api/v1/country/all`);
      return dispatch({
        type: "GET_COUNTRY",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
