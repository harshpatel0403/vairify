import axios from "axios";
import BaseAPI from "../../BaseAPI";

export const HandleProfile = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/profile/create`,
        data
      );
      return dispatch({
        type: "CREATE_PROFILE",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleGetProfile = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.get(
        `${BaseAPI}/api/v1/profile/get-profile/${data}`,
        data
      );
      return dispatch({
        type: "GET_PROFILE",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
