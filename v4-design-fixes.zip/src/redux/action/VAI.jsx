import axios from "axios";
import BaseAPI from "../../BaseAPI";
console.log("🚀 ~ file: Auth.jsx:3 ~ BaseAPI:", BaseAPI);

export const HandleDiscountCoupon = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/coupons/apply-coupon`,
        data
      );
      return dispatch({
        type: "DISCOUNT_COUPON",
        payload: response.data,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
export const HandleGenerateCoupon = (data) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(
        `${BaseAPI}/api/v1/coupons/generate-coupons`,
        data
      );
      return dispatch({
        type: "GENERATE_COUPON",
        payload: response,
      });
    } catch (err) {
      return dispatch({
        type: "SET_LOADING",
        payload: err.response,
      });
    }
  };
};
