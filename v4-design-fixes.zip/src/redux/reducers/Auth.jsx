const initialState = {
  SignUp: {},
  Auth: {},
  OTPEmail: {},
  ResetPassword: {},
  language: {},
  country: [],
};

export const HandleAuth = (state = initialState, action) => {
  switch (action.type) {
    case "CREATE_USER":
      return {
        ...state,
        SignUp: action.payload,
      };
    case "LOGIN":
      return {
        ...state,
        Auth: action.payload,
      };
    case "SEND_OTP":
      return {
        ...state,
        OTPEmail: action.payload?.email,
      };
    case "RESET_PASSWORD":
      return {
        ...state,
        ResetPassword: action.payload,
      };
    case "LANGUAGE_STATE":
      return {
        ...state,
        language: action.payload,
      };
    case "GET_COUNTRY":
      return {
        ...state,
        country: action.payload,
      };

    case "SET_LOADING":
      return { ...state, error: action?.payload?.response };

    default:
      return state;
      break;
  }
};
