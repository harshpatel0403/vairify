const initialState = {
  discountCoupon: {},
  error: {},
  geberateCoupon: {},
};

export const HandleVAI = (state = initialState, action) => {
  switch (action.type) {
    case "DISCOUNT_COUPON":
      return {
        ...state,
        discountCoupon: action.payload,
      };
    case "GENERATE_COUPON":
      return {
        ...state,
        geberateCoupon: action.payload?.data,
      };
    case "SET_LOADING":
      return { ...state, error: action?.payload?.response };

    default:
      return state;
      break;
  }
};
