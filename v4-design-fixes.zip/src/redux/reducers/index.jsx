import { combineReducers } from "redux";
import { TotalVairipay } from "./vairipay";
import { HandleAuth } from "./Auth";
import { HandleVAI } from "./VAI";
import { HandleServices } from "./Services";
import { HandleAdvanceServices } from "./AdvancedSearch.JSX";
import { HandleMarketplace } from "./MarketplaceSearch";

const reducer = combineReducers({
  TotalVairipay: TotalVairipay,
  Auth: HandleAuth,
  Vai: HandleVAI,
  Services: HandleServices,
  AdvanceServices: HandleAdvanceServices,
  Market: HandleMarketplace,
});

export default reducer;
