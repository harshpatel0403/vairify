const initialState = {
  error: {},
  marketplace: {},
  marketplacedata: [],
  results: [],
  sendInvitation: [],
  deleteInvitation: {},
  myInvitation: [],
  getpost: [],
  getAllPost: [],
  getAllPostComment: []
};

export const HandleMarketplace = (state = initialState, action) => {
  switch (action.type) {
    case "CREATE_MARKETPLACE":
      return {
        ...state,
        marketplace: action.payload?.data,
      };
    case "GET_MARKETPLACE":
      return {
        ...state,
        marketplacedata: action.payload,
      };
    case "RESULT_MARKETPLACE":
      return {
        ...state,
        results: action.payload,
      };
    case "SEND_INVITATION":
      return {
        ...state,
        sendInvitation: action.payload,
        results: action.payload,
      };
    case "DELETE_INVITATION":
      return {
        ...state,
        deleteInvitation: action.payload,
      };
    case "MY_INVITATION":
      return {
        ...state,
        myInvitation: action.payload,
      };
    case "GET_POST":
      return {
        ...state,
        getpost: action.payload,
      };
    case "GETALL_POST":
      return {
        ...state,
        getAllPost: action.payload,
      };
    case "GETALL_POST_COMMENT":
      return {
        ...state,
        getAllPostComment: action.payload,
      };
    case "SET_LOADING":
      return { ...state, error: action?.payload?.response };

    default:
      return state;
      break;
  }
};
