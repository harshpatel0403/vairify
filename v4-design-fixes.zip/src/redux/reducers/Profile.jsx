const initialState = {
  error: {},
  profileservices: {},
  profiledata: {},
};

export const HandleProfile = (state = initialState, action) => {
  switch (action.type) {
    case "CREATE_PROFILE":
      return {
        ...state,
        profileservices: action.payload?.data,
      };
    case "GET_PROFILE":
      return {
        ...state,
        profiledata: action.payload,
      };
    case "SET_LOADING":
      return { ...state, error: action?.payload?.response };

    default:
      return state;
      break;
  }
};
