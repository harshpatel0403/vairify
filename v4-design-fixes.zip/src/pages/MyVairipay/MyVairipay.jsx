import Button from "../../components/Button";
import Carousel from "../../components/Carousel";
import { useNavigate } from "react-router-dom";
import VaripayService from "../../services/VaripayServices";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

export default function MyVairipay() {
  const navigate = useNavigate();
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);

  const [varipayRequest, setVaripayRequest] = useState([]);

  const [userVaripays, setUserVaripays] = useState([]);

  const getUseraripays = () => {
    VaripayService.getUserVariapys(UserData._id)
      .then((res) => {
        console.log(res);

        setUserVaripays(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getUserVaripayRequests = () => {
    VaripayService.userVariapayRequests(UserData._id)
      .then((res) => {
        setVaripayRequest(res)
        console.log("res: ", res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getUseraripays();
    getUserVaripayRequests();
  }, []);


  const handelNavigate = () =>{
    navigate("/vairipay-request" , {
      state: varipayRequest
    });
  }
 

  return (
    <div className="main-container">
      <div className="w-full mx-auto flex flex-col justify-center items-center pt-10">
        <div className="w-full mx-auto flex flex-row justify-center items-center">
          <div className="mr-2 relative bottom-2">
            <span className="text-[55px] text-[#040B47] font-bold">My</span>
          </div>
          <div>
            <img src={"/images/Vairipay.png"} alt="Vairipay Logo" />
          </div>
        </div>
        <div
          style={{ width: "100vw" }}
          className="flex flex-col justsify-center items-center mt-5 bg-[#040C50] px-4 shadow-2xl"
        >
          <Carousel images={userVaripays} vairipay={"true"} />
        </div>

        <div className="w-full mx-auto flex flex-col justify-center items-center mt-8 py-2 border-2 border-[#000] bg-[#3760CB] max-[350px]:h-[120px] h-[105px] rounded-[30px] max-[350px]:px-10 px-10 shadow-2xl leading-6">
          <span className="text-center pt-2">
            <span className="font-bold text-[22px] text-white">
              You Have{" "}
              <span
                className="w-[30px] h-[30px] text-[20px] text-[#01195C] inline-flex items-center justify-center bg-yellow-400 rounded-full text-lg"
                style={{ fontWeight: "bold" }}
              >
                {varipayRequest && varipayRequest.length}
              </span>
              Request
            </span>
          </span>
          <div className="mt-2 mb-1">
            <Button
            onClick={handelNavigate}
              className={
                "flex items-center px-[30px] py-2 my-2 max-w-[118px] justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] py-2"
              }
              text={"View"}
              size="36px"
            />
          </div>
        </div>
        <div className="w-[100%] max-w-[400px] mx-auto flex flex-row justify-between items-start mt-10">
          <div className="flex flex-col justify-center items-center w-[48%]">
            <div className="relative">
              <img src={"/images/VAIRIPAYⓒ.png"} alt="Vairipay text" />
            </div>
            <div
              onClick={() => {
                navigate("/vairipay-search");
              }}
            >
              <img
                src={"/images/Vairipay1.png"}
                alt="Vairipay First"
                className="w-[100px]"
              />
            </div>
            <div className="relative pt-2">
              <span className="text-[18px] font-bold">P2P APPS</span>
            </div>
          </div>
          <div className="flex flex-col justify-center items-center w-[48%]">
            <div className="relative">
              <img src={"/images/VAIRIPAYⓒ.png"} alt="Vairipay text" />
            </div>
            <div
              onClick={() => {
                navigate("/goldentoken");
              }}
            >
              <img
                src={"/images/Vairipay2.png"}
                alt="Vairipay Second"
                className="w-[100px]"
              />
            </div>
            <div className="relative pt-2">
              <span className="text-[18px] font-bold">Golden Rose Tokens</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
