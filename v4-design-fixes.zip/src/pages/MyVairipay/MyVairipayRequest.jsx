import { useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-regular-svg-icons";
import Modal from "react-modal";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Slider from "react-slick";
import VaripayService from "../../services/VaripayServices";
import CarouselPrevArrow from "../../components/CarouselPrevArrow";
import CarouselNextArrow from "../../components/CarouselNextArrow";
import InputText from "../../components/InputText";

export default function MyVairipayRequest() {
  const { state } = useLocation();
  const [messageOpen, setMessageOpen] = useState(false);
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    cssEase: "linear",
    prevArrow: <CarouselPrevArrow />,
    nextArrow: <CarouselNextArrow />,
  };

  const [userVaripay, setUserVaripay] = useState([]);

  const handleNextClick = () => {
    if (currentItemIndex < state.length - 1) {
      setCurrentItemIndex(currentItemIndex + 1);
    }
  };

  const handlePreviousClick = () => {
    if (currentItemIndex > 0) {
      setCurrentItemIndex(currentItemIndex - 1);
    }
  };

  const currentRequest = state[currentItemIndex];

  const compareUserVaripays = () => {
    VaripayService.comapareUserVaripays(
      UserData._id,
      currentRequest.requester._id
    )
      .then((res) => {
        console.log(res);
        setUserVaripay(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    compareUserVaripays();
  }, [currentRequest]);

  const closeMessage = () => {
    setMessageOpen(false);
  };

  const navigate = useNavigate();

  const handelDeleteRequest = (e, id) => {
    e.preventDefault();
    VaripayService.deleteUserVaripayRequest(id)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className="main-container">
      <div className="w-full mx-auto flex flex-col justify-center items-center pt-2">
        <div className="w-full mx-auto flex flex-row justify-center items-start">
          <div className="flex flex-col items-center justify-center">
            <div>
              <span className="text-[18px] text-[#040C50] font-extrabold">
                VAI
                <span className="text-[18px] text-[#040C50] font-medium">
                  RIFY ID
                </span>
              </span>
            </div>
            <div>
              <span className="text-[15px] text-[#040C50] font-bold">
                {currentRequest?.requester?.vaiID}
              </span>
            </div>
          </div>
          <div className="w-[120px] relative">
            <div
              style={{ left: "0px", bottom: "80px" }}
              className="absolute w-full h-full"
            >
              <img
                src={import.meta.env.BASE_URL + "images/Ellipse 121.png"}
                alt="Sugar"
              />
            </div>
            <div style={{ right: "4px", top: "6px" }} className="absolute">
              <img
                src={import.meta.env.BASE_URL + "images/SugarIcon2.png"}
                alt="Sugar Icon Second"
              />
            </div>
          </div>
          <div>
            <div>
              <span className="text-[18px] text-[#040C50] font-bold">
                TRU
                <span className="text-[18px] text-[#040C50] font-light">
                  REVU
                  <span className="text-[10px] text-[#040C50] font-light">
                    ⓒ
                  </span>
                </span>
              </span>
            </div>
            <div className="flex flex-row justify-center items-center">
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <span className="text-[15px] text-[#040C50] font-bold">5.0</span>
            </div>
          </div>
        </div>
        <div className="w-full mx-auto flex flex-col justify-center items-center relative bottom-3">
          <div>
            <span className="font-bold text-[24px]">
              {currentRequest?.requester?.name}
            </span>
          </div>
          <div className="mt-2">
            <img
              src={import.meta.env.BASE_URL + "images/MaskGroup.png"}
              alt="Mask Group"
            />
          </div>
          <button onClick={handlePreviousClick}>Previous</button>
          <button onClick={handleNextClick}>Next</button>
          <button onClick={() => setMessageOpen(true)}>
            <div className="w-[150px] h-[47px] rounded-full bg-gradient-to-b from-[#FFFFFF] to-[#0C8A02] flex flex-col justify-center items-center">
              <div className="font-bold text-[10px]">
                {currentRequest?.requester?.name} has requested
              </div>
              <div className="font-bold text-[20px]">
                ${currentRequest?.amount}.00
              </div>
            </div>
          </button>
        </div>
        <div
          style={{ width: "100vw" }}
          className="flex flex-col justsify-center items-center mt-2 bg-[#040C50] px-4 shadow-2xl"
        >
          <Slider {...settings}>
            {userVaripay?.map((varipay) => (
              <div key={varipay._id} className="max-w-[90px] h-[90px]">
                <p>{varipay.paymentAppName}</p>
                <img
                  className="w-full h-full"
                  src={
                    import.meta.env.VITE_APP_API_USER_VARIPAY_IMAGE_URL +
                    `/${varipay?.paymentImage}`
                  }
                  alt={varipay.paymentImage}
                />
                <div
                  className="text-custom flex justify-center items-center"
                  style={{ background: "transparent", color: "white" }}
                >
                  <span className="font-bold text-[14px]">click here</span>
                </div>
              </div>
            ))}
          </Slider>
        </div>
        {userVaripay.length === 0 ? (
          <div className="w-full mx-auto flex flex-col justify-center items-center mt-8 bg-[#3760CB] max-[350px]:h-fit h-[98px] rounded-3xl px-10 leading-5 shadow-2xl">
            <span className="text-center">
              <span className="font-bold text-[18px] text-white">
                Our system has not detected common apps with{" "}
                {currentRequest?.requester?.name}. To use
              </span>
              <span className="font-extrabold text-[18px] text-white">VAI</span>
              <span className="font-light text-[18px] text-white">
                RIPAY<span className="text-[10px]">ⓒ</span>{" "}
              </span>
              <span className="font-bold text-[18px] text-white">
                please click an icon above
              </span>
            </span>
          </div>
        ) : (
          <div className="w-full mx-auto flex flex-col justify-center items-center mt-8 bg-[#3760CB] max-[350px]:h-fit h-[98px] rounded-3xl px-10 leading-5 shadow-2xl">
            <span className="text-center">
              <span className="font-bold text-[18px] text-white">
                Our system has detected shared apps with{" "}
                {currentRequest?.requester?.name}. To use
              </span>
              <span className="font-extrabold text-[18px] text-white">VAI</span>
              <span className="font-light text-[18px] text-white">
                RIPAY<span className="text-[10px]">ⓒ</span>{" "}
              </span>
              <span className="font-bold text-[18px] text-white">
                please click an icon above
              </span>
            </span>
          </div>
        )}

        <div className="w-[100%] max-w-[400px] mx-auto flex flex-row justify-between items-start mt-10">
          <div className="flex flex-col justify-center items-center w-[48%]">
            <div className="relative">
              <img
                src={import.meta.env.BASE_URL + "images/VAIRIPAYⓒ.png"}
                alt="Vairipay text"
                className="w-[100px]"
              />
            </div>
            <div onClick={() => navigate("/vairipay-search")}>
              <img
                src={import.meta.env.BASE_URL + "images/Vairipay1.png"}
                className="w-[100px]"
                alt="Vairipay First"
              />
            </div>
            <div className="relative pt-2">
              <span className="text-[18px] font-bold">P2P APPS</span>
            </div>
          </div>
          <div className="flex flex-col justify-center items-center w-[48%]">
            <div className="relative">
              <img
                src={import.meta.env.BASE_URL + "images/VAIRIPAYⓒ.png"}
                alt="Vairipay text"
                className="w-[100px]"
              />
            </div>
            <div
              onClick={() => {
                navigate("/goldentoken");
              }}
            >
              <img
                src={import.meta.env.BASE_URL + "images/Vairipay2.png"}
                alt="Vairipay Second"
                className="w-[100px]"
              />
            </div>
            <div className="relative pt-2">
              <span className="text-[18px] font-bold">Golden Rose Tokens</span>
            </div>
          </div>
        </div>
      </div>
      <Modal
        isOpen={messageOpen}
        //   onAfterOpen={afterMessageOpen}
        onRequestClose={closeMessage}
        className={
          "bg-[#3760CB] relative top-56 mx-auto py-4 w-[95%] rounded-2xl px-4"
        }
        contentLabel="#"
      >
        <div className="h-[210.23px] sm:h-fit bg-[#3760CBD4] rounded-2xl border-2 border-[#fff] p-[7px_7px_5px_10px] sm:p-[10px_10px_10px_10px]">
          <div className="flex">
            <div className="flex flex-col justify-between items-center w-[30%]">
              <img
                src="/images/gallery-peofile.png"
                alt=""
                className="w-[74px] sm:w-[84px] h-[72.44px] sm:h-[84px]"
              />
              <p className="text-[12px] text-[#fff] font-bold pt-px leading-[10.57px]">
                TRUREVU<span className="text-[8px]">ⓒ</span>
              </p>
              <p className="text-[12px] text-[#fff] font-bold text-center leading-[17.57px]">
                {currentRequest?.requester?.name}{" "}
                {currentRequest?.requester?.vaiID}
              </p>
              <div className="flex gap-1 items-start">
                <div className="flex gap-1 mt-1">
                  {[0, 1, 2, 3, 4].map((rating) => (
                    <img
                      src="/images/Star.svg"
                      className="w-[10px]  h-[10px]"
                      alt=""
                    />
                  ))}
                </div>
                <span className="text-white block text-center  font-roboto font-bold text-[15px]">
                  5.0
                </span>
              </div>
              <p className="text-[14px] text-[#fff] font-bold rounded-2xl border-2 border-[#fff] bg-[#02227E] px-2 py-px text-center h-fit min-h-[33.7px] flex justify-center items-center">
                View Profile
              </p>
            </div>
            <div className="w-[74%]">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[14px] font-bold text-[#fff] text-center leading-[17.57px]">
                    Amount Requested
                  </p>
                  <div className="flex justify-center items-center">
                    <div className="w-[100px]">
                      <InputText
                        size="25px"
                        className="text-[24px] font-bold text-[#01195C] h-[25px]"
                        placeholder={`$${currentRequest?.amount}`}
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-[14px] font-bold text-[#fff]">
                    Request Type{" "}
                  </p>
                  <p className="text-[18px] font-bold text-[#fff] uppercase">
                    Intial
                  </p>
                </div>
              </div>
              <div className="pb-px">
                <p className="text-[10px] font-bold text-center text-[#fff]">
                  Comments
                </p>
                <div className="px-7">
                  <InputText
                    placeholder={`$${currentRequest?.mesage}`}
                    size="59px"
                    bgColor="[#D9D9D97D]"
                    border="#02227E"
                    className="border-2 rounded-2xl"
                  />
                </div>
              </div>
              <div className="my-1 flex justify-center h-[34px] flex justify-center items-center pt-2">
                <p
                  onClick={(e) => handelDeleteRequest(e, UserData._id)}
                  className="text-[#FFFFFF] text-[20px] font-bold mt-2 px-7 py-2 rounded-2xl bg-gradient-to-b from-[#A30C30] to-[#DB3002] max-w-[150px] text-center"
                >
                  Deny
                </p>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
