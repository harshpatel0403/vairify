import { faStar } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function MyVairipayAppleRequestQR() {
    const navigate = useNavigate()
    const {state} = useLocation()
    const handleSubmit = () => {
        navigate('/my-vairipay-request-confirm')
    }
    return (
        <div className="main-container">
     <div className="w-full mx-auto flex flex-col justify-center items-center pt-2">
        <div className="w-full mx-auto flex flex-row justify-center items-start">
          <div className="flex flex-col items-center justify-center">
            <div>
              <span className="text-[18px] text-[#040C50] font-extrabold">
                VAI
                <span className="text-[18px] text-[#040C50] font-medium">
                  RIFY ID
                </span>
              </span>
            </div>
            <div>
              <span className="text-[15px] text-[#040C50] font-bold">
                658H39
              </span>
            </div>
          </div>
          <div className="w-[120px] relative">
            <div
              style={{ left: "0px", bottom: "80px" }}
              className="absolute w-full h-full"
            >
              <img
                src={import.meta.env.BASE_URL + "images/Ellipse 121.png"}
                alt="Sugar"
              />
            </div>
            <div style={{ right: "4px", top: "6px" }} className="absolute">
              <img
                src={import.meta.env.BASE_URL + "images/SugarIcon2.png"}
                alt="Sugar Icon Second"
              />
            </div>
          </div>
          <div>
            <div>
              <span className="text-[18px] text-[#040C50] font-bold">
                TRU
                <span className="text-[18px] text-[#040C50] font-light">
                  REVU
                  <span className="text-[10px] text-[#040C50] font-light">
                    ⓒ
                  </span>
                </span>
              </span>
            </div>
            <div className="flex flex-row justify-center items-center">
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <span className="text-[15px] text-[#040C50] font-bold">5.0</span>
            </div>
          </div>
        </div>
        <div className="w-full mx-auto flex flex-col justify-center items-center relative bottom-2">
          <div>
            <span className="font-bold text-[24px]">Sugar</span>
          </div>
        </div>
            <div className="w-full mx-auto flex flex-col justify-center items-center pt-10">
                <div className='w-full mx-auto flex items-center justify-center'>
                    <img src={import.meta.env.BASE_URL + 'images/VairipayAddLogo.png'} alt="Vairipay Add Logo" />
                </div>
                <div className='w-full mx-auto flex flex-col justify-center items-center mt-8 bg-[#3760CB] rounded-3xl px-10 py-2 shadow-2xl border-2 border-black'>
                    <span className='text-center'>
                <span className='font-black text-[18px] text-white leading-6'>You have selected Apple Pay Touch the QR code to Open the app to Sugars account.</span>
                    </span>
                </div>
                <button className='w-full mx-auto' onClick={() => handleSubmit()}>
                    <div className='w-full mx-auto flex flex-col justify-center items-center py-4 bg-[#3760CB] rounded-[30px] mt-10'>
                        <div><img src={import.meta.env.BASE_URL + 'images/VairipayQRApple.png'} alt="Vairipay QR Apple Logo"/></div>
                        <div><span className='text-white text-[27px] font-bold'>Sugar</span></div>
                        <div><span className='text-white text-[18px] font-extrabold'>VAI</span><span className='text-white text-[18px] font-medium'>RIFY ID</span><span className='text-white text-[18px] font-bold ml-2'>{state?.item?.PaymentID}</span></div>
                        <div><img src={import.meta.env.BASE_URL + 'images/VairipayRequestQR.png'} alt="Vairipay Request QR Logo" /></div>
                        <div><span className='text-white text-[32px] font-bold'>$25.00</span></div>
                    </div>
                </button>
            </div>
            </div>
        </div>
    );
}