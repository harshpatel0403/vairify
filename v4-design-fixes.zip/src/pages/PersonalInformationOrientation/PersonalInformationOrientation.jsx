import { useEffect, useMemo, useState } from "react";
import Button from "../../components/Button";
import { useDispatch, useSelector } from "react-redux";
import { HandleProfile } from "../../redux/action/Profile";
import { toast } from "react-toastify";
import Loading from "../../components/Loading/Index";
import { HandleCountry } from "../../redux/action/Auth";

const Ethnicity = [
  "White",
  "Latina",
  "Asian",
  "African American",
  "Native American",
  "French",
  "German",
  "Italian",
  "Middle Eastern",
  "English",
  "South American",
  "Baltic",
  "Hawaiian",
  "Eastern European",
  "Spanish",
  "Indian",
  "Mixed",
];
const Nationality = [
  "American",
  "Argentinian",
  "Armenian ",
  "Australian ",
  "Austrian ",
  "Belarussian ",
  "Belgian ",
  "Brazilian ",
  "British ",
  "Bulgarian ",
  "Canadian ",
  "Chinese ",
  "Colombian ",
  "Czech ",
  "Dutch ",
  "English ",
  "Estonian ",
  "Filipino ",
  "French ",
  "German ",
  "Ghanaian ",
  "Greek ",
  "Hungarian ",
  "Indian ",
  "Indonesian ",
  "Italian ",
  "Japanese ",
  "Kazakh ",
  "Kenyan ",
  "Korean ",
  "Latvian ",
  "Lebanese ",
  "Lithuanian ",
  "Malaysian ",
  "Mexican ",
  "Moldovan ",
  "Moroccan ",
  "Nigerian ",
  "Polish ",
  "Portuguese ",
  "Romanian ",
  "Russian ",
  "Singaporean ",
  "South african ",
  "Spanish ",
  "Swedish ",
  "Tanzanian ",
  "Thai ",
  "Turkish ",
  "Ukrainian ",
  "Venezuelan ",
  "Vietnamese ",
];
const Age = [
  "18 - 20",
  "21 - 25",
  "26 - 30",
  "31 - 35",
  "36 - 40",
  "41 - 45",
  "46 - 50",
  "Over 50",
];
const Build = [
  "Average",
  "Slender",
  "Athletic",
  "Very muscular",
  "Curvy",
  "Few Extra Pounds",
  "Flabby",
  "Plus Size",
];
const HairLength = [
  "Bald ",
  "Super short",
  "Short",
  "Chin length",
  "Shoulder length",
  "Below shoulders",
  "Mid back",
  "Ass length",
  "Super long",
];
const HairColor = ["Bleached", "Blonde", "Brown", "Black", "Red", "Other"];
const HairStyle = ["Straight", "Some curls", "Curly", "Permed", "Other"];
const Eyes = ["Blue", "Brown", "Green", "Hazel", "Grey", "Black"];
const Country = [];
const City = [];
const Smoker = ["Yes", "No"];

const Weight = [
  "45kg / 99lbs or less",
  "46-50kg / 101-110 lbs",
  "51- 55kg / 112-121 lbs",
  "56-60kg / 123-132 lbs",
  "61-65kg / 134-143 lbs",
  "66-70kg / 146- 154 lbs",
  "71-90kg / 157 - 198 lbs",
  "91- 110kg / 201- 243 lbs",
  "111 / 245 lbs  and Over",
];
const PubicHair = ["Natural", "Partially shaved", "Shaved"];
const Piercings = [
  "None",
  "Tongue",
  "Breasts",
  "Belly button",
  "Pussy",
  "Face Tongue",
  "Tongue and breasts",
  "Breasts Tongue",
  "Pussy Breast",
  "Pussy Other",
];
const BreastCup = ["A", "B", "C", "D", "DD", "DDD", "E or higher"];

const BreastAppearance = [
  "Flat",
  "Average",
  "Youthful",
  "Perky",
  "Rock hard",
  "Super nice",
  "Droopy",
  "Really saggy",
  "Unattractive",
  "Unnatural",
];
const BreastType = ["Natural", "Augmented (Implants)"];

const DickSize = [
  "10cm / 3.94 inches",
  "11cm / 4.33 inches",
  "12cm / 4.72 inches",
  "13cm / 5.12 inches",
  "14cm / 5.51 inches",
  "15cm / 5.91 inches",
  "16cm / 6.30 inches",
  "17cm / 6.69 inches",
  "18cm / 7.09 inches",
  "19cm / 7.48 inches",
  "20cm / 7.87 inches",
  "21cm / 8.27 inches",
  "22cm / 8.66 inches",
  "23cm / 9.06 inches",
];

const Tattoos = ["None", "One", "A few", "Many", "Many"];

const Travel = ["Local", "State/Province", "Country", "Worldwide (FMTY)"];

const Venue = ["Incall", "Outcall"];

const Virtual = ["Video", "Voice", "Sexting", "Photo/Videos"];

const Pornstar = ["Yes", "No"];

const Communication = ["App Only", "Outside Number", "Both"];
const OnlyFans = ["Yes", "No"];
const SocialMedia = [
  "OnlyFans",
  "Facebook",
  "YouTube",
  "WhatsApp",
  "Instagram",
  "Twitter",
  "TikTok",
  "Snapchat",
  "LinkedIn",
  "Pinterest",
  "Reddit",
  "Telegram",
  "WeChat",
  "QQ",
  "QZone",
  "Sina Weibo",
  "Tumblr",
  "Viber",
  "Baidu Tieba",
  "Quora",
  "LINE",
  "Twitch",
  "KakaoTalk",
  "Douban",
  "Medium",
  "Vkontakte (VK)",
  "Odnoklassniki",
  "Taringa!",
  "Mixi",
  "Flickr",
  "Swarm",
  "Meetup",
  "Nextdoor",
  "Tagged",
  "Badoo",
  "MySpace",
  "Viadeo",
  "Youku",
  "Xing",
  "Twoo",
];
const Staff = [
  "1 to 5 Employees",
  "5 to 10 Employees",
  "10 to 20 Employees",
  "20 to 50 Employees",
  "50 and up Employees",
  "Virtual Employees",
];
const TypeOfBusiness = [
  "Strip Club",
  "Escort Agency",
  "Massage Parlor",
  "Organization",
  "Support",
  "Forum/Publication",
];
const Location = [];
const BreastSize = [];

const PersonalInformationOrientation = () => {
  const dispatch = useDispatch();
  const UserAuth = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const countryData = useSelector((state) => state?.Auth?.country);
  const [optionData, setOptionDate] = useState({});
  const [genderOptions, setGenderOptions] = useState([
    "Male",
    "Female",
    "Trans Male Pre-Op",
    "Trans Female Pre-Op",
    "Trans Male Post-Op",
    "Trans Female Post-Op",
  ]);
  const [selectedGender, setSelectedGender] = useState("Male");
  const [orientationOptions, setOrientationOptions] = useState([
    "M4W",
    "M4M",
    "Bisexual",
  ]);
  const [selectedOrientation, setSelectedOrientation] = useState("M4W");
  const [heightOptions, setHeightOptions] = useState([]);
  const [FacialHair, setFacialHair] = useState([]);
  const [isLoading, setIsLoading] = useState(false); // State to track loading

  // Function to update orientation options based on selected gender
  // Function to update orientation options based on selected gender
  const updateOrientationOptions = (selectedGender) => {
    if (selectedGender === "Male") {
      setOrientationOptions(["M4W", "M4M", "Bisexual"]);
      setHeightOptions([
        "5'0\" - 5'5\"",
        "5'5\" - 5'8\"",
        "5'9\" - 5'11\"",
        "6'0\" - 6'2\"",
        "6'3\" - 6'5\"",
        "6'5\" or 6'7\"",
        "6'8\" or taller",
      ]);
      setFacialHair(["clean shaven", "mustache", "Beard"]);
    } else if (selectedGender === "Female") {
      setOrientationOptions(["W4M", "W4W", "Bisexual"]);
      setHeightOptions([
        "4'9\" - 4'11\"",
        "5'0\" - 5'2\"",
        "5'3\" - 5'5\"",
        "5'6\" - 5'8\"",
        "5'9\" - 5'11\"",
        "6'0\" - 6'2\"",
        "6'3\" - 6'5\"",
        "6'5\" or Taller",
      ]);
      setFacialHair([]); // No facial hair options for females
    } else if (selectedGender.startsWith("Trans Male")) {
      setHeightOptions([
        "5'0\" - 5'5\"",
        "5'5\" - 5'8\"",
        "5'9\" - 5'11\"",
        "6'0\" - 6'2\"",
        "6'3\" - 6'5\"",
        "6'5\" or 6'7\"",
        "6'8\" or taller",
      ]);
      setFacialHair(["clean shaven", "mustache", "Beard"]);
    } else if (selectedGender.startsWith("Trans Female")) {
      setHeightOptions([
        "4'9\" - 4'11\"",
        "5'0\" - 5'2\"",
        "5'3\" - 5'5\"",
        "5'6\" - 5'8\"",
        "5'9\" - 5'11\"",
        "6'0\" - 6'2\"",
        "6'3\" - 6'5\"",
        "6'5\" or Taller",
      ]);
      setFacialHair([]); // No facial hair options for trans females
    } else if (selectedGender.startsWith("Trans")) {
      setOrientationOptions(["T4W", "T4M", "Bisexual"]);
      setHeightOptions([]);
      setFacialHair([]); // No facial hair options for trans individuals
    } else {
      setOrientationOptions([]);
      setHeightOptions([]);
      setFacialHair([]); // No facial hair options for other genders
    }
  };

  // Event handler for gender select change
  const handleGenderChange = (event) => {
    HandleOption(event);
    const selectedGender = event.target.value;
    setSelectedGender(selectedGender);
    updateOrientationOptions(selectedGender);
  };

  // Event handler for orientation select change
  const handleOrientationChange = (event) => {
    HandleOption(event);
    const selectedOrientation = event.target.value;
    setSelectedOrientation(selectedOrientation);
  };

  useEffect(() => {
    updateOrientationOptions(selectedGender);
  }, [selectedGender]);

  const HandleOption = (event) => {
    setOptionDate({ ...optionData, [event.target.name]: event.target.value });
  };

  const HandleSubmit = () => {
    setIsLoading(true);
    optionData.gender = selectedGender;
    optionData.orientation = selectedOrientation;
    optionData.userId = UserAuth?._id;
    optionData.siteId = UserAuth?.vaiID;
    dispatch(HandleProfile(optionData))
      .then((result) => {
        if (result?.payload?.status === 200) {
          toast(result?.payload?.data?.message, {
            hideProgressBar: true,
            autoClose: 3000,
            type: "success",
          });
          setIsLoading(false);
        } else {
          toast(result?.payload?.data?.error, {
            hideProgressBar: true,
            autoClose: 3000,
            type: "error",
          });
          setIsLoading(false);
        }
      })
      .catch((err) => {
        setIsLoading(false);
        console.error(err, "Error");
      });
  };
  useMemo(() => {
    countryData.map((item) => {
      const name = item.name;
      const city = item?.cities?.map((city) => city?.name);
      Location.push(name);
      Country.push(name);
      City.push(city);
      return;
    });
  }, [countryData]);
  useEffect(() => {
    dispatch(HandleCountry());
  }, []);

  return (
    <div>
      <h1 className="text-[27px] font-black text-center font-roboto py-2">
        Profile
      </h1>
      {
        // Client Personal information
      }
      {UserAuth?.user_type === "client-hobbyist" && (
        <div>
          <p className="bg-gradient-to-t from-[#0247FF] to-[#02227EAD] h-[27px]" />
          <h1 className="text-[27px] text-[#000] text-center font-black font-robotot pt-2">
            Personal information
          </h1>
          <div className="flex flex-col items-center justify-center px-5">
            <div className="flex justify-between items-center w-full max-w-[420px]">
              <div className="flex flex-col items-start w-[45%]">
                <p className="text-[16px] text-[#000] text-start font-bold font-roboto-serif w-full">
                  Gender
                </p>
                <div className="flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5">
                  <select
                    className="px-2 pb-1.5 pt-px bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] text-center font-bold font-inter min-w-[fit] w-full h-[35px]"
                    value={selectedGender}
                    name="gender"
                    onChange={handleGenderChange}
                  >
                    {genderOptions.map((gender) => (
                      <option key={gender} value={gender}>
                        {gender}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex flex-col items-start w-[45%]">
                <p className="text-[16px] text-[#000] text-start font-bold font-roboto-serif w-full">
                  Orientation
                </p>
                <div className="flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5">
                  <select
                    className="px-2 pb-1.5 pt-px bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] text-center font-bold font-inter min-w-[fit] w-full h-[35px]"
                    value={selectedOrientation}
                    name="orientation"
                    onChange={handleOrientationChange} // Add this line
                  >
                    {orientationOptions.map((orientation) => (
                      <option key={orientation} value={orientation}>
                        {orientation}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 w-full gap-x-5 gap-y-2.5 mt-5 pb-2">
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center px-2 w-[100%] h-[36px]">
                <p className="text-[14.4px] text-[#000] font-bold font-roboto leading-4">
                  Site ID (Automatic)
                </p>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="age"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Age
                  </option>
                  {Age.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="country"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Country
                  </option>
                  {Country.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="city"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    City
                  </option>
                  {City.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="ethinicity"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Ethinicity
                  </option>
                  {Ethnicity.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="nationality"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Nationality
                  </option>
                  {Nationality.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="smoker"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Smoker
                  </option>
                  {Smoker.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              {UserAuth?.user_type !== "client-hobbyist" && (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="languages"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Languages
                    </option>
                    {Country.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              {UserAuth?.user_type === "client-hobbyist" && (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="communication"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Communication
                    </option>
                    {Communication.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              {UserAuth?.user_type === "client-hobbyist" && (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="socialmedia"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Social Media
                    </option>
                    {SocialMedia.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {
        // Business Personal information
      }
      {UserAuth?.user_type === "agency-business" && (
        <div>
          <h1 className="text-[27px] text-[#000] text-center font-black font-robotot pt-2">
            Business Information
          </h1>
          <div className="flex flex-col items-center justify-center px-5">
            <div className="grid grid-cols-2 sm:grid-cols-3 w-full gap-x-5 gap-y-2.5 mt-5 pb-2">
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="typeofbusiness"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Type Of Business
                  </option>
                  {TypeOfBusiness.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="staff"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Staff
                  </option>
                  {Staff.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="virtual"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Virtual
                  </option>
                  {Virtual.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="location"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Location
                  </option>
                  {Location.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="venue"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Venue
                  </option>
                  {Venue.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="communication"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Communication/Contact
                  </option>
                  {Communication.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="socialmedia"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Social Media
                  </option>
                  {SocialMedia.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="virtualservices"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Virtual Services
                  </option>
                  {Virtual.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {
        // Companion Personal information
      }
      {UserAuth?.user_type === "companion-provider" && (
        <div>
          <h1 className="text-[27px] text-[#000] text-center font-black font-robotot pt-2">
            Personal information
          </h1>
          <div className="flex flex-col items-center justify-center px-5">
            <div className="flex justify-between items-center w-full max-w-[420px]">
              <div className="flex flex-col items-start w-[45%]">
                <p
                  className="text-[16px] text-[#000] text-start font-bold font-roboto-serif w-full"
                  name="gender"
                >
                  Gender
                </p>
                <div className="flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5">
                  <select
                    className="px-2 pb-1.5 pt-px bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] text-center font-bold font-inter min-w-[fit] w-full h-[35px]"
                    value={selectedGender}
                    name="gender"
                    onChange={handleGenderChange}
                  >
                    {genderOptions.map((gender) => (
                      <option key={gender} value={gender}>
                        {gender}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex flex-col items-start w-[45%]">
                <p className="text-[16px] text-[#000] text-start font-bold font-roboto-serif w-full">
                  Orientation
                </p>
                <div className="flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5">
                  <select
                    className="px-2 pb-1.5 pt-px bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] text-center font-bold font-inter min-w-[fit] w-full h-[35px]"
                    value={selectedOrientation}
                    name="orientation"
                    onChange={handleOrientationChange} // Add this line
                  >
                    {orientationOptions.map((orientation) => (
                      <option key={orientation} value={orientation}>
                        {orientation}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 w-full gap-x-5 gap-y-2.5 mt-5 pb-2">
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center px-2 w-[100%] h-[36px]">
                <p className="text-[14.4px] text-[#000] font-bold font-roboto leading-4">
                  Site ID (Automatic)
                </p>
              </div>

              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="country"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Country
                  </option>
                  {Country.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="city"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    City
                  </option>
                  {City.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="ethinicity"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Ethinicity
                  </option>
                  {Ethnicity.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="nationality"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Nationality
                  </option>
                  {Nationality.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="smoker"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Smoker
                  </option>
                  {Smoker.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      )}
      {
        // Companion Personal Appearance
      }
      {UserAuth?.user_type === "companion-provider" && (
        <div>
          <p className="bg-gradient-to-t from-[#0247FF] to-[#02227EAD] h-[27px] w-full mt-4" />
          <h1 className="text-[27px] text-[#000] text-center font-black font-robotot pt-2">
            Personal Appearance
          </h1>

          <div className="flex flex-col items-center justify-center px-5">
            <div className="grid grid-cols-2 sm:grid-cols-3 w-full gap-x-5 gap-y-2.5 mt-5 pb-2">
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="build"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Build
                  </option>
                  {Build.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="height"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Height
                  </option>
                  {heightOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="eyescolor"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Eyes Color
                  </option>
                  {Eyes.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>

              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="haircolor"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Hair Color
                  </option>
                  {HairColor.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="hairlength"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Hair Length
                  </option>
                  {HairLength.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="weight"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Weight
                  </option>
                  {Weight.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="publichair"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Public Hair
                  </option>
                  {PubicHair.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="piercings"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Piercings
                  </option>
                  {Piercings.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              {selectedGender === "Female" ||
              selectedGender.startsWith("Trans") ? (
                <>
                  <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                    <select
                      className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                      name="breasttype"
                      onChange={HandleOption}
                    >
                      <option selected disabled>
                        Breast Type
                      </option>
                      {BreastType.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                    <select
                      className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                      name="breastsize"
                      onChange={HandleOption}
                    >
                      <option selected disabled>
                        Breast Size
                      </option>
                      {BreastSize.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                    <select
                      className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                      name="breastappearance"
                      onChange={HandleOption}
                    >
                      <option selected disabled>
                        Breast Appearance
                      </option>
                      {BreastAppearance.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                </>
              ) : null}
              {selectedGender === "Male" ||
              selectedGender === "Female" ||
              selectedGender.startsWith("Trans") ? (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="tattoos"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Tattoos
                    </option>
                    {Tattoos.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}
              {selectedGender === "Male" ||
              selectedGender.startsWith("Trans") ? (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="dicksize"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Dick Size
                    </option>
                    {DickSize.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {
        // Companion Availability/Services
      }
      {UserAuth?.user_type === "companion-provider" && (
        <>
          <p className="bg-gradient-to-t from-[#0247FF] to-[#02227EAD] h-[27px] w-full mt-4" />
          <h1 className="text-[27px] text-[#000] text-center font-black font-robotot pt-2">
            Availability/Services
          </h1>

          <div className="flex flex-col items-center justify-center px-5">
            <div className="grid grid-cols-2 sm:grid-cols-3 w-full gap-x-5 gap-y-2.5 mt-5 pb-2">
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="travel"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Travel
                  </option>
                  {Travel.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="venue"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Venue
                  </option>
                  {Venue.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              {selectedGender === "Male" || selectedGender === "Female" ? (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="onlyfans"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Only Fans
                    </option>
                    {OnlyFans.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                  <select
                    className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                    name="socialmedia"
                    onChange={HandleOption}
                  >
                    <option selected disabled>
                      Social Media
                    </option>
                    {SocialMedia.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="virtualservice"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Virtual Service
                  </option>
                  {Virtual.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="pornstar"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Pornstar
                  </option>
                  {Pornstar.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div className="border-2 border-[#767882] rounded-3xl flex justify-center items-center max-w-[319px]:px-2 max-[560px]:px-[7px] sm:px-5 w-[100%] h-[36px]">
                <select
                  className="bg-transparent px-3 py-1.5 w-full font-bold focus:outline-none"
                  name="communication"
                  onChange={HandleOption}
                >
                  <option selected disabled>
                    Communication
                  </option>
                  {Communication.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </>
      )}

      <div className="flex flex-col items-center justify-center px-5">
        <div className="w-full mt-7">
          <div className="text-[14.4px] text-roboto text-[#000] text-start font-bold">
            <span>Description</span>
          </div>
          <textarea
            id="profile_information_description"
            rows="3"
            className="block p-2 w-full text-[18px] text-[#000] bg-transparent rounded-lg border-2 border-[#767882] focus:ring-blue-500 focus:border-blue-500 "
            placeholder="Share something that describes you"
            name="description"
            onChange={HandleOption}
          ></textarea>
        </div>
        <div className="flex items-center justify-center w-full max-w-[420px] my-5">
          <Button
            className={
              "flex items-center px-[40px] py-2 my-2 w-fit justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] py-2 rounded-xl"
            }
            text={
              !isLoading ? (
                "Submit"
              ) : (
                <div className="flex items-center	justify-center pt-[6px]">
                  <Loading />
                </div>
              )
            }
            size="42px"
            onClick={HandleSubmit}
          />
        </div>
      </div>
    </div>
  );
};

export default PersonalInformationOrientation;
