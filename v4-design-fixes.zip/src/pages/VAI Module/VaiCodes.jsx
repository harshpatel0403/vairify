import { useSelector } from "react-redux";
import Button from "../../components/Button";
import TextContainer from "../../components/TextContainer";

const VaiCodes = () => {
  const CouponCode = useSelector((state) => state?.Vai?.geberateCoupon?.data);
  console.log("🚀 ~ file: VaiCodes.jsx:7 ~ VaiCodes ~ CouponCode:", CouponCode);
  return (
    <div className="main-container">
      <div className="flex flex-col justify-center items-center w-max-370 mx-auto">
        <div className="grid grid-cols-1 grid-flow-col gap-4">
          <div className="relative flex flex-col justify-start items-center">
            <div className="relative top-6">
              <img
                src={import.meta.env.BASE_URL + "images/VectorLogo1.png"}
                alt="Vector Logo 1"
              />
            </div>
            <div className="relative bottom-2 left-4">
              <img
                src={import.meta.env.BASE_URL + "images/VectorLogo2.png"}
                alt="Vector Logo 2"
              />
            </div>
            <div className="relative top-2">
              <img
                src={import.meta.env.BASE_URL + "images/V.A.I.(small).png"}
                alt="VAI Small"
              />
            </div>
            <div className="relative top-5">
              <p className="font-semibold text-[16.2px] text-justify">
                Your payment was successful. Please use the V.A.I. codes
                to verify your employees
              </p>
            </div>
          </div>
        </div>
        <div className="flex-1 mt-8 mb-6">
          <div className="flex items-center justify-center text-black font-extrabold text-[16.2px]">
            <span>V.A.I. Codes</span>
          </div>
        </div>
        <div className="w-full">
          {CouponCode?.map((coupon) => (
            <div key={coupon._id} className="flex-1 w-full mb-6">
              <TextContainer text={coupon?.code} />
            </div>
          ))}
        </div>
        {/* static values are here */}
        <div className="flex-1 w-full mt-8 mb-2">
          <Button
            className={
              "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]"
            }
            text={"Go to V.A.I. >"}
            size="45px"
          />
        </div>
      </div>
    </div>
  );
};

export default VaiCodes;
