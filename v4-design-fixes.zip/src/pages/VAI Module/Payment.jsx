/* eslint-disable no-unreachable */
import Button from "../../components/Button";
import {
  useStripe,
  useElements,
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
} from "@stripe/react-stripe-js";
import axios from "axios";
import InputText from "../../components/InputText";
import Loading from "../../components/Loading/Index";
import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { HandleGenerateCoupon } from "../../redux/action/VAI";
import { toast } from "react-toastify";

const Payment = () => {
  const { state: totalPayment } = useLocation();
  console.log(
    "🚀 ~ file: Payment.jsx:17 ~ Payment ~ totalPayment:",
    totalPayment
  );
  const strip = useStripe();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const elements = useElements();
  const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const [isLoading, setIsLoading] = useState(false); // State to track loading
  const [cardHolderName, setCardHolderName] = useState("");

  const handleOrder = async(e) => {
    e.preventDefault();
    if (UserDetails?.user_type === "agency-business") {
     await GenerateCoupon();
    }
    setIsLoading(true);
    axios
      .post(
        `${
          import.meta.env.VITE_APP_API_BASE_URL
        }/create-payment-intent-customers`,
        null,
        {
          params: {
            total: totalPayment?.totalAmount,
            currency: "PKR",
            name: cardHolderName,
            phone: "030030303033030",
          },
        }
      )
      .then(function (response) {
        console.log("Res: ", response);
        let clientSecret = response.data.clientSecret;
        strip
          .confirmCardPayment(clientSecret, {
            payment_method: {
              card: elements.getElement(CardNumberElement),
            },
          })
          .then(async (res) => {
            console.log(res, "stripe");
            // Generat coupon code
            if (UserDetails?.user_type === "agency-business") {
              await GenerateCoupon();
            }
            setIsLoading(false);
            navigate("/payment-success");
          })
          .catch((err) => {
            console.warn(err);
            setIsLoading(false);
          });
      })
      .catch(function (error) {
        console.log("error: ", error);
        setIsLoading(false);
      });
  };

  // Generate Coupon code
  const GenerateCoupon = async () => {
    setIsLoading(true);
    const body = {
      userId: UserDetails?._id,
      numberOfCoupons: parseFloat(totalPayment?.AdditionalVerification) + 3,
    };
    await dispatch(HandleGenerateCoupon(body))
      .then((result) => {
        if (result?.payload?.status === 200) {
          toast(result.payload.data.message, {
            hideProgressBar: true,
            autoClose: 3000,
            type: "success",
          });
          navigate("/payment-success");
          setIsLoading(false);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  // Create a new Date object for the current date
  const currentDate = new Date();

  // Define options for formatting the date
  const dateOptions = {
    year: "numeric",
    month: "long",
    day: "numeric",
  };

  // Format the current date using toLocaleDateString
  const formattedDate = currentDate.toLocaleDateString(undefined, dateOptions);

  return (
    <div className="main-container flex flex-col justify-start">
      <div className="grid grid-cols-1 grid-flow-col gap-4">
        <div className="relative flex flex-col justify-start items-center">
          <div className="relative top-6">
            <img
              src={import.meta.env.BASE_URL + "images/VectorLogo1.png"}
              alt="Vector Logo 1"
            />
          </div>
          <div className="relative bottom-2 left-4">
            <img
              src={import.meta.env.BASE_URL + "images/VectorLogo2.png"}
              alt="Vector Logo 2"
            />
          </div>
        </div>
      </div>

      <div className="pt-4 text-lg font-medium text-[#838282]">
        <p>{formattedDate}</p>
        <p>#1832-9912-7552</p>
      </div>

      <div className="flex-1 mt-12">
        <div className="mb-3">
          <label className="text-[18px] font-bold ml-2 text-[#02227E] flex">
            Card Number
          </label>
          <CardNumberElement
            id="cardNumber"
            className={`w-full pt-[15px] text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-transparent `}
          />
        </div>
        <div className="flex justify-between">
          <div className="mb-3">
            <label className="text-[18px] font-bold ml-2 text-[#02227E] flex">
              Expiration Date
            </label>
            <CardExpiryElement
              id="expiry"
              className={`w-full pt-[15px] text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-transparent `}
            />
          </div>
          <div className="mb-3">
            <label className="text-[18px] font-bold ml-2 text-[#02227E] flex">
              CVC
            </label>
            <CardCvcElement
              id="cvc"
              className={`w-[90px] pt-[15px] px-4 text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 h-[50px] bg-transparent `}
            />
          </div>
        </div>
        <div className="mb-3">
          <label className="text-[18px] font-bold ml-2 text-[#02227E] flex">
            Card Holder Name
          </label>
          <InputText
            value={cardHolderName}
            onChange={(e) => setCardHolderName(e.target.value)}
            placeholder={"Card Holder Name"}
            influencer-affiliate
            className={`w-full text-[12px] text-[20px] border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-transparent `}
            // border={error.nameOfBusiness && `#ef4444`}
            name={"CardHolderName"}
          />
        </div>
      </div>

      <div className="pb-2 mt-5">
        <Button
          onClick={handleOrder}
          className={
            "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]"
          }
          text={
            !isLoading ? (
              "Submit"
            ) : (
              <div className="flex items-center	justify-center pt-[6px]">
                <Loading />
              </div>
            )
          }
          size="45px"
        />
      </div>
    </div>
  );
};

export default Payment;
