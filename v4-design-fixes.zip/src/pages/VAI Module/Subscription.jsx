import { useLocation, useNavigate } from "react-router-dom";
import Button from "../../components/Button";

const Subscription = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  console.log(state, "======>>>>>>>>>");

  const HandlrCoupon = () => {
    navigate("/discount-coupon", {
      state: state,
    });
  };
  const HandlrPayment = () => {
    navigate("/migration", {
      state: state,
    });
  };
  return (
    <div className="main-container flex flex-col justify-center subscription-part">
      <div className="grid grid-cols-1 grid-flow-col gap-4">
        <div className="relative flex flex-col justify-start items-center">
          <div className="relative top-6">
            <img
              src={import.meta.env.BASE_URL + "images/VectorLogo1.png"}
              alt="Vector Logo 1"
            />
          </div>
          <div className="relative bottom-2 left-4">
            <img
              src={import.meta.env.BASE_URL + "images/VectorLogo2.png"}
              alt="Vector Logo 2"
            />
          </div>
        </div>
      </div>

      <div className="pt-4 mx-auto">
        <img
          className="mx-auto"
          src={import.meta.env.BASE_URL + "images/V.A.I..png"}
        />
        <p className="text-xl mt-8 font-semibold">
          Verified Anonymous Identity
        </p>
      </div>

      <div className="pb-4 pt-3">
        <h1 className="font-bold text-3xl">
          ${state?.totalAmount + ".00" || "$149.00"}
        </h1>
      </div>

      <div className="">
        <Button
          className={
            "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2"
          }
          text={"Submit Payment"}
          size="45px"
          onClick={HandlrPayment}
        />
      </div>

      <div className="pt-2 pb-3 text-bold">
        <hr className="border-black w-14 inline-block align-middle" />
        <span className="text-black font-bold mx-3 text-sm">OR</span>
        <hr className="border-black w-14 inline-block align-middle" />
      </div>
      <div className="pb-7">
        <Button
          className={
            "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]"
          }
          text={"Enter Coupon Code"}
          size="45px"
          onClick={HandlrCoupon}
        />
      </div>
    </div>
  );
};

export default Subscription;
