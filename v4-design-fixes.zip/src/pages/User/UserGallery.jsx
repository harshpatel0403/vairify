import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import UserGalleryService from "../../services/UserGalleryService";
import { useNavigate } from "react-router-dom";

const UserGallery = () => {
    const navigate = useNavigate();
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const [gallery, setGallery] = useState([]);

  const getGallery = () => {
    UserGalleryService.getUserGallery(UserData._id)
      .then((res) => {
        console.log(res.images);
        setGallery(res.images);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handelImageClick = (e, item) => {
    e.preventDefault();
    navigate('/user/gallerycomment', {
        state: item,
      })
  };

  useEffect(() => {
    getGallery();
  }, []);

  return (
    <div className="main-container">
      <div className="flex flex-col justify-center items-center">
        <div className="mt-3 w-full max-w-[400px]"></div>
        <div className="w-full flex flex-col justify-center items-center mt-custom-15">
          <div className="text-custom">
            <span>Gallery</span>
          </div>
        </div>
        <div className="w-full mx-auto flex flex-col justify-center items-center mt-3">
          <div className="grid grid-cols-3 gap-0 overflow-y-auto">
            <div className="w-max-121 hover: border-2 hover:border-blue-500">
              {gallery.map((gal) => (
                <img
                  onClick={(e) => handelImageClick(e, gal)}
                  key={gal._id}
                  className="w-full h-full"
                  src={
                    import.meta.env.VITE_APP_API_USERGALLERY_IMAGE_URL +
                    `/${gal.image}`
                  }
                  alt="Gallery Images"
                />
              ))}
            </div>
          </div>
        </div>
        <div className="mt-custom-34 w-full flex justify-center items-center">
          <button>
            <img src={"/images/GalleryDownIcon.png"} alt="Gallery Down" />
          </button>
        </div>
        {/* <div className="w-full">
            <div className="flex justify-start items-center">
                <button>
                    <img src={process.env.PUBLIC_URL + "/images/backBtn.png"} alt="Back Button" />
                </button>
            </div>
        </div> */}
      </div>
    </div>
  );
};

export default UserGallery;
