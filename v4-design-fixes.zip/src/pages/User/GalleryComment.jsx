import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";

const GalleryComment = () => {
  const { state } = useLocation();
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);
  console.log(state);
  return (
    <div>
      <p className="text-[#000] font-bold text-[24px] text-center font-roboto">
        {UserData?.name}
      </p>
      <h2 className="font-roboto text-black text-[21px] font-black py-3">
        Comments
      </h2>
      <div className="flex flex-col px-[36px] pb-10 gap-[37px]">
        {state.comments.map((comment) => (
          <div key={comment} className="flex flex-col items-start">
            <div className="flex items-center gap-2">
              <img src={""} className="w-[36px] h-[36px]" />
              <span className="text-[14px] font-roboto font-bold text-black">
                name here
              </span>
              <span className="text-[14px] font-roboto font-bold text-[#000]/[33%]">
                time
              </span>
            </div>
            <div className="min-h-[40px]">
              <span className="text-[14px] text-left block font-roboto font-bold text-black">
                comment
              </span>
            </div>
            <div className="flex gap-[27px]">
              <span className="text-[14px] font-roboto font-bold text-[#000]/[33%]">
                like count
              </span>
              <button className="text-[14px] font-roboto font-bold text-[#000]/[33%]">
                Reply
              </button>
              <button className="text-[14px] font-roboto font-bold text-[#000]/[33%]">
                See Translation
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GalleryComment;
