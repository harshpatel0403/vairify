import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";

const UserProfile = () => {
  return (
    <div className="main-container">
      <div className="w-full mx-auto flex flex-col justify-center items-center ">
        <div className="w-full mx-auto flex flex-row justify-between items-start mt-2">
          <div className="flex flex-col items-center justify-center">
            <div>
              <span className="text-[18px] text-[#040C50] font-extrabold">
                VAI
                <span className="text-[18px] text-[#040C50] font-semibold">
                  RIFY ID
                </span>
              </span>
            </div>
            <div>
              <span className="text-[15px] text-[#040C50] font-bold">
                658H39
              </span>
            </div>
          </div>
          <div className="w-[120px] relative">
            <div
              style={{ left: "10px", bottom: "65px" }}
              className="absolute w-full h-full"
            >
              <img src={"/images/Ellipse 121.png"} alt="Sugar" />
            </div>
            <div style={{ right: "0px", top: "25px" }} className="absolute">
              <img src={"/images/SugarIcon2.png"} alt="Sugar Icon Second" />
            </div>
          </div>
          <div>
            <div>
              <span className="text-[18px] text-[#040C50] font-bold">
                TRU
                <span className="text-[18px] text-[#040C50] font-semibold">
                  REVUⓒ
                </span>
              </span>
            </div>
            <div className="flex flex-row justify-center items-center">
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <FontAwesomeIcon
                icon={faStar}
                color="#E1AB3F"
                className="text-[10px] margin-right-5"
              />
              <span className="text-[15px] text-[#040C50] font-bold">5.0</span>
            </div>
          </div>
        </div>
        <div className="w-full mx-auto flex flex-col justify-center items-center mt-2">
          <span className="font-bold text-[24px]">Sugar</span>
        </div>
        <div className="w-full mx-auto flex flex-col justify-center items-center mt-4">
          <button className="w-[142px] h-[31px] bg-gradient-to-b from-[#FFFFFF] to-[#0C8A02] px-2 rounded-[20px]">
            <div className="flex flex-row justify-center items-center">
              <span className="mr-2 font-bold text-[16px] flex items-center justify-center">
                Request
              </span>
              <div className="w-[62px] h-[21px] flex items-center justify-center">
                <img
                  src={"/images/VairipayRequestSecond.png"}
                  alt="Vairify Request"
                />
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
