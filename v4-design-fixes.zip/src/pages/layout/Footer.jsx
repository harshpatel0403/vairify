import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

export default function Footer({ bgColor }) {
  // State to track whether the token is available
  const AuthToken = useSelector((state)=>state?.Auth?.Auth?.data?.token)
  const [tokenAvailable, setTokenAvailable] = useState(false);
  console.log("🚀 ~ file: Footer.jsx:6 ~ Footer ~ tokenAvailable:", tokenAvailable)

  // Check for token availability when the component mounts
  useEffect(() => {
    setTokenAvailable(!!AuthToken); // Update the state based on token existence
  }, [AuthToken]);
  return (
    <div className={`bottom-group-container flex flex-row justify-around items-center
    bg-[${bgColor}]
    text-3xl text-white text-center
    fixed
    inset-x-0
    bottom-0
    m-0
    p-3`}>
      <div>
        <button disabled={!tokenAvailable}>
          <img src={"/images/BottomNav1.png"} alt="Bottom Nav 1" />
        </button>
      </div>
      <div className="relative">
        <button disabled={!tokenAvailable}>
          <img src={"/images/BottomNav2.png"} alt="Bottom Nav 2" />
        </button>
        <span
          className="absolute top-0 right-0"
          style={{
            width: "14px",
            height: "14px",
            backgroundColor: "#0247FF",
            borderRadius: "50%",
            color: "white",
            fontSize: "7px",
            fontWeight: "700",
            lineHeight: "8.79px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          12
        </span>
      </div>
      <div>
        <button disabled={!tokenAvailable}>
          <img src={"/images/BottomNav3.png"} alt="Bottom Nav 3" />
        </button>
      </div>
      <div>
        <button disabled={!tokenAvailable}>
          <img src={"/images/BottomNav4.png"} alt="Bottom Nav 4" />
        </button>
      </div>
      <div>
        <button disabled={!tokenAvailable}>
          <img src={"/images/BottomNav5.png"} alt="Bottom Nav 5" />
        </button>
      </div>
    </div>
  );
}
