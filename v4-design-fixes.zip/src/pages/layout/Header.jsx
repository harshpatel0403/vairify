/* eslint-disable react/prop-types */
import { useEffect } from "react";
import IconButton from "../../components/IconButton";
import { useLocation, useNavigate } from "react-router-dom";
import { HandleUser } from "../../redux/action/Auth";
import { useDispatch, useSelector } from "react-redux";

export default function Header({ onClick, bgColor }) {
  const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const dispatch = useDispatch()
  const location = useLocation();
  const navigate = useNavigate();
  const path = location.pathname;
  const goBack = () => {
    navigate(-1);
  };
  useEffect(() => {
    if (path.includes("/post") && UserDetails) {
      dispatch(HandleUser(UserDetails?._id))
    }
  }, [])
  return (
    <div className={`header-part w-full flex flex-col justify-center items-start px-2 left-0 fixed  bg-[${bgColor}] z-50`}>
      <div className="w-full mx-auto flex flex-row justify-between items-center">
        <div>
          {path != "/login" && (
            <IconButton
              onClick={() => goBack()}
              icon={<img src={"/images/leftVector.png"} alt="Left Icon" />}
            />
          )}
        </div>
        {path.includes("/user") !== true &&
          path.includes("/date-guard") !== true &&
          path.includes("/post") !== true && (
            <div className="flex flex-col justify-center items-center relative bottom-3">
              <div>
                <img src={"/images/varify_logo.png"} alt="Varify Logo" className="mt-5" />
              </div>
            </div>
          )}
        {
          path.includes("/post") === true &&
          <div className="flex bg-[#D5D6E0] mb-[-1px] items-center self-end px-2 rounded-t-md">
            <img src="/images/tokens.png" />
            <span className="text-[26px] font-[700] pl-1">{UserDetails?.tokens}</span>
          </div>
        }
        <div>
          <button onClick={onClick} className="p-4">
            <img src={"/images/burgerVector.png"} alt="Burger Vector Icon" />
          </button>
        </div>
      </div>
    </div>
  );
}
