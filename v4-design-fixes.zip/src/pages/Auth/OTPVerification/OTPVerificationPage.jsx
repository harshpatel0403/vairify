/* eslint-disable react/no-unescaped-entities */
import { useState } from "react";
import Button from "../../../components/Button";
import {  useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { VerifyOTP } from "../../../redux/action/Auth";
import { toast } from "react-toastify";
import Loading from "../../../components/Loading/Index";
import OtpInput from 'react-otp-input';

export default function OTPVerificationPage() {
  const dispatch = useDispatch();
  const OTPEmail = useSelector((state) => state?.Auth?.OTPEmail);
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false); // State to track loading

  const [otp, setOtp] = useState("");
  const navigate = useNavigate();

  const submitOtp = () => {
    // Validate fields
    setIsLoading(true);
    const validationErrors = {};
    if (!otp) {
      validationErrors.otp = "OTP is required";
    }
    if (Object.keys(validationErrors).length > 0) {
      setErrorMessage(validationErrors);
      setIsLoading(false);
      return; // Prevent form submission if there are errors
    }

    // Clear any previous errors
    setErrorMessage({});
    const body = {
      email: OTPEmail,
      otpCode: otp,
    };

    dispatch(VerifyOTP(body))
      .then((result) => {
        console.log("🚀 ~ file: OTPVerificationPage.jsx:42 ~ .then ~ result:", result)
        if (result?.payload?.status === 200) {
          toast("OTP verify successfully", {
            hideProgressBar: true,
            autoClose: 3000,
            type: "success",
          });
          setIsLoading(false);
          navigate("/get-vai");
        } else {
          setIsLoading(false);
          setError(true);
        }
      })
      .catch((err) => {
        setIsLoading(false);
        console.error(err, "Error");
      });
  };
  const handleOtpChange = (value) => {
    setOtp(value);
  };

  return (
    <div className="main-container flex flex-col form-field-container">
      <div className="mx-auto mt-20 py-2">
        <img src={"/images/loginAvatar.png"} alt="Login Image" />
      </div>
      <div className="flex-1 mx-auto">
        {!error ? (
          <div className="verification-result">
            <span className="text-[22.5px] font-light">
              "OTP has been sent to your register Email & Number"
            </span>
          </div>
        ) : (
          <div className="flex flex-col justify-center items-center text-red-500 verification-bad-result">
            <span className="text-[22px] font-light">
              "The Code you have entered is
            </span>
            <span className="text-[22px] font-light">incorrect</span>
            <span className="text-[22px] font-light">
              please try again or click here to"
            </span>
            <a href="#" className="text-black text-[22px] font-bold">
              resend
            </a>
          </div>
        )}
        <div className="flex flex-row justify-center items-center text-center mt-12 otp-field-collection">
          <OtpInput
            value={otp}
            onChange={handleOtpChange}
            numInputs={6}
            renderSeparator={<span> </span>}
            renderInput={(props) => <input
              {...props}
              className={`flex-1 mr-2 border-2 bg-[#d5d6e0] h-14 w-9 text-center form-control otp_input bg-transparent text-[30px] "
            type="text`}
            style={{ borderColor: errorMessage.otp ? `#ef4444` : "#0247FF" }}
            />}
          />
          {/* {[1, 2, 3, 4, 5, 6].map((index) => (
            <input
              key={index}
              className={`flex-1 mr-2 border-2 bg-[#d5d6e0] h-14 w-9 text-center form-control otp_input bg-transparent text-[30px] "
              type="text`}
              maxLength="2"
              value={otp[index - 1]}
              onChange={(e) => handleOtpChange(otp + e.target.value)}
              style={{ borderColor: errorMessage.otp ? `#ef4444` : "#0247FF" }}
            />
          ))} */}
        </div>
        {errorMessage.otp && (
          <label className="text-red-500 text-sm flex items-baseline  pt-[2px]">
            {errorMessage.otp}
          </label>
        )}
      </div>
      <div className="mt-8 mb-4">
        <Button
          className={
            "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]"
          }
          text={
            !isLoading ? (
              "Submit"
            ) : (
              <div className="flex items-center	justify-center pt-[6px]">
                <Loading />
              </div>
            )
          }
          size="45px"
          onClick={submitOtp}
        />
      </div>
    </div>
  );
}
