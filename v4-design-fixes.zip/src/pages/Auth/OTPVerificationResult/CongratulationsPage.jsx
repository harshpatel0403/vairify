import React from 'react';
import Button from '../../../components/Button';
import { useNavigate } from 'react-router-dom';

export default function CongratulationsPage() {
    const navigate = useNavigate();
    const handleSubmit = () => {
        navigate("/reset-password");
    }
    return (
        <div className="main-container flex flex-col justify-between">
                <div className="mt-7 mx-auto">
                    <div className='w-[229px] h-[229px]'><img src={"/images/congratulations.png"} alt="Congratulations" /></div>
                </div>
                <div className="flex-1 mx-auto py-2">
                    <div className="flex flex-col justify-center items-center mb-custom-19">
                        <div className='flex flex-col justify-center items-center'>
                            <h2 className="text-[27px] font-bold mr-2">Congratulations!</h2>
                            <h2 className="text-[18px] font-bold">Sugar</h2>
                        </div>
                        <span className="text-[14.4px] font-bold mb-2">Your registration was successful.</span>
                    <span className="description-congratulated text-[14.4px]">
                            You are now a founding member of the most advanced sex work community in the world. Explore all the amazing features within this incredible app. Simply check the boxes below, and we will keep you informed
                        </span>
                    </div>
                    <div className="mt-8 mb-4">
                        <label className="flex justify-start items-center text-gray-500 font-bold">
                            <input className="w-[20px] h-[20px] mr-4 bg-gray-300" type="checkbox" />
                            <span className="text-[14.4px] font-bold text-black">Yes,want to be a Final stage Beta Tester</span>
                        </label>
                    </div>
                    <div className="mb-4">
                        <label className="flex justify-start items-center text-gray-500 font-bold">
                            <input className="w-[20px] h-[20px] mr-4 bg-gray-300" type="checkbox" />
                            <span className="text-[14.4px] font-bold text-black">Notify me when the app is released</span>
                        </label>
                    </div>
                </div>
                <div className="mb-6">
                <Button className="flex items-center justify-center font-bold bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]" size="45px" text="Explore" onClick={() => handleSubmit()} />
                </div>
        </div>
    );
}