/* eslint-disable react/no-unescaped-entities */
import { useEffect, useState } from "react";
import UserService from "../../../services/userServices";
import { useSelector } from "react-redux";
import SetupService from "../../../services/SetupService";
import { useNavigate } from "react-router-dom";

const GoldenToken = () => {
  const navigate = useNavigate();
  const [token, setTokens] = useState(0);
  const [packages, setPackages] = useState([]);

  const userId = useSelector((state) => state?.Auth?.Auth?.data?.user?._id);

  const getTokens = () => {
    UserService.getUserTokens(userId)
      .then((res) => {
        const data = res.tokens;
        setTokens(data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getPackages = () => {
    SetupService.getGrtPackages()
      .then((res) => {
        console.log(res);
        setPackages(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handelNavigate = (e, item) => {
    e.preventDefault();
    navigate("/grt-checkout", {
      state: item,
    });
  };

  useEffect(() => {
    getTokens();
    getPackages();
  }, []);

  return (
    <div className="main-container" style={{ paddingBottom: "0px" }}>
      <div className="w-full mx-auto flex flex-col justify-center items-center pt-5">
        <div className="w-full mx-auto flex flex-row justify-center items-center">
          {/* Total tokens: {token} */}
          <div>
            <img
              src={"/images/GoldenRoseTokenLogo.png"}
              alt="Golden Rose Token Logo"
            />
          </div>
          <div>
            <img
              src={"/images/GoldenRoseTokensSafe2.png"}
              alt="Golden Rose Token Safe Logo"
            />
          </div>
        </div>
        <div className="w-[100vw] h-[21px] bg-[#01195C] pb-3"></div>
        <div className="pb-4">
        {packages.map((item) => (
         
             <div
            key={item._id}
            className="w-full mx-auto flex flex-col justify-center items-center bg-gradient-to-b from-[#0198FE] to-[#FFFFFF] rounded-[20px] py-4 mt-3"
          >
            <div className="w-full mx-auto flex flex-row justify-center items-center">
              <div className="flex flex-col justify-center items-center relative top-8">
                <img
                  src={"/images/GoldenRoseTokenCoins.png"}
                  width={200}
                  alt="Golden Rose Token Coin"
                />
              </div>
              <div className="flex flex-col justify-between items-center">
                <div className="">
                  <img
                    src={"/images/GoldenRoseTokensText.png"}
                    alt="Golden Rose Tokens Text"
                  />
                </div>
                <div className="flex flex-col justify-center items-center my-2">
                  <div className="font-bold text-[18px] leading-5">
                    <span>{item.totalTokens} GRT's</span>
                  </div>
                  <div className="font-bold text-[18px] leading-5">
                    <span>for</span>
                  </div>
                  <div className="font-bold text-[18px] leading-5">
                    <span>${item.price}</span>
                  </div>
                </div>
                <div className="w-[83px]">
                  <button
                    onClick={(e) => {
                      handelNavigate(e, item);
                    }}
                    className={
                      "w-full flex items-center justify-center bg-[#0247FF] rounded-[25px] font-bold text-[21.6px] text-white"
                    }
                  >
                    Buy
                  </button>
                </div>
              </div>
              <div className="flex flex-col justify-center items-center relative top-8 ml-4">
                <img
                  src={"/images/GoldenRoseTokenCoins.png"}
                  width={200}
                  alt="Golden Rose Token Coin"
                />
              </div>
            </div>
          </div>
         
        ))}
        </div>
      </div>
    </div>
  );
};

export default GoldenToken;
