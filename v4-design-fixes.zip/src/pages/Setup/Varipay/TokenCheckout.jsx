/* eslint-disable react/no-unescaped-entities */
import Button from "../../../components/Button";
import { useLocation, useNavigate } from "react-router-dom";

import {
  useStripe,
  useElements,
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
} from "@stripe/react-stripe-js";
import axios from "axios";
import { useState } from "react";
import InputText from "../../../components/InputText";
import Loading from "../../../components/Loading/Index";
import { useSelector } from "react-redux";
import UserService from "../../../services/userServices";

const TokenCheckout = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const strip = useStripe();
  const elements = useElements();

  const UserDetails = useSelector((states) => states?.Auth?.Auth?.data?.user);
  console.log(state);
  const [isLoading, setIsLoading] = useState(false);
  const [cardHolderName, setCardHolderName] = useState("");

  const addTokens = () => {
    let body = { tokensToAdd: state?.totalTokens };
    UserService.addUserTokens(UserDetails._id, body)
      .then((res) => {
        console.log(res);

        navigate("/grt-congratulation", {
          state: state,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    addTokens();
    // axios
    //   .post(
    //     `${import.meta.env.VITE_APP_API_BASE_URL}/create-payment-intent-customers`,
    //     null,
    //     {
    //       params: {
    //         email:UserDetails.email,
    //         name: cardHolderName,
    //         phone: "030030303033030",
    //         des:"golden token purchase",
    //         total: state?.price,
    //         currency: "PKR",

    //       },
    //     }
    //   )
    //   .then(function (response) {
    //     console.log("Res: ", response);
    //     let clientSecret = response.data.clientSecret;
    //     strip
    //       .confirmCardPayment(clientSecret, {
    //         payment_method: {
    //           card: elements.getElement(CardNumberElement),
    //         },
    //       })
    //       .then(async (res) => {
    //         console.log(res, "stripe");
    //         setIsLoading(false);
    //         navigate('/grt-congratulation')
    //       })
    //       .catch((err) => {
    //         console.warn(err);
    //         setIsLoading(false);
    //       });
    //   })
    //   .catch(function (error) {
    //     console.log("error: ", error);
    //     setIsLoading(false);
    //   });
  };

  return (
    <div className="main-container bg-[#E1AB3F] h-full">
      <div className="max-w-[390px] mx-auto">
        <div className="pt-4">
          <div
            key={state?._id}
            className="w-full mx-auto flex flex-col justify-center items-center bg-gradient-to-b from-[#0198FE] to-[#FFFFFF] rounded-[20px] py-4 gt-token-card"
          >
            <div className="w-full mx-auto flex flex-row justify-center items-center">
              <div className="flex flex-col justify-center items-center relative top-8">
                <img
                  src={"/images/GoldenRoseTokenCoins.png"}
                  width={200}
                  alt="Golden Rose Token Coin"
                />
              </div>
              <div className="flex flex-col justify-between items-center">
                <div className="">
                  <img
                    src={"/images/GoldenRoseTokensText.png"}
                    alt="Golden Rose Tokens Text"
                  />
                </div>
                <div className="flex flex-col justify-center items-center my-2">
                  <div className="font-bold text-[18px] leading-5">
                    <span>{state?.totalTokens} GRT's</span>
                  </div>
                  <div className="font-bold text-[18px] leading-5">
                    <span>for</span>
                  </div>
                  <div className="font-bold text-[18px] leading-5">
                    <span>${state?.price}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col justify-center items-center relative top-8 ml-4">
                <img
                  src={"/images/GoldenRoseTokenCoins.png"}
                  width={200}
                  alt="Golden Rose Token Coin"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="mt-9">
          <div className="w-full flex justify-between">
            <h6 className="text-[14px] text-[#4D4D4D] font-medium">
              <strong className="font-extrabold">VAI</strong>RIPAY
            </h6>
            <h6 className="text-[14px] text-[#4D4D4D] font-medium">
              Order 0594829
            </h6>
          </div>
          <div className="w-full flex mt-2 mb-4">
            <p className="bg-transparent border-none focus:outline-none focus-within:outline-none text-[32px] font-bold leading-8 pr-12 text-left pl-0">
              {state?.price} $
            </p>
          </div>
          <InputText
            value={cardHolderName}
            onChange={(e) => setCardHolderName(e.target.value)}
            placeholder={"Card Holder Name"}
            influencer-affiliate
            className={`w-full text-[12px] text-[20px] border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-white`}
            // border={error.nameOfBusiness && `#ef4444`}
            name={"CardHolderName"}
          />
          <div className="mt-4 px-2">
            <p className="text-[#666] text-[16px] text-left mb-2 text-black">
              Pay by bank card
            </p>
            <CardNumberElement
              id="cardNumber"
              className={`w-full pt-[15px] text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-white mb-3`}
            />
            <CardExpiryElement
              id="expiry"
              className={`w-full pt-[15px] text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 px-4 h-[50px] bg-white mb-3`}
            />
            <CardCvcElement
              id="cvc"
              className={`w-[90px] pt-[15px] px-4 text-[20px] font-bold text-gray border-2 border-[#3760CB] rounded-2xl py-2 h-[50px] bg-white `}
            />
          </div>
          <div className="mt-8">
            <Button
              text={
                !isLoading ? (
                  "Checkout"
                ) : (
                  <div className="flex items-center	justify-center pt-[6px]">
                    <Loading />
                  </div>
                )
              }
              onClick={handleSubmit}
              className={
                "bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-extrabold text-[21.38px] w-[230px] rounded-lg"
              }
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TokenCheckout;
