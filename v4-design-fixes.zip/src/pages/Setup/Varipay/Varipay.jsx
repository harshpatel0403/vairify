import Button from "../../../components/Button";
import { Link } from "react-router-dom";

export default function Varipay() {
  return (
    <div className="main-container pb-2 form-field-container flex flex-col justify-around" style={{height: "100%"}}>
      <div className="flex flex-col items-center">
        <div className="flex justify-center items-center leading-[60px] mt-4 my-pay-img-box">
          <p className="text-[55px] text-[#040B47] font-bold">My</p>
          <img
            src={"/images/VairipaySearchLogo.png"}
            alt="Vairipay Search Logo"
            className="h-[55px] w-auto"
          />
        </div>
        <div className="mypay-text-part mt-3">
          <p className="text-[28px] font-bold text-center leading-[40px]">
            Set up
          </p>
        </div>
        <div className="payment-block mt-3">
        <p className="text-[22px] font-bold text-center pb-[3px]">
          Payment Apps
        </p>
        <div className="flex justify-center items-center">
          <Link to="/vairipay-search">
            <img
              src="/images/Vairipay1.png"
              alt="Hot Rod"
              // className="h-[180px] w-[200px]"
            />
          </Link>
        </div>
        </div>
        <div className="golden-block mt-4">
        <p className="text-[22px] font-bold text-center pb-[3px]">
          Golden Rose Tokens
        </p>
        <div className="flex justify-center items-center">
          <Link to="/goldentoken">
            <img
              src="/images/Vairipay2.png"
              alt="Hot Rod"
              // className="h-[180px] w-[200px]"
            />
          </Link>
        </div>
        </div>
        
       
        
        <Link to="/user/profile/request" className="w-full mt-3">
          <Button
            className={
              "flex items-center px-[10px] py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] mt-5 shadow-[1px_3px_10px_rgba(0,0,0,0.7)]"
            }
            text={"Next >"}
            size="45px"
          />
        </Link>
      </div>
    </div>
  );
}
