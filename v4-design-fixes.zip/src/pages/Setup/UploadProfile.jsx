import { useSelector } from "react-redux";
import Button from "../../components/Button";
import UserService from "../../services/userServices";
import React, { useState } from "react";

const UploadProfile = () => {
  const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  const handelUpload = () => {
    let data = new FormData();
    data.append("userId", UserDetails._id);
    data.append("image", image);
    UserService.uploadProfileImage(data)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      const imageUrl = URL.createObjectURL(file);
      setImagePreview(imageUrl);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current.click();
  };

  const fileInputRef = React.useRef();

  return (
    <div className="main-container">
      <div className="pt-6 w-full max-auto flex flex-col justify-center items-center">
        <div className="text-[27px] font-extrabold">
          <span>Upload Profile Image</span>
        </div>
        <div className="w-full flex flex-col justify-center items-center mt-5">
          <div className="w-[178px] h-[160px] flex flex-col justify-center items-center border-[#0247FF] border-2 rounded-lg">
            <div className="w-[88px] h-[74px]">
              {image ? (
                <img
                  src={imagePreview}
                  alt="Selected Image"
                  style={{ maxWidth: "100%" }}
                />
              ) : (
                <>
                  <img
                    id="imagePreview"
                    style={{ overflow: "hidden", width: "100%" }}
                    className="w-full h-full"
                    src={"/images/VectorCamera.png"}
                    alt="Vector Camera"
                  />
                </>
              )}
            </div>
          </div>
        </div>
        <div className="relative custom-select-border w-[120px] h-[34px] mt-5">
          <div>
            <button
              className="photo-upload-btn text-white text-[20px] font-extrabold"
              onClick={handleBrowseClick}
            >
              Browse
            </button>
            <input
              type="file"
              ref={fileInputRef}
              style={{ display: "none" }}
              onChange={handleFileInputChange}
            />
          </div>
        </div>
      </div>
      <div className="mt-custom-34 w-full flex flex-row justify-between items-center">
        <Button onClick={handelUpload}
          text="Upload"
          className="custom-btn-bg text-[#01195C] text-[26px]"
        />
      </div>
    </div>
  );
};

export default UploadProfile;
