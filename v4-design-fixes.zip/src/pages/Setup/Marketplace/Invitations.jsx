import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import Button from "../../../components/Button";
import { useDispatch, useSelector } from "react-redux";
import {
  HandleDeleteInvitation,
  HandleGetMarketPlace,
} from "../../../redux/action/MarketplaceSearch";
import moment from "moment";
import { toast } from "react-toastify";
import Loading from "../../../components/Loading/Index";
import { useNavigate } from "react-router-dom";

const Invitations = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const marketplacedata = useSelector(
    (state) => state?.Market?.marketplacedata
  );
  const [isLoading, setIsLoading] = useState(false); // State to track loading
  const [open, setopen] = useState(false);
  const [inquiryData, setInquiryData] = useState({});
  const closeopen = () => {
    setopen(false);
  };

  useEffect(() => {
    dispatch(HandleGetMarketPlace(UserDetails?._id, "Invitation"));
  }, []);

  const deleteButton = async () => {
    setIsLoading(true);
    await dispatch(HandleDeleteInvitation(inquiryData?._id))
      .then((result) => {
        if (result?.payload?.status === 200) {
          toast(result?.payload?.data?.message, {
            hideProgressBar: true,
            autoClose: 3000,
            type: "success",
          });
          dispatch(HandleGetMarketPlace(UserDetails?._id, "Invitation"));
          setopen(false);
          setIsLoading(false);
        } else {
          setIsLoading(false);
          // setError(true);
        }
      })
      .catch((err) => {
        setIsLoading(false);
        console.error(err, "Error");
      });
  };

  return (
    <div className="main-container px-0 py-4 rounded-2xl pb-[45px] bg-[#D5D6E0]">
      <div className="flex flex-col justify-between">
        <div className="mt-2 bg-[#040C50]/[26%] w-full h-[40px]">
          <h2 className="font-bold text-[26px] text-[#02227E] font-inter ">
            Invitations
          </h2>
        </div>
        {marketplacedata &&
          marketplacedata?.map((item) => {
            const startTime = moment(item?.invitationtime?.from, "hh:mm A");
            const endTime = moment(item?.invitationtime?.to, "hh:mm A");
            // Calculate the duration between the two moments
            const duration = moment.duration(endTime.diff(startTime));
            const hours = duration.hours();
            const minutes = duration.minutes();

            const activeInvitees = item?.invitee?.filter(
              (invitee) => invitee?.status === "accept"
            );
            const activeLength = activeInvitees.length;

            return (
              <div className="mt-[20px] flex flex-col gap-[26px] px-2">
                <div className="bg-[#3760CB] shadow-2xl py-[12px] rounded-[20px] border border-gray-100 h-[221px]">
                  <div className="flex gap-2 sm:gap-4 pl-[4px] pr-[19px]">
                    <div className="w-[25%] flex justify-center">
                      <img
                        src="/images/vairify-marketpalce.png"
                        className="w-[101px] h-[97px] rounded-full "
                        alt=""
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-around items-center">
                        <button>
                          <img src="/images/phone-rounded.svg" alt="" />
                        </button>
                        <button>
                          <img src="/images/massege-rounded.svg" alt="" />
                        </button>
                      </div>
                      <div className="grid gap-[10px] grid-cols-4 pt-2">
                        <span className="font-roboto text-white text-[10px] font-bold">
                          Requested <br /> Appt/time
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          Invitation
                          <br /> Posting time
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          Elapsed <br /> Time
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          Status
                        </span>
                      </div>
                      <div className="grid gap-[10px] mt-4 sm:mt-[14px] grid-cols-4">
                        <span className="font-roboto text-white text-[10px] font-bold">
                          {item?.invitationtime?.from}-
                          {item?.invitationtime?.to}
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          {moment(item.createdAt).format("DD/mm/yy")} <br />
                          {moment(item.createdAt).format("hh:mma")}
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          {hours} hr {minutes} m
                        </span>
                        <span className="font-roboto text-white text-[10px] font-bold">
                          {item.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-end justify-between px-2 sm:px-5 gap-[21px]">
                    <div className="w-[25%]">
                      <span className="block text-[12px] font-bold font-roboto text-white whitespace-nowrap">
                        Request Type
                      </span>
                      <span className="text-white font-bold  block text-[20px]">
                        {item.inquiry}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 sm:gap-[21px]">
                      <button
                        onClick={() => {
                          setInquiryData(item);
                          setopen(true);
                        }}
                        className="font-roboto font-bold text-[20px] text-white px-4 border rounded-[15px] border-[#02227E] bg-[#E04A22] w-[109px] h-[33px]"
                      >
                        Cancel
                      </button>
                      <div className="relative">
                        <button
                          className="font-roboto font-bold text-[20px] text-white px-4 border rounded-[15px] border-white bg-[#02227E] w-[90px] h-[33px]"
                          onClick={() =>
                            navigate("/active-invitation", {
                              state: item,
                            })
                          }
                        >
                          View
                        </button>
                        <p className="absolute top-[-10px] right-[0px] bg-[#FFC020] rounded-full w-fit px-[4px] leading-[20px] text-[#01195C] text-[18px] font-extrabold">
                          {activeLength}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
      </div>
      <Modal
        isOpen={open}
        onRequestClose={closeopen}
        className=" w-[360px] h-[174px] bg-[#3760CB] relative center-modal rounded-2xl px-4"
      >
        <button
          onClick={() => setopen(false)}
          className="absolute top-2 right-2"
        >
          <img
            src="/images/Mask group-close.png"
            alt=""
            width="30px"
            height="30px"
          />
        </button>
        <div className="pt-8">
          <p className="text-[24px] font-bold text-center text-[#fff] leading-8">
            Are you sure you want to cancel your invitation
          </p>
          <div className="flex justify-around items-center w-full pt-2">
            <div className="w-[40%]">
              <Button
                className={
                  "flex items-center py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-black text-[23.4px]"
                }
                text={
                  !isLoading ? (
                    "Yes"
                  ) : (
                    <div className="flex items-center justify-center pt-[6px]">
                      <Loading />
                    </div>
                  )
                }
                size="45px"
                onClick={deleteButton}
              />
            </div>
            <div className="w-[40%]">
              <Button
                className={
                  "flex items-center py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-black text-[23.4px]"
                }
                text={"No"}
                size="45px"
                onClick={() => setopen(false)}
              />
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Invitations;
