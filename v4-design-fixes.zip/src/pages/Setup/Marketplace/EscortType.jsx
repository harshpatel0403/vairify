import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Button from "../../../components/Button";
import MarketPlaceModale from "../../../components/MarketPlace/MarketPlaceModale";
import { useDispatch, useSelector } from "react-redux";
import { HandleCountry } from "../../../redux/action/Auth";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Independant = [];
const Radius = [
  "Within 15 mi (25 km)",
  "Within 30 mi (50 km)",
  "Within 50 mi (100 km)",
  "Within 120 mi (200 km)",
  "Within 200 mi (320 km)",
];
const Location = [];

const Search_location = ["Add/Search location"];

const Invitation = ["Invitation", "Search"];
const genderOptions = [
  "Man",
  "woman",
  "Trans Male (Pre-Op)",
  "Trans Female (Pre-Op)",
  "Trans Male (Post-Op)",
  "Trans Female (Post-Op)",
];
const Venue = ["Incall", "Outcall"];
const GayBathHouse = ["1", "2", "3", "4"];
const City = [];

const EscortType = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { state } = useLocation();
  console.log(
    "🚀 ~ file: EscortType.jsx:37 ~ EscortType ~ state:",
    state.EditData
  );
  const [open, setOpen] = useState(false);
  const [searchOpen, setsearchOpen] = useState(false);
  const [addSearchLocation, setAddSearchLocation] = useState(false);
  const AdvanceServices = useSelector(
    (state) => state.AdvanceServices.services
  );
  console.log(
    "🚀 ~ file: EscortType.jsx:47 ~ EscortType ~ AdvanceServices:",
    AdvanceServices
  );
  const countryData = useSelector((state) => state?.Auth?.country);
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);

  const [selectedGender, setSelectedGender] = useState("Man");
  const [selectedOrientation, setSelectedOrientation] = useState("M4W");
  const [orientationOptions, setOrientationOptions] = useState([
    "M4W",
    "M4M",
    "Bisexual",
  ]);
  const [type, setType] = useState([]);
  const [selectedType, setSelectedType] = useState("Independant");
  const [selectedVenue, setSelectedVenue] = useState("Incall");
  const [selectedTruRevuStart, setSelectedTruRevuStart] = useState({
    from: "4.5",
    to: "5.0",
  });
  const [selectedInvitation, setSelectedInvitation] = useState("Invitation");
  const [selectedGayBathHouse, setSelectedGayBathHouse] = useState("1");
  const [selectedRadius, setSelectedRadius] = useState("Radius");
  const [selectedLocation, setSelectedLocation] = useState("Current Location");
  const [selectedCity, setSelectedCity] = useState("City");
  const [favoriteStatus, setFavoriteStatus] = useState(false);
  const AllData = {
    userId: UserData?._id,
    type: selectedType,
    location: selectedLocation,
    gender: selectedGender,
    orientation: selectedOrientation,
    venue: selectedVenue,
    service: state.title,
    inquiry: selectedInvitation,

    trurevu: { from: selectedTruRevuStart.from, to: selectedTruRevuStart.to },
    radious: selectedRadius,
    city: selectedCity,
    advancedservices: state?.EditData?.advancedservices,
    favoriteStatus: favoriteStatus,
  };
  useMemo(() => {
    if (state.EditData) {
      setSelectedType(state.EditData.type);
      setSelectedLocation(state.EditData.location);
      setSelectedRadius(state.EditData.radious);
      setSelectedGender(state.EditData.gender);
      setSelectedOrientation(state.EditData.orientation);
      setSelectedVenue(state.EditData.venue);
      setSelectedTruRevuStart({
        from: state.EditData.trurevu.from,
        to: state.EditData.trurevu.to,
      });
      setSelectedInvitation(state.EditData.inquiry);
      setSelectedCity(state.EditData.city);
    }
  }, [state.EditData]);
  useMemo(() => {
    countryData &&
      countryData?.map((item) => {
        const name = item.name;
        const city = item?.cities?.map((city) => city?.name);
        Location.push(name);
        City.push(city);
        return;
      });
  }, [countryData]);

  const handleGenderChange = (event) => {
    const selectedGender = event.target.value;
    setSelectedGender(selectedGender);
    updateOrientationOptions(selectedGender);
  };

  const updateOrientationOptions = (selectedGender) => {
    if (selectedGender === "Man") {
      setOrientationOptions(["M4W", "M4M", "Bisexual"]);
      setSelectedOrientation("M4W");
    } else if (selectedGender === "woman") {
      setOrientationOptions(["W4M", "W4W", "Bisexual"]);
      setSelectedOrientation("W4M");
    } else if (selectedGender.startsWith("Trans")) {
      setOrientationOptions(["T4M", "T4W", "Bisexual"]);
      setSelectedOrientation("T4M");
    } else {
      setOrientationOptions([]);
    }
  };
  const handleOrientationChange = (event) => {
    const selectedOrientation = event.target.value;
    setSelectedOrientation(selectedOrientation);
  };
  const handleTypeonChange = (event) => {
    const type = event.target.value;
    setSelectedType(type);
  };
  const handleVenueonChange = (event) => {
    const selectedOrientation = event.target.value;
    setSelectedVenue(selectedOrientation);
  };

  useEffect(() => {
    if (state.title === "Escort") {
      setType(["Independant", "Agency"]);
    } else if (state.title === "Massage") {
      setType(["Independant", "Agency", "Massage Parlor"]);
    } else if (state.title.startsWith("Dancer")) {
      setType(["Independant", "Agency", "Strip Club"]);
    } else if (state.title.startsWith("Life")) {
      setType([
        "Swingers Lifestyle",
        "Gay Lifestyle",
        "Lesbian Lifestyle",
        "Trans Lifestyle",
      ]);
    } else if (state.title === "Adult Stores/toys") {
      setType(["Online", "Local"]);
    } else if (state.title === "Adult Forums") {
      setType(["Infiuencer", "Forums"]);
    } else {
      setType([
        "Charitable Organizations",
        "Educational Organizations",
        "Research Organizations",
        "Advocary Groups",
        "Professional Associations",
      ]);
    }
  }, [state]);

  const HandleAdvancedSearch = () => {
    navigate("/advance/search", {
      state: { state, AllData, EditData: state?.EditData },
    });
  };
  useEffect(() => {
    dispatch(HandleCountry());
  }, []);

  
  const HandleReviewButton = (event) => {
    if (event) {
      setFavoriteStatus(true);
    } else {
      setFavoriteStatus(false);
    }
    if (selectedInvitation === "Invitation") {
      setOpen(true);
    } else {
      setsearchOpen(true);
    }
  };
  const HandleSubmitButton = () => {
    setsearchOpen(true);
  };

  return (
    <div className="main-container-other flex flex-col justify-start">
      <p className="text-[30px] md:text-[33px] text-center text-[#000] font-roboto-serif font-bold py-2">
        {state.title}
      </p>
      <div className="bg-linear-gradient h-[30px] text-[24px] text-[#fff] font-bold flex justify-center items-center shadow-[0px_9px_20px_rgba(0,0,0,0.5)]">
        {" "}
        Type
      </div>
      <div className=" flex justify-center items-center">
        <div className="relative">
          <select
            className="mb-4 pr-8 appearance-none leading-normal  mt-4 px-5 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter shadow-[0px_9px_20px_rgba(0,0,0,0.5)] flex justify-center items-center"
            name="independant"
            onChange={handleTypeonChange}
            value={selectedType}
          >
            {type.map((item) => {
              return <option value={item}>{item}</option>;
            })}
          </select>
          <div className="absolute right-2 top-7">
            <svg
              className={`w-6 h-6 fill-current text-white`}
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 12l-6-6h12l-6 6z"
              />
            </svg>
          </div>
        </div>
      </div>
      <div className="bg-linear-gradient h-[30px] text-[24px] text-[#fff] font-bold flex items-center justify-center shadow-[0px_9px_20px_rgba(0,0,0,0.5)]">
        Search
      </div>
      <div className="px-5 flex flex-col items-center">
        {
          //   <p className="text-[24px] md:text-[26px] text-center text-[#000] font-roboto-serif font-bold py-3">
          //     Location
          //   </p>
        }
        <div className="flex flex-col items-start w-full max-w-[420px] mt-6 mb-1">
          <p className="text-[18px] text-[#000] text-start font-bold font-inter">
            Favorite Locations
          </p>
          <div className="flex items-center justify-center w-full gap-2 sm:gap-5">
            <div className="relative flex items-center w-fit shadow-[0px_3px_20px_rgba(0,0,0,0.5)] rounded-xl">
              <select
                className="w-fit bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl appearance-none pl-7 sm:pl-10 pr-8 py-1.5 text-[20px] text-[#fff] font-bold font-inter"
                name="location"
                onChange={(e) => setSelectedLocation(e.target.value)}
                value={selectedLocation}
              >
                <option selected disabled>
                  Current Location
                </option>
                {Location.map((item) => {
                  return <option value={item}>{item}</option>;
                })}
              </select>
              <img
                src="images/Mask-group-icons.png"
                alt=""
                className="absolute top-[3px] z-10"
              />
              <div className="absolute top-3 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>
            </div>
            <div className="relative">
              <select
                className="w-[120px] appearance-none px-2 pr-5 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter shadow-[0px_3px_20px_rgba(0,0,0,0.5)]"
                name="radius"
                onChange={(e) => setSelectedRadius(e.target.value)}
                value={selectedRadius}
              >
                <option selected disabled>
                  Radius
                </option>
                {Radius.map((item) => {
                  return <option value={item}>{item}</option>;
                })}
              </select>
                <div className="absolute top-3 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>

            </div>
          </div>
        </div>

        <div className="flex justify-center items-center w-[80%]">
          <Button
            className={
              "flex items-center mt-4 py-2 my-2 justify-center bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] text-[#fff] font-bold text-[20px] rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
            }
            text={"Add/Search Location"}
            size="40px"
            onClick={() => setAddSearchLocation(!addSearchLocation)}
          />
        </div>
        {addSearchLocation && (
          <div className="flex flex-col items-start w-full max-w-[420px] mt-6 mb-1">
            <p className="text-[18px] text-[#000] text-start font-bold font-inter">
              Search
            </p>
            <div className="flex items-center justify-center w-full gap-2 sm:gap-5">
              <select
                className="w-full px-2 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter h-[35px] shadow-[0px_3px_20px_rgba(0,0,0,0.5)]"
                name="location"
                onChange={(e) => setSelectedLocation(e.target.value)}
                value={selectedLocation}
              >
                <option selected disabled>
                  Country
                </option>
                {Location.map((item) => {
                  return <option value={item}>{item}</option>;
                })}
              </select>
              <select
                className="w-full px-2 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter h-[35px] shadow-[0px_3px_20px_rgba(0,0,0,0.5)]"
                name="city"
                onChange={(e) => setSelectedCity(e.target.value)}
                value={selectedCity}
              >
                <option selected disabled>
                  City
                </option>
                {City.map((item) => {
                  return <option value={item}>{item}</option>;
                })}
              </select>
            </div>
            <div className="w-full flex justify-center items-center">
              <div className="flex justify-center items-center">
                <Button
                  className={
                    "flex items-center pr-4 pl-4 mt-4 py-2 my-2 justify-center bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] text-[#fff] font-bold text-[24px] py-2 rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                  }
                  text={"Save location "}
                  size="40px"
                  onClick={() => setAddSearchLocation(!addSearchLocation)}
                />
              </div>
            </div>
          </div>
        )}

        {!state.status && (
          <div className="flex flex-col items-start  mt-1">
            <p className="text-[18px] text-[#000] text-start font-bold font-roboto-serif w-full">
              Specialty
            </p>
            <div className="flex justify-center items-center w-full">
              <select
                className="w-full mb-4 mt-4 mx-auto px-5 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter h-[35px] shadow-[0px_9px_20px_rgba(0,0,0,0.5)] flex justify-center items-center"
                name="Add/Search Location"
                value={selectedGayBathHouse}
                onChange={(e) => setSelectedGayBathHouse(e.target.value)}
              >
                <option selected disabled>
                  Gay Bath House
                </option>
                {GayBathHouse.map((item) => {
                  return <option value={item}>{item}</option>;
                })}
              </select>
            </div>
          </div>
        )}
        {state.status && (
          <div className="flex justify-between items-center w-full max-w-[420px] mt-4">
            <div className="flex flex-col items-start w-[45%] ">
              <p className="text-[18px] text-[#000] text-start font-bold font-roboto-serif w-full">
                Sex
              </p>
              <div className="relative flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5 shadow-[0px_9px_20px_rgba(0,0,0,0.5)] rounded-2xl">
                <select
                  className="pl-2 appearance-none sm:pl-10 pr-1.5 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] text-center to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter min-w-[fit] w-full"
                  onChange={handleGenderChange}
                  name="gender"
                  value={selectedGender}
                >
                  {genderOptions.map((gender) => (
                    <option value={gender}>{gender}</option>
                  ))}
                </select>
                <img
                  src="images/Mask-group-icons.png"
                  alt=""
                  className="absolute top-2 left-1 z-10"
                />
                  <div className="absolute top-3 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>
              </div>
            </div>
            <div className="flex flex-col items-start w-[45%]">
              <p className="text-[18px] text-[#000] text-start font-bold font-roboto-serif w-full">
                Orientation
              </p>
              <div className="relative flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5 shadow-[0px_9px_20px_rgba(0,0,0,0.5)] rounded-2xl">
                <select
                  className="pl-2 text-center appearance-none sm:pl-10 pr-1.5 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter min-w-[fit] w-full"
                  name="orientation"
                  value={selectedOrientation}
                  onChange={handleOrientationChange} // Add this line
                >
                  {orientationOptions.map((orientation) => (
                    <option key={orientation} value={orientation}>
                      {orientation}
                    </option>
                  ))}
                </select>
                <img
                  src="images/Mask-group-icons.png"
                  alt=""
                  className="absolute top-2 left-2 z-10"
                />
                <div className="absolute top-3 right-2">
                  <svg
                    className={`w-6 h-6 fill-current text-white`}
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 12l-6-6h12l-6 6z"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}
        <div
          className={`w-full max-w-[420px] flex justify-${
            state.status ? "between" : "center"
          }  items-center gap-2 sm:gap-5`}
        >
          {state.status && (
            <div className="flex justify-center items-center w-[45%] max-w-[420px] mt-5">
              <div className="flex flex-col items-start w-full">
                <p className="text-[18px] text-[#000] text-start font-bold font-roboto-serif w-full">
                  Venue
                </p>
                <div className="flex flex-wrap relative items-center justify-between w-full gap-2 sm:gap-5 shadow-[0px_9px_20px_rgba(0,0,0,0.5)] rounded-2xl">
                  <select
                    className="px-2 pl-6 appearance-none py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter min-w-[fit] w-full"
                    onChange={handleVenueonChange}
                    value={selectedVenue}
                  >
                    {Venue.map((orientation) => (
                      <option key={orientation} value={orientation}>
                        {orientation}
                      </option>
                    ))}
                  </select>
                  <div className="absolute top-3 right-2">
                  <svg
                    className={`w-6 h-6 fill-current text-white`}
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 12l-6-6h12l-6 6z"
                    />
                  </svg>
                </div>
                </div>
              </div>
            </div>
          )}
          <div className="flex flex-col items-start w-[45%] mt-5">
            <p className="text-[18px] text-[#000] text-start font-bold font-roboto-serif w-full">
              TRUREVU
            </p>
            <div className="w-full flex justify-center items-center gap-2 sm:gap-5">
              <div className="flex relative flex-wrap items-center justify-between w-full gap-2 sm:gap-5 shadow-[0px_9px_20px_rgba(0,0,0,0.5)] rounded-2xl">
                <select
                  className="px-2 appearance-none py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter min-w-[fit] w-full"
                  onChange={(e) =>
                    setSelectedTruRevuStart({
                      ...selectedTruRevuStart,
                      from: e.target.value,
                    })
                  }
                  value={selectedTruRevuStart.from}
                >
                  <option value="4.5" selecterd>
                    4.5
                  </option>
                  <option value="5.0">5.0</option>
                  <option value="5.5">5.5</option>
                </select>
                <div className="absolute top-3 right-1">
                  <svg
                    className={`w-6 h-6 fill-current text-white`}
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 12l-6-6h12l-6 6z"
                    />
                  </svg>
                </div>
              </div>
              <p className="text-[14px] font-bold text-[#01195C]">to</p>
              <div className="relative flex flex-wrap items-center justify-between w-full gap-2 sm:gap-5 shadow-[0px_9px_20px_rgba(0,0,0,0.5)] rounded-2xl">
                <select
                  className="px-2 appearance-none py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter min-w-[fit] w-full"
                  onChange={(e) =>
                    setSelectedTruRevuStart({
                      ...selectedTruRevuStart,
                      to: e.target.value,
                    })
                  }
                  value={selectedTruRevuStart.to}
                >
                  <option value="5.0" selecterd>
                    5.0
                  </option>
                  <option value="5.5">5.5</option>
                  <option value="6.0">6.0</option>
                </select>
                <div className="absolute top-3 right-1">
                  <svg
                    className={`w-6 h-6 fill-current text-white`}
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 12l-6-6h12l-6 6z"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        {state.status && (
          <div className="flex justify-center items-center w-full">
            <div className="relative mb-4 mt-7">
                <select
                  className="w-fit appearance-none mx-auto pl-5 pr-8 py-1.5 bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-xl text-[20px] text-[#fff] font-bold font-inter shadow-[0px_9px_20px_rgba(0,0,0,0.5)] flex justify-center items-center"
                  name="Invitation"
                  onChange={(e) => setSelectedInvitation(e.target.value)}
                  value={selectedInvitation}
                >
                  {Invitation.map((item) => {
                    return <option value={item}>{item}</option>;
                  })}
                </select>
                <div className="absolute top-3 right-1">
                  <svg
                    className={`w-6 h-6 fill-current text-white`}
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 12l-6-6h12l-6 6z"
                    />
                  </svg>
                </div>
            </div>
          </div>
        )}
        {state.status && (
          <>
            <div className="flex items-center justify-center w-full max-w-[420px]">
              <Button
                className={
                  "flex !h-auto items-center w-fit mt-4 py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[20px] rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                }
                text={"Review and Save To Favorites "}
                size="35px"
                onClick={() => HandleReviewButton(true)}
              />
            </div>
            <div className="flex items-center justify-center w-full max-w-[420px]">
              <Button
                className={
                  "flex !h-auto items-center w-fit mt-4 py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[20px] rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                }
                text={"Review and Submit"}
                onClick={() => HandleSubmitButton()}
                size="35px"
              />
            </div>
            <div className="flex items-center justify-center">
              <Button
                className={
                  "items-center inline-flex px-4 mt-4 w-auto py-2 my-2 justify-center bg-[#02227E] bg-gradient-to-b from-[#02227E] to-[#0247FF] text-[#fff] font-bold text-[20px] rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                }
                text={"Advanced Search"}
                size="40px"
                onClick={HandleAdvancedSearch}
              />
            </div>
          </>
        )}
        {!state.status && (
          <>
            <div className="flex mt-5 items-center justify-center w-full max-w-[420px]">
              <Button
                className={
                  "flex items-center w-fit mt-4 py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] py-2 rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                }
                text={"Search and Save To Favorites"}
                size="35px"
              />
            </div>
            <div className="flex mt-2 items-center justify-center w-full mb-3">
              <Button
                className={
                  "flex items-center mt-4 py-2 w-[50%] my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] py-2 rounded-xl shadow-[0px_9px_20px_rgba(0,0,0,0.5)]"
                }
                text={"Search"}
                size="35px"
              />
            </div>
          </>
        )}
        <MarketPlaceModale
          open={open}
          setOpen={setOpen}
          setsearchOpen={setsearchOpen}
          searchOpen={searchOpen}
          AllData={AllData}
          EditData={state?.EditData}
        />
      </div>
    </div>
  );
};

export default EscortType;
