/* eslint-disable react/no-unescaped-entities */
import Button from "../../components/Button"
import { useState } from "react";


const MutalConsent = () => {
  const [isChecked, setIsChecked] = useState(false);
  const [error, setError] = useState({});
  const HandleOnClick = () => {
    const validationErrors = {};

    if (!isChecked) {
      validationErrors.isChecked = "Terms and conditions is required";
    }

    if (Object.keys(validationErrors).length > 0) {
      setError(validationErrors);
      return; // Prevent form submission if there are errors
    }
    // Clear any previous errors
    setError({});
  };
  return (
    <div className="main-container flex flex-col justify-start">
    <div className="w-full flex items-center justify-center pt-10 pb-4">
      <h2 className="text-[18px] md:text-[22px] text-blue-700 font-extrabold whitespace-nowrap">
        Mutual Consent Contract
      </h2>
    </div>

    <div className="py-2 mb-6 mx-auto">
      <p
        className="overflow-y-auto px-2 font-black p-4 small-terms-height"
        style={{ fontSize: 10.8, textAlign: "justify", height:'22rem', backgroundColor: '#fff', borderRadius: 8 }}
      >
        Welcome to Vairify.Date
        <br />
        <br />
        These Terms and Conditions constitute a legally binding agreement made
        between you, whether personally or on behalf of an entity (“you”) and
        Vairify.Date ("Company", “we”, “us”, or “our”), concerning your access
        to and use of the Vairify.Date website as well as any other media
        form, media channel, mobile website or mobile application related,
        linked, or otherwise connected thereto (collectively, the “Site”). You
        agree that by accessing the Site, you have read, understood, and
        agreed to be bound by all of these Terms and Conditions.
        <br />
        <br />
        Supplemental terms and conditions or documents that may be posted on
        the Site from time to time are hereby expressly incorporated herein by
        reference. We will alert you about any changes by updating the “Last
        updated” date of these Terms and Conditions, and you waive any right
        to receive specific notice of each such change. It is your
        responsibility to periodically review these Terms and Conditions to
        stay informed of updates. You will be subject to and will be deemed to
        have been made aware of and to have accepted, the changes in any
        revised Terms and Conditions by your continued use of the Site after
        the date such revised Terms and Conditions are posted. These Terms and
        Conditions constitute a legally binding agreement made between you,
        whether personally or on behalf of an entity (“you”) and Vairify.Date
        ("Company", “we”, “us”, or “our”), concerning your access to and use
        of the Vairify.Date website as well as any other media form, media
        channel, mobile website or mobile application related, linked, or
        otherwise connected thereto (collectively, the “Site”). You agree that
        by accessing the Site, you have read, understood, and agreed to be
        bound by all of these Terms and Conditions. Supplemental terms and
        conditions or documents that may be posted on the Site from time to
        time are hereby expressly incorporated herein by reference. We reserve
        the right, in our sole discretion, to make changes or modifications to
        these Terms and Conditions at any time and for any reason. We will
        alert you about any changes by updating the “Last updated” date of
        these Terms and Conditions, and you waive any right to receive
        specific notice of each such change. It is your responsibility to
        periodically review these Terms and Conditions to stay informed of
        updates. You will be subject to and will be deemed to have been made
        aware of and to have accepted, the changes in any revised Terms and
        Conditions by your continued use of the Site after the date such
        revised Terms and Conditions are posted. The information provided on
        the Site is not intended for distribution to or use by any person or
        entity in any y jurisdiction
      </p>
    </div>
    <div className="pb-2 mx-auto">
      <div className="flex items-center justify-center mb-4">
        <input
          type="checkbox"
          className="form-checkbox text-indigo-600 h-[30px] w-[30px] focus:outline-none"
          onChange={(e) => setIsChecked(e.target.checked)}
          checked={isChecked}
        />
        <label className="ml-4 block font-black text-[11px] text-left">
        I agree to sign this contract electronically 
with my Vairify  # ___________
        </label>
      </div>
      {error.isChecked && (
        <label className="text-red-500 text-lg flex items-baseline pl-[12px] pt-[2px]">
          {error.isChecked}
        </label>
      )}
      <Button
        className={
          "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)] mt-7"
        }
        text={"Next >"}
        size="45px"
        onClick={HandleOnClick}
      />
    </div>
  </div>
  )
}

export default MutalConsent