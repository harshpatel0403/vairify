import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../../../services/AuthService";
import SearchBox from "../../../components/SearchBox";

const SocialSearch = () => {
  const [selectedCountry, setSelectedCountry] = useState("");
  const [countries, setCountries] = useState([]);
  const [varipays, setVaripays] = useState([]);
  const [filterdVaripays, setFilteredVaripays] = useState([]);

  const getAllData = () => {
    AuthService.getAllCountries()
      .then((res) => {
        setCountries(res);
        const uniqueVairipaysMap = new Map();

        countries.forEach((item) => {
          const vairipays = item.varipays || [];
          vairipays.forEach((vairipay) => {
            uniqueVairipaysMap.set(vairipay.name, vairipay);
          });
        });

        const uniqueVairipaysArray = Array.from(uniqueVairipaysMap.values());
        setVaripays(uniqueVairipaysArray);
        setFilteredVaripays(uniqueVairipaysArray);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getAllData();
  }, []);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    navigate("/add-social", {
      state: event,
    });
  };

  const handleSearch = (searchTerm) => {
    const filtered = varipays.filter((varipay) =>
      varipay.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredVaripays(filtered);
  };

  const handleSelectChange = (event) => {
    const selectedCountry = event.target.value;
    setSelectedCountry(selectedCountry);

    if (selectedCountry) {
      const selectedCountryData = countries.find(
        (country) => country.name === selectedCountry
      );
      if (selectedCountryData) {
        setFilteredVaripays(selectedCountryData.varipays);
      } else {
        setFilteredVaripays(varipays);
      }
    } else {
      setFilteredVaripays(varipays);
    }
  };

  return (
    <div className="main-container form-field-container pb-0 flex flex-col justify-center pt-2">
      <div className="w-full mx-auto flex flex-col justify-center items-center pt-2">
        <div className="w-full mx-auto flex items-center justify-center">
          <img
            src={import.meta.env.BASE_URL + "images/VairipaySearchLogo.png"}
            alt="Vairipay Search Logo"
          />
        </div>
        <select
          className="w-[100%] p-2 rounded-xl my-2 font-extrabold text-[21px] text-[#6a7bb3]"
          style={{ color: 'rgba(2, 34, 126, 0.60) !important;'}}
          value={selectedCountry}
          onChange={handleSelectChange}
        >
          <option value="">Search Country (Any)</option>
          {countries.map((country) => (
            <option key={country._id} value={country.name}>
              {country.name}
            </option>
          ))}
        </select>
        <div className="input-serach-veiripay w-full">
        <SearchBox
          onSearch={handleSearch}
          placeholder="Search Social"
          className={
            "w-[100%] max-w-[297px] rounded-lg border-0 border-[#D9D9D9] text-[30px] font-extrabold text-[#02227E]"
          }
        />
        </div>
        <div className="grid grid-cols-3 gap-4 mt-5 mb-5">
          {filterdVaripays.length !== 0 &&
            filterdVaripays.map((item, index) => {
              return (
                <div
                  key={index}
                  onClick={() => handleSubmit(item)}
                  className="bg-[#3760CB] rounded-[30px] border-2 border-[#02227E] w-[98px] h-[100px] flex items-center justify-center overflow-hidden"
                >
                  <img
                    src={
                      import.meta.env.BASE_URL + `images/varipays/${item.image}`
                    }
                    alt={item.name}
                  />
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default SocialSearch;
