import { useSelector } from "react-redux";
import Button from "../../components/Button"
import React, { useState } from "react";
import UserGalleryService from "../../services/UserGalleryService";


const Gallery = () => {
    const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
    const [image, setImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);

    const handelUpload = () => {
        let data = new FormData();
        data.append("userId", UserDetails._id);
        data.append("image", image);
        UserGalleryService.uploadImages(data)
          .then((res) => {
            console.log(res);
          })
          .catch((err) => {
            console.log(err);
          });
      };
    
      const handleFileInputChange = (e) => {
        const file = e.target.files[0];
        if (file) {
          setImage(file);
          const imageUrl = URL.createObjectURL(file);
          setImagePreview(imageUrl);
        }
      };
    
      const handleBrowseClick = () => {
        fileInputRef.current.click();
      };
    
      const fileInputRef = React.useRef();


  return (
    <div className="main-container form-field-container flex flex-col justify-around">
       <div className="text-[27px] font-extrabold pt-10 pb-7"><span>Photo Gallery</span></div>
    <div className="w-full max-auto flex flex-col justify-center items-center image-upload-data">
        <div className="w-full flex flex-col justify-center items-center">
            <div className="flex flex-col justify-center items-center  w-[250px] h-[218px] image-upload-box">
            {image ? (
                <img
                  src={imagePreview}
                  alt="Selected Image"
                  style={{ }}
                />
              ) : (
                <>
                  <img
                    id="imagePreview"
                    style={{ overflow: "hidden"}}
                    className="w-[130px] h-[114px]"
                    src={"/images/VectorCamera.png"}
                    alt="Vector Camera"
                  />
                  <p className="mt-3 text-[14px] font-bold">Photos</p>
                </>
              )}
            </div>
        </div>
        <div className="custom-select-border">
            <button  onClick={handleBrowseClick} className="photo-upload-btn text-white text-[20px] font-extrabold" >
                Browse
            </button>
            <input 
                type="file"
                accept="image/png, image/jpeg, image/gif"
                name="Choose Image"
                className="image-file-input"
                id="photo-upload"
                ref={fileInputRef}
              style={{ display: "none" }}
              onChange={handleFileInputChange}
            />
        </div>

       

      
    </div>
    <div className="mt-custom-34 w-full flex flex-row justify-between items-center">
        <Button 
         className={
          "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)] mt-7"
        }
        size="45px"
        onClick={handelUpload}  text="Upload >>"  />
    </div>
</div>
  )
}

export default Gallery