import { useSelector } from "react-redux";
import Button from "../../components/Button";
import { useNavigate } from "react-router-dom";

const SetupProfile = () => {
  const navigate = useNavigate();
  const UserData = useSelector((state) => state?.Auth?.Auth?.data?.user);
  console.log("🚀 ~ file: SetupProfile.jsx:8 ~ SetupProfile ~ UserData:", UserData)

  const handleLanguage = () => {
    navigate("/language");
  };
  const handelPersonalProfile = () => {
    navigate("/personal-information");
  };

  const handecontract = () => {
    navigate("/mutalconsent");
  };

  const handelVaripays = () => {
    navigate("/setup-varipay");
  };
  const handelPhotoGallery = () => {
    navigate("/photogallery");
  };
  const handelServices = () => {
    navigate("/services");
  };
  const handelDateGiardSetup = () => {
    navigate("/dateguard-setup");
  };
  
  const handelSocial = () => {
    navigate("/search-social");
  };
  const handelSetupFacial = () => {
    navigate("/setup-facial");
  };


  return (
    <div className="main-container pt-8">
      <div className="w-full mx-auto flex flex-col justify-center items-center">
        <div className="congratulation-title">
          <span className="text-[#0636C1] text-[45px] font-bold">
            Congratulations!
          </span>
        </div>
        <div>
          <span className="text-[#0636C1] text-[25px] font-bold">
            {UserData?.name}
          </span>
        </div>
        <div>
          <span className="text-black">Your Verification was successful</span>
        </div>
      </div>
      <div className="w-full mx-auto flex flex-col justify-center items-start mb-14">
        <div className="w-full mx-auto flex flex-col justify-center items-center cong-time-setup mt-2">
          <span className="text-black text-[22px] font-bold">
            Time to set up your profile
          </span>
        </div>
        <div className="w-full mt-8">
          <Button
            onClick={handleLanguage}
            text="Language"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
            onClick={handelPersonalProfile}
            text="Personal Profile"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
           onClick={handecontract}
            text="Mutual Consent Contract"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
           onClick={handelVaripays}
            text="VAIRIPAYⓒ"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
           onClick={handelPhotoGallery}
            text="Gallery Photo"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
          onClick={handelSetupFacial}
            text="In-App Facial Recognition"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
           onClick={handelServices}
            text="Rates/Services"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
            text="Calender"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
          onClick={handelDateGiardSetup}
            text="DateGuard"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
        <div className="w-full mt-4">
          <Button
          onClick={handelSocial}
            text="Social"
            className="btn-res text-[20px] text-bold text-white bg-gradient-to-b from-[#02227E] to-[#0247FF] flex flex-row justify-start items-center px-5 py-3 border-2 border-gray-300"
          />
        </div>
      </div>
    </div>
  );
};

export default SetupProfile;
