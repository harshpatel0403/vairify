import { useEffect, useState } from "react";
import Button from "../../components/Button";
import SearchBox from "../../components/SearchBox";
import { useNavigate } from "react-router-dom";
import SetupService from "../../services/SetupService";
import { useDispatch } from "react-redux";
import { HandleLanguage } from "../../redux/action/Auth";

const Language = () => {
  const [languages, setLanguages] = useState([]);
  const [filteredLanguages, setFilteredLanguages] = useState([]);
  const [selectedLang, setSelectedLang] = useState(false)
  const dispatch = useDispatch()

  const navigate = useNavigate();

  const getLanguages = () => {
    SetupService.allLanguages()
      .then((res) => {
        setLanguages(res);
        setFilteredLanguages(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getLanguages();
  }, []);

  const handleSearch = (searchTerm) => {
    const filtered = languages.filter((language) =>
      language.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredLanguages(filtered);
  };

  const HandleValue = (value, index) => {
    dispatch(HandleLanguage(value?.name))
    setSelectedLang(index)
  };
  const handleNext = () => {
    navigate("/selectcategory");
  };

  return (
    <div className="language-main-container main-container pt-5 form-field-container">
      <div className="w-full mx-auto flex flex-col justify-between items-center">
        <div>
          <span className="text-[30px] font-bold">Select Language...</span>
        </div>
        <div className="mt-3 w-full mx-auto max-w-[255px]">
          <SearchBox
            onSearch={handleSearch}
            placeholder="Search Languages"
            classname="rounded-xl pr-8"
            language="true"
          />
        </div>
        <div
          style={{ width: "100vw" }}
          className="search-language-item flex flex-col justify-start items-center mt-4 max-h-[100vh] overflow-scroll"
        >
          {filteredLanguages.map((language, i) => (
            <div
              key={i}
              className={`w-full mx-auto flex items-center justify-center cursor-pointer ${i === selectedLang ? 'bg-[#040B47] text-white' : 'hover:bg-[#D9D9D9] hover:border-[#D9D9D9]'}`}
            >
              <div
                className="w-[250px] flex items-center justify-between py-4"
                onClick={() => HandleValue(language, i)}
              >
                <div className="w-[88px] flex-1">
                  <img
                    className="shadow-2xl w-[85px]"
                    src={
                      import.meta.env.VITE_APP_API_LANGUAGES_IMAGE_URL +
                      `/${language.image}`
                    }
                    alt={language.name}
                  />
                </div>
                <span className=" text-[21px] font-medium flex-1 text-left">
                  {language.name}
                </span>
              </div>
            </div>
          ))}
{/* 


{filteredLanguages.map((language, i) => (
            <div
              key={i}
              className="w-full mx-auto flex items-center justify-center hover:bg-[#D9D9D9] hover:border-[#D9D9D9]"
            >
              <div
                className="w-[250px] flex items-center justify-between py-4"
                onClick={() => HandleValue(language)}
              >
                <div className="w-[88px]">
                  <img
                    className="w-full shadow-2xl"
                    src={
                      import.meta.env.VITE_APP_API_LANGUAGES_IMAGE_URL +
                      `/${language.image}`
                    }
                    alt={language.name}
                  />
                </div>
                <span className=" text-[21px] font-medium">
                  {language.name}
                </span>
              </div>
            </div>
          ))}



{filteredLanguages.map((language, i) => (
            <div
              key={i}
              className="w-full mx-auto flex items-center justify-center hover:bg-[#D9D9D9] hover:border-[#D9D9D9]"
            >
              <div
                className="w-[250px] flex items-center justify-between py-4"
                onClick={() => HandleValue(language)}
              >
                <div className="w-[88px]">
                  <img
                    className="w-full shadow-2xl"
                    src={
                      import.meta.env.VITE_APP_API_LANGUAGES_IMAGE_URL +
                      `/${language.image}`
                    }
                    alt={language.name}
                  />
                </div>
                <span className=" text-[21px] font-medium">
                  {language.name}
                </span>
              </div>
            </div>
          ))}



{filteredLanguages.map((language, i) => (
            <div
              key={i}
              className="w-full mx-auto flex items-center justify-center hover:bg-[#D9D9D9] hover:border-[#D9D9D9]"
            >
              <div
                className="w-[250px] flex items-center justify-between py-4"
                onClick={() => HandleValue(language)}
              >
                <div className="w-[88px]">
                  <img
                    className="w-full shadow-2xl"
                    src={
                      import.meta.env.VITE_APP_API_LANGUAGES_IMAGE_URL +
                      `/${language.image}`
                    }
                    alt={language.name}
                  />
                </div>
                <span className=" text-[21px] font-medium">
                  {language.name}
                </span>
              </div>
            </div>
          ))}

{filteredLanguages.map((language, i) => (
            <div
              key={i}
              className="w-full mx-auto flex items-center justify-center hover:bg-[#D9D9D9] hover:border-[#D9D9D9]"
            >
              <div
                className="w-[250px] flex items-center justify-between py-4"
                onClick={() => HandleValue(language)}
              >
                <div className="w-[88px]">
                  <img
                    className="w-full shadow-2xl"
                    src={
                      import.meta.env.VITE_APP_API_LANGUAGES_IMAGE_URL +
                      `/${language.image}`
                    }
                    alt={language.name}
                  />
                </div>
                <span className=" text-[21px] font-medium">
                  {language.name}
                </span>
              </div>
            </div>
          ))} */}
        </div>
        <div className="flex-1 w-full mt-10 mb-2">
          <Button
            className={
              "flex items-center justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[26px] py-2 shadow-[0px_10px_22px_rgba(0,0,0,0.5)]"
            }
            text={"Next"}
            size="45px"
            onClick={handleNext}
          />
        </div>
      </div>
    </div>
  );
};

export default Language;
