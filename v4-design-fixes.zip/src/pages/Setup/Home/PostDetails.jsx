import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'
import { faStar } from '@fortawesome/free-solid-svg-icons';
import { useLocation, useNavigate } from 'react-router';
import { useState } from 'react';
import BaseAPI from '../../../BaseAPI';
import { useSelector } from 'react-redux';

export default function PostDetails() {
    const { state } = useLocation()
    const navigate = useNavigate()
    const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);

    const likedByUser = state?.likes?.includes(UserDetails?._id);

    return (
        <div>
            <div className='main-container'>
                <div className='w-full mx-auto flex flex-col justify-center items-center'>
                    <div className='w-full mx-auto flex flex-row justify-between items-start mt-2'>
                        <div className='flex flex-col items-center justify-center'>
                            <div><span className='text-[18px] text-[#040C50] font-extrabold'>VAI<span className='text-[18px] text-[#040C50] font-semibold'>RIFY ID</span></span></div>
                            <div><span className='text-[15px] text-[#040C50] font-bold'>{state?.userId?.vaiID}</span></div>
                        </div>
                        <div className='w-[120px] relative'>
                            <div style={{ left: '10px', bottom: '65px' }} className='absolute w-full h-full'><img src={'/images/Crystal.png'} alt="Crystal" /></div>
                            <div style={{ right: '0px', top: '25px' }} className='absolute'><img src={'/images/SugarIcon2.png'} alt="Crystal Icon" /></div>
                        </div>
                        <div>
                            <div><span className='text-[18px] text-[#040C50] font-bold'>TRU<span className='text-[18px] text-[#040C50] font-semibold'>REVUⓒ</span></span></div>
                            <div className='flex flex-row justify-center items-center'><FontAwesomeIcon icon={faStar} color="#E1AB3F" className='text-[10px] margin-right-5' /><FontAwesomeIcon icon={faStar} color="#E1AB3F" className='text-[10px] margin-right-5' /><FontAwesomeIcon icon={faStar} color="#E1AB3F" className='text-[10px] margin-right-5' /><FontAwesomeIcon icon={faStar} color="#E1AB3F" className='text-[10px] margin-right-5' /><FontAwesomeIcon icon={faStar} color="#E1AB3F" className='text-[10px] margin-right-5' /><span className='text-[15px] text-[#040C50] font-bold'>5.0</span></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2 mb-5'>
                        <span className='font-bold text-[24px]'>{state?.userId?.name}</span>
                    </div>
                </div>
            </div >
            <div
                className=
                "gap-6 flex items-center mb-1 justify-between p-3 "
            >
                <div className="mt-2">
                    <button
                        className="text-[14px] border-[2px] rounded-full px-2 py-[3px] mt-0 text-white bg-[#02227E] font-roboto  border-[#0198FE]"

                    >
                        Request <span className="font-bold">VAI</span>
                        <span>RIDATE</span>
                    </button>
                </div>
                <div className='flex gap-2'>
                    <div className="flex items-center gap-1">
                        <span
                            className="text-[12px]  text-[#01195C] font-bold font-700"
                        >
                            Like
                        </span>

                        <img
                            src={likedByUser ? "/images/likes.png" : "/images/like.png"}
                            className='w-[25px]' />
                    </div>
                    <div className="flex items-center gap-1"
                        onClick={() => navigate("/user/comments", {
                            state: state
                        })}>
                        <span
                            className="text-[12px]  text-[#01195C] font-bold font-700"
                        >
                            Comment
                        </span>
                        <img
                            className='w-[25px]'
                            src="/images/Vector (1).png"
                        />
                    </div>
                </div>
            </div>
            <div className="px-px">
                <img
                    src={`${BaseAPI}/api/images/usersPost/${state?.image}`}
                    className="rounded-t-[15px] max-w-[362px] w-full mx-auto "
                />
                <div className="pt-[8px] pb-[8px] rounded-b-[15px] bg-[#3760CB69] max-w-[362px] w-full mx-auto">
                    <h2
                        className="text-[16px] font-bold text-[#02227E]  mx-auto max-w-[300px]  sm:max-w-auto text-center "
                    >
                        {state?.message}
                    </h2>
                </div>
            </div>
        </div>
    )
}
