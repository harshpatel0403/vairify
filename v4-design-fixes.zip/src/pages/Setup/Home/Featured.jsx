import React, { useEffect, useState } from "react";

import { useNavigate } from "react-router-dom";
import Carousel2 from "../../../components/Carousel-2/Carousel-2";
import { useDispatch, useSelector } from "react-redux";
import { HandleGetAllPost, HandleLikePost } from "../../../redux/action/MarketplaceSearch";
import BaseAPI from "../../../BaseAPI";

const vairipayOptions = [
  { img: "images/fe (1).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (2).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (3).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (4).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (5).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (6).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (7).png", dis: "Lexi 57I90H7" },
  { img: "images/fe (8).png", dis: "Lexi 57I90H7" },
];
const tabs = [
  { id: 1, name: "Live feed", icon: "", current: false },
  { id: 2, name: "Local Posts", icon: "", current: false },
  { id: 3, name: "FMTY", icon: "", current: true },
  {
    id: 4,
    name: " Marketplace",
    icon: "/images/marketplace-icon.png",
    current: false,
  },
];

const Build = [
  "Average",
  "Slender",
  "Athletic",
  "Very muscular",
  "Curvy",
  "Few Extra Pounds",
  "Flabby",
  "Plus Size",
];

// const ladyData = [
//   {
//     badge: "/images/Ellipse74.png",
//     name: "Crystal",
//     id: "876YT58",
//     image: "/images/image-2.png",
//   },
//   {
//     badge: "/images/Ellipse74.png",
//     name: "Crystal",
//     id: "876YT58",
//     image: "/images/image-2.png",
//   },
//   {
//     badge: "/images/Ellipse74.png",
//     name: "Crystal",
//     id: "876YT58",
//     image: "/images/image-2.png",
//   },
//   {
//     badge: "/images/Ellipse74.png",
//     name: "Crystal",
//     id: "876YT58",
//     image: "/images/image-2.png",
//   },
//   {
//     badge: "/images/Ellipse74.png",
//     name: "Crystal",
//     id: "876YT58",
//     image: "/images/image-2.png",
//   },
// ];
function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}
const Featured = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate()
  const UserDetails = useSelector((state) => state?.Auth?.Auth?.data?.user);
  const ladyData = useSelector((state) => state.Market.getAllPost);
  const [selectedTab, setSelectedTab] = useState(2);
  const [selectedGrid, setSelectedGrid] = useState(1);

  useEffect(() => {
    dispatch(HandleGetAllPost());
  }, []);

  const HandleLike = async (id) => {
    const body = {
      userId: UserDetails?._id,
    }
    await dispatch(HandleLikePost(id, body))
    dispatch(HandleGetAllPost());
  }
  return (
    <div className="main-content relative rounded-2xl overflow-hidden bg-[#D5D6E0]">
      <div className="bg-[#D5D6E0] absolute left-[50%] translate-x-[-50%] -top-[25px] w-[92px] rounded-t-[10px]">
        <span className="font-roboto text-[#02227E] font-[800] text-[16px] ">
          Featured
        </span>
      </div>
      <Carousel2 images={vairipayOptions} admin={"true"} vairipay={"false"} />
      <div className="block px-2">
        <div className="border-b border-[#02227E]/[58%]">
          <nav
            className="-mb-[3px] flex space-x-4 overflow-auto scroll-hide"
            aria-label="Tabs"
          >
            {tabs.map((tab) => (
              <button
                onClick={() => setSelectedTab(tab.id)}
                key={tab.id}
                className={classNames(
                  selectedTab === tab.id
                    ? "border-[#040C50]/[40%] "
                    : "border-transparent  hover:border-[#040C50]/[40%] ",
                  "whitespace-nowrap flex items-center judtify-center gap-px font-roboto-serif font-bold text-[#02227E] border-b-[5px]  px-1 text-[12px]"
                )}
              >
                {!!tab.icon && <img src={tab.icon} />}
                {tab.name}
              </button>
            ))}
          </nav>
        </div>
      </div>
      <div className="px-5">
        <div className="flex mt-px items-center  justify-between">
          <div className="flex overflow-scroll gap-2 pr-4">
            <div className="relative flex justify-center items-center h-[36px]">
              <select
                className="text-[#D9D9D9] max-w-[100px] appearance-none py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto font-bold text-[12px] rounded-[5px]"
                name="build"
              // onChange={HandleOption}
              >
                <option selected disabled>
                  Build
                </option>
                {Build.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <div className="absolute top-2 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>
            </div>
            <div className="relative flex justify-center items-center h-[36px]">
              <select
                className="text-[#D9D9D9] max-w-[100px] appearance-none py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto font-bold text-[12px] rounded-[5px]"
                name="build"
              // onChange={HandleOption}
              >
                <option selected disabled>
                  Build
                </option>
                {Build.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <div className="absolute top-2 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>
            </div>
            <div className="relative flex justify-center items-center h-[36px]">
              <select
                className="text-[#D9D9D9] max-w-[100px] appearance-none py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto font-bold text-[12px] rounded-[5px]"
                name="build"
              // onChange={HandleOption}
              >
                <option selected disabled>
                  Build
                </option>
                {Build.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <div className="absolute top-2 right-2">
                <svg
                  className={`w-6 h-6 fill-current text-white`}
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 12l-6-6h12l-6 6z"
                  />
                </svg>
              </div>
            </div>
            {/* <span className="text-[#D9D9D9] py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto-serif font-bold text-[12px] rounded-[5px]">
              Escort
            </span>
            <span className="text-[#D9D9D9] py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto-serif font-bold text-[12px] rounded-[5px]">
              Escort
            </span> */}
            {/* <span className="text-[#D9D9D9] py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto-serif font-bold text-[12px] rounded-[5px]">
              Escort
            </span>
            <span className="text-[#D9D9D9] py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto-serif font-bold text-[12px] rounded-[5px]">
              Escort
            </span>
            <span className="text-[#D9D9D9] py-[3px] pl-[23px] pr-[34px] block bg-[#02227E]/[58%] border-black border font-roboto-serif font-bold text-[12px] rounded-[5px]">
              Escort
            </span> */}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedGrid(1)}
              className={classNames(
                selectedGrid === 1
                  ? "border bg-[#02227E]/[32%] border-[#02227E]"
                  : "",
                "flex items-center justify-center w-[40px] h-[35px] "
              )}
            >
              <img src="/images/grid-list.svg" />
            </button>
            <button
              onClick={() => setSelectedGrid(2)}
              className={classNames(
                selectedGrid === 2
                  ? "border bg-[#02227E]/[32%] border-[#02227E]"
                  : "",
                "flex items-center justify-center w-[40px] h-[35px] "
              )}
            >
              <img src="/images/grid-2.svg" />
            </button>
          </div>
        </div>
      </div>
      <div
        className={classNames(
          selectedGrid === 2 ? "grid-cols-2" : "sm:grid-cols-2",
          " max-h-[calc(100vh_-_274px)] mb-2 overflow-auto grid mt-1.5  gap-2"
        )}
      >
        {ladyData && ladyData?.map((item, index) => {
          const likedByUser = item.likes.includes(UserDetails?._id);

          return (
            <div
              key={index}
              className={classNames(
                selectedGrid === 2 ? "rounded-[14px]" : "rounded-[30px]",
                "bg-[#040C50]/[70%] py-1.5 max-w-[368px] mx-auto "
              )}
            >
              <div
                className={classNames(
                  selectedGrid === 2 ? "px-2" : " px-5",
                  "flex items-end"
                )}

              >
                <div className="flex mb-1 flex-1  items-center gap-1">
                  <img
                    src="/images/Ellipse74.png"
                    className={classNames(
                      selectedGrid === 2
                        ? "w-[14px] h-[14px] border"
                        : "w-[26px] h-[26px] border-[2px]",
                      "rounded-full  border-white"
                    )}
                  />
                  <div>
                    <h2
                      className={classNames(
                        selectedGrid === 2 ? "text-[5.17px]" : "text-[10.8px]",
                        " text-white font-bold font-roboto"
                      )}
                    >
                      {item?.userId?.name}
                    </h2>
                    <h2
                      className={classNames(
                        selectedGrid === 2 ? "text-[5.17px]" : "text-[10.8px]",
                        " text-white font-bold font-roboto"
                      )}
                    >
                      ID# {item?.userId?.vaiID}
                    </h2>
                    <div
                      className={classNames(
                        selectedGrid === 2 ? "gap-px" : "gap-1",
                        "flex items-center"
                      )}
                    >
                      {[0, 1, 2, 3, 4].map((rating) => (
                        <img
                          src="/images/Star.svg"
                          className={classNames(
                            selectedGrid === 2
                              ? "w-[8px] h-[8px]"
                              : "w-[13px] h-[13px]"
                          )}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div
                  className={classNames(
                    selectedGrid === 2 ? "gap-1" : "gap-3",
                    "flex items-center mb-1 "
                  )}
                >
                  <div className="flex items-center gap-1"
                    onClick={() => HandleLike(item?._id)}>
                    <span
                      className={classNames(
                        selectedGrid === 2 ? "text-[6px]" : "text-[9px]",
                        " text-white font-bold font-roboto"
                      )}
                    >
                      Like
                    </span>
                    <img
                      src={likedByUser ? "/images/likes.png" : "/images/like.svg"}
                      className={classNames(
                        selectedGrid === 2 ? "w-[8px] h-[11px]" : "w-[22px]",
                      )}
                      alt={likedByUser ? "Liked" : "Like"}
                    />
                  </div>
                  <div className="flex items-center gap-1"
                    onClick={() => navigate("/user/comments", {
                      state: item
                    })}>
                    <span
                      className={classNames(
                        selectedGrid === 2 ? "text-[6px]" : "text-[9px]",
                        " text-white font-bold font-roboto"
                      )}
                    >
                      Comment
                    </span>
                    <img
                      src="/images/Vector.png"
                      className={classNames(
                        selectedGrid === 2 ? "w-[10px] h-[11px]" : ""
                      )}
                    />
                  </div>
                </div>
              </div>
              <div className="px-px"
                onClick={() => navigate("/user/details", {
                  state: item
                })}>
                <img
                  src={`${BaseAPI}/api/images/usersPost/${item?.image}`}
                  className={classNames(
                    selectedGrid === 2 ? "rounded-[12px]" : "rounded-[30px]",
                    "max-w-[362px] w-full mx-auto "
                  )}
                />
              </div>

              <div className="mt-[5px]">
                <h2
                  className={classNames(
                    selectedGrid === 2
                      ? "text-[6px] font-medium"
                      : "text-[11px] font-bold",
                    "text-white  mx-auto max-w-[300px]  sm:max-w-auto text-center "
                  )}
                >
                  {item?.message}
                </h2>
              </div>
              <div className="mt-2">
                <button
                  className={classNames(
                    selectedGrid === 2 ? "text-[6px] " : "text-[14px] ",
                    "border-[2px] rounded-full px-2 py-[3px] mt-0 text-white bg-[#02227E] font-roboto  border-[#0198FE]"
                  )}
                >
                  Request <span className="font-bold">VAI</span>
                  <span>RIDATE</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Featured;
