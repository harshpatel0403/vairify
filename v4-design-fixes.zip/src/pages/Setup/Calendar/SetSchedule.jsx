import React, { useState, useEffect } from "react";
import Modal from "react-modal";
import { useLocation, useNavigate } from "react-router-dom";
import Button from "../../../components/Button";
import InputText from "../../../components/InputText";
import SelectBox_ from "../../../components/SelectBox_";
import axios from "axios";

export default function SetSchedule() {
    const navigate = useNavigate();
    const location = useLocation();
    const [event, setEvent] = useState(
        location.state?.event
            ? location.state?.event
            : {
                title: "",
                start: new Date(),
                end: new Date(),
                status: 1,
                color: "#32ff4f",
            }
    );
    const savedSchedules = [
        "Saved schedules",
        "Schedule 1",
        "Schedule 2",
        "Schedule 3",
    ];
    const locations = ["My Locations", "Location 1", "Location 2", "Location 3"];
    const times = [
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00",
        "07:00",
        "08:00",
        "09:00",
        "10:00",
        "11:00",
        "12:00",
    ];
    const zones = ["A.M", "P.M"];
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];
    const days = [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
        "13",
        "14",
        "15",
        "16",
        "17",
        "18",
        "19",
        "20",
        "21",
        "22",
        "23",
        "24",
        "25",
        "26",
        "27",
        "28",
        "29",
        "30",
        "31",
    ];
    const [Su, setSu] = useState(true);
    const [Mo, setMo] = useState(true);
    const [Tu, setTu] = useState(false);
    const [We, setWe] = useState(true);
    const [Th, setTh] = useState(false);
    const [Fr, setFr] = useState(true);
    const [Sa, setSa] = useState(false);

    const [fromMonth, setFromMonth] = useState("");
    const [fromDay, setFromDay] = useState("");
    const [toDay, setToDay] = useState("");
    const [toMonth, setToMonth] = useState("");

    const [fromTime, setFromTime] = useState("");
    const [fromZone, setFromZone] = useState("");
    const [toTime, setToTime] = useState("");
    const [toZone, setToZone] = useState("");
    const [arrayTimes, setTimes] = useState([]);
    const [myLocation, setMyLocation] = useState("");

    const [bufferDay, setBufferDay] = useState("00");
    const [bufferHr, setBufferHr] = useState("00");
    const [bufferMin, setBufferMin] = useState("15");

    const [apptDay, setApptDay] = useState("00");
    const [apptHr, setApptHr] = useState("00");
    const [apptMin, setApptMin] = useState("15");

    const [modalIsOpen, setIsOpen] = useState(false);
    const [messageOpen, setMessageOpen] = useState(false);

    const customStyles = {
        content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            transform: "translate(-50%, -50%)",
            background: "#073FE1",
            borderRadius: "30px",
            width: "97%",
        },
    };

    useEffect(() => {
        Modal.setAppElement("#schedule_rules");
    });

    const openModal = () => {
        setIsOpen(true);
    };

    const afterOpenModal = () => { };

    const closeModal = () => {
        setIsOpen(false);
        // navigate("/set-rules")
    };

    const handleDurationDownBuffer = () => {
        const bufferMinInt = parseInt(bufferMin);
        const bufferHrInt = parseInt(bufferHr);
        const bufferDayInt = parseInt(bufferDay);
        const decreasedBufferMinInt = bufferMinInt - 15;
        if (decreasedBufferMinInt == 0 && bufferHrInt == 0 && bufferDayInt == 0) {
            setBufferMin("00");
        } else if (decreasedBufferMinInt == 0 && bufferHrInt > 0) {
            const decreasedBufferHrInt = bufferHrInt - 1;
            if (decreasedBufferHrInt > 9) {
                setBufferHr(decreasedBufferHrInt.toString());
            } else {
                setBufferHr("0" + decreasedBufferHrInt.toString());
            }
            setBufferMin("60");
        } else if (
            decreasedBufferMinInt == 0 &&
            bufferHrInt == 0 &&
            bufferDayInt > 0
        ) {
            const decreasedBufferDayInt = bufferDayInt - 1;
            if (decreasedBufferDayInt > 9) {
                setBufferDay(decreasedBufferDayInt.toString());
            } else {
                setBufferDay("0" + decreasedBufferDayInt.toString());
            }
            setBufferHr("24");
            setBufferMin("60");
        } else {
            if (decreasedBufferMinInt > 9) {
                setBufferMin(decreasedBufferMinInt.toString());
            } else {
                setBufferMin("0" + decreasedBufferMinInt.toString());
            }
        }
    };

    const handleDurationUpBuffer = () => {
        const bufferMinInt = parseInt(bufferMin);
        const bufferHrInt = parseInt(bufferHr);
        const bufferDayInt = parseInt(bufferDay);
        const increasedBufferMinInt = bufferMinInt + 15;
        if (increasedBufferMinInt >= 60 && bufferHrInt >= 24) {
            const increasedBufferDayInt = bufferDayInt + 1;

            if (increasedBufferDayInt > 9) {
                setBufferDay(increasedBufferDayInt.toString());
            } else {
                setBufferDay("0" + increasedBufferDayInt.toString());
            }
            setBufferHr("00");
            setBufferMin("00");
        } else if (increasedBufferMinInt > 60 && bufferHrInt <= 24) {
            const increasedBufferHrInt = bufferHrInt + 1;

            if (increasedBufferHrInt > 9) {
                setBufferHr(increasedBufferHrInt.toString());
            } else {
                setBufferHr("0" + increasedBufferHrInt.toString());
            }
            setBufferMin("00");
        } else {
            setBufferMin(increasedBufferMinInt.toString());
        }
    };

    const handleDurationDownBlackOut = () => {
        const apptMinInt = parseInt(apptMin);
        const apptHrInt = parseInt(apptHr);
        const apptDayInt = parseInt(apptDay);
        const decreasedApptMinInt = apptMinInt - 15;
        if (decreasedApptMinInt == 0 && apptHrInt == 0 && apptDayInt == 0) {
            setApptMin("00");
        } else if (decreasedApptMinInt == 0 && apptHrInt > 0) {
            const decreasedApptHrInt = apptHrInt - 1;
            if (decreasedApptHrInt > 9) {
                setApptHr(decreasedApptHrInt.toString());
            } else {
                setApptHr("0" + decreasedApptHrInt.toString());
            }
            setApptMin("60");
        } else if (decreasedApptMinInt == 0 && apptHrInt == 0 && apptDayInt > 0) {
            const decreasedApptDayInt = apptDayInt - 1;
            if (decreasedApptDayInt > 9) {
                setApptDay(decreasedApptDayInt.toString());
            } else {
                setApptDay("0" + decreasedApptDayInt.toString());
            }
            setApptHr("24");
            setApptMin("60");
        } else {
            if (decreasedApptMinInt > 9) {
                setApptMin(decreasedApptMinInt.toString());
            } else {
                setApptMin("0" + decreasedApptMinInt.toString());
            }
        }
    };

    const handleDurationUpBlackOut = () => {
        const apptMinInt = parseInt(apptMin);
        const apptHrInt = parseInt(apptHr);
        const apptDayInt = parseInt(apptDay);
        const increasedApptMinInt = apptMinInt + 15;
        if (increasedApptMinInt >= 60 && apptHrInt >= 24) {
            const increasedApptDayInt = apptDayInt + 1;

            if (increasedApptDayInt > 9) {
                setApptDay(increasedApptDayInt.toString());
            } else {
                setApptDay("0" + increasedApptDayInt.toString());
            }
            setApptHr("00");
            setApptMin("00");
        } else if (increasedApptMinInt > 60 && apptHrInt <= 24) {
            const increasedApptHrInt = apptHrInt + 1;

            if (increasedApptHrInt > 9) {
                setApptHr(increasedApptHrInt.toString());
            } else {
                setApptHr("0" + increasedApptHrInt.toString());
            }
            setApptMin("00");
        } else {
            setApptMin(increasedApptMinInt.toString());
        }
    };

    const handleNavigateToCalendar = () => {
        navigate("/calendar");
    };

    const handleChangeName = (e) => {
        setEvent({ ...event, title: e.target.value });
    };

    const closeMessage = () => {
        setMessageOpen(false);
    };

    const openMessage = () => {
        setMessageOpen(true);
    };

    const afterMessageOpen = () => {
        setTimeout(() => navigate("/schedule"), 2000);
    };

    const handleSave = () => {
        if (event?.id)
            axios.post("/api/calendar/update", { event }).then(() => {
                closeModal();
                openMessage();
            });
        else {
            axios.post("/api/calendar/add", { event }).then(() => {
                closeModal();
                openMessage();
            });
        }
    };

    const handleChangeFromDay = (e) => {
        setFromDay(e.target.value);
    };

    const handleChangeFromMonth = (e) => {
        setFromMonth(e.target.value);
    };

    const handleChangeToDay = (e) => {
        setToDay(e.target.value);
    };

    const handleChangeToMonth = (e) => {
        setToMonth(e.target.value);
    };

    return (
        <div id="schedule_rules" className="main-container px-5">
            <div className="w-full mx-auto flex flex-col justify-center items-center pt-4">
                <div className="w-full mx-auto flex flex-col justify-center items-center">
                    {event?.id ? (
                        <span className="font-extrabold text-[27px] text-black">
                            Set Schedule
                        </span>
                    ) : (
                        <span className="font-extrabold text-[27px] text-black">
                            Create Schedule
                        </span>
                    )}
                </div>
            </div>
            <Modal
                isOpen={messageOpen}
                onAfterOpen={afterMessageOpen}
                onRequestClose={closeMessage}
                className={
                    "bg-[#3760CB] relative top-56 mx-auto py-4 w-[360px] rounded-2xl px-4"
                }
                contentLabel="#"
            >
                <h3 className="text-[16px] text-white font-bold">
                    Schedule Saved Successfully
                </h3>
            </Modal>
            <Modal
                isOpen={modalIsOpen}
                onAfterOpen={afterOpenModal}
                onRequestClose={closeModal}
                className={
                    "bg-[#3760CB] relative top-56 mx-auto py-2 w-[360px] rounded-2xl"
                }
                contentLabel="#"
            >
                <h4 className="text-[26px] text-[#01195C] font-bold text-center">
                    Detail
                </h4>
                <div className="w-full bg-[#D9D9D936] mt-1">
                    <h4 className="text-[26px] text-[#01195C] font-bold text-center">
                        Set Schedule
                    </h4>
                </div>
                <div className="w-full mx-auto flex flex-col justify-start items-center px-5 py-3">
                    <div className="w-full mx-auto flex flex-row justify-between items-center flex-wrap">
                        <div>
                            <span className="text-[16px] font-bold text-white">Location</span>
                        </div>
                        <div>
                            <span className="text-[12px] font-bold text-white mr-2">
                                UNITED STATES
                            </span>
                        </div>
                    </div>
                    <div className="w-full mx-auto flex flex-row justify-between items-center flex-wrap mt-2">
                        <div>
                            <span className="text-[16px] font-bold text-white">Date</span>
                        </div>
                        <div>
                            <span className="text-[12px] font-bold text-white">
                                {event?.start?.toLocaleDateString("en-US")}-
                                {event?.end?.toLocaleDateString("en-US")}
                            </span>
                        </div>
                    </div>
                    <div className="w-full mx-auto flex flex-row justify-between items-center flex-wrap mt-2">
                        <div>
                            <span className="text-[16px] font-bold text-white">Days</span>
                        </div>
                        <div>
                            <span className="text-[12px] font-bold text-white">
                                M,T,W,Th,Sa
                            </span>
                        </div>
                    </div>
                    <div className="w-full mx-auto flex flex-row justify-between items-center flex-wrap mt-2">
                        <div>
                            <span className="text-[16px] font-bold text-white">Time</span>
                        </div>
                        <div>
                            <span className="text-[12px] font-bold text-white">
                                08:00 Am-01:00 Pm
                            </span>
                        </div>
                    </div>
                    <div className="w-full mx-auto flex flex-row justify-between items-center  mt-2">
                        <div className="w-full">
                            <span className="text-[16px] font-bold text-white">
                                Name Schedule
                            </span>
                        </div>
                        <div>
                            <InputText
                                size="30px"
                                onClick={handleChangeName}
                                className="rounded-sm bg-white"
                            />
                        </div>
                    </div>
                    <div className="w-full mx-auto flex flex-row justify-center gap-2 items-center mt-3">
                        <Button
                            onClick={() => closeModal()}
                            text="Close"
                            className="text-black from-0% to-65% from-[#0CA36C] to-[#08FA5A] bg-gradient-to-b text-[18px] font-bold max-w-[185px]"
                            size="40px"
                        />
                        <Button
                            onClick={() => handleSave()}
                            text="Save Schedule"
                            className="text-black from-0% to-65% from-[#0CA36C] to-[#08FA5A] bg-gradient-to-b text-[18px] font-bold max-w-[185px]"
                            size="40px"
                        />
                    </div>
                </div>
            </Modal>
            <div className="w-full mx-auto flex justify-between items-center gap-2 mt-4">
                <div className="flex flex-grow justify-center items-center gap-2">
                    <div className="relative w-1/2">
                        <SelectBox_ options={savedSchedules} className={"appearance-none w-full pl-2 pr-6 text-[12px] font-extrabold py-1 border-2 border-[#0247FF7A] focus:border-[#000] h-[35px]"} />
                        <div className="absolute top-2 right-1">
                            <svg
                                className={`w-6 h-6 fill-current text-[#0247FF]`}
                                viewBox="0 0 20 20"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M10 12l-6-6h12l-6 6z"
                                />
                            </svg>
                        </div>
                    </div>
                    <div className="relative w-1/2">
                        <SelectBox_ options={locations} className={"appearance-none w-full pl-2 pr-6 text-[12px] font-extrabold py-1 border-2 border-[#0247FF7A] focus:border-[#000] h-[35px]"} />
                        <div className="absolute top-2 right-1">
                            <svg
                                className={`w-6 h-6 fill-current text-[#0247FF]`}
                                viewBox="0 0 20 20"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M10 12l-6-6h12l-6 6z"
                                />
                            </svg>
                        </div>
                    </div>
                    {/* <SelectBox_ options={locations} className={"text-[12px] font-extrabold py-1 border-2 border-[#0247FF7A] focus:border-[#000] h-[35px]"} /> */}
                </div>
                <div className="">
                    <Button
                        text="Add"
                        bgColor=" from-[#02227E] to-[#0247FF]"
                        className="px-3 bg-gradient-to-b text-white font-extrabold rounded-xl text-[12.6px]"
                        size="36px"
                    />
                </div>
            </div>
            <div className="w-full flex flex-row justify-between items-center mt-4 pr-[52px]">
                <div className="flex gap-1 justify-between items-center w-full">
                    <div className="flex flex-row justify-center items-center w-full">
                        <div className="relative">
                            <SelectBox_
                                onChange={handleChangeFromMonth}
                                options={months}
                                className={
                                    "rounded-r-none appearance-none text-[12px] font-extrabold px-0 pl-2 max-[350px]:pl-1 sm:pl-4 pr-3 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"
                                }
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                        <div className="relative">
                            <SelectBox_
                                onChange={handleChangeFromDay}
                                options={days}
                                className={"rounded-l-none appearance-none text-[12px] font-extrabold px-0 pl-1 max-[350px]:pr-4 pr-5 py-1 border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"}
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <span className="text-[14.4px] font-bold">To</span>
                    <div className="flex flex-row justify-center items-center w-full">
                        <div className="relative">
                            <SelectBox_
                                onChange={handleChangeToMonth}
                                options={months}
                                className={
                                    "rounded-r-none appearance-none text-[12px] font-extrabold px-0 pl-2 max-[350px]:pl-1 sm:pl-4 pr-3 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"
                                }
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                        <div className="relative">
                            <SelectBox_
                                onChange={handleChangeToDay}
                                options={days}
                                className={"rounded-l-none appearance-none text-[12px] font-extrabold px-0 pl-1 max-[350px]:pr-4 pr-5 py-1 border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"}
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="">
                    {/* <Button text="Add" bgColor=' from-[#02227E] to-[#0247FF]' className="px-3 bg-gradient-to-b text-white text-[14px] font-bold rounded-xl" size="45px" /> */}
                </div>
            </div>
            <div className="w-full mx-auto flex flex-row justify-between items-center mt-4">
                <div>
                    <span className="text-[14px] font-extrabold">Days:</span>
                </div>
                <div className="w-[32px]">
                    {Su == true ? (
                        <Button
                            text="Su"
                            onClick={() => setSu(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Su"
                            onClick={() => setSu(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {Mo == true ? (
                        <Button
                            text="Mo"
                            onClick={() => setMo(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Mo"
                            onClick={() => setMo(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {Tu == true ? (
                        <Button
                            text="Tu"
                            onClick={() => setTu(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Tu"
                            onClick={() => setTu(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {We == true ? (
                        <Button
                            text="We"
                            onClick={() => setWe(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="We"
                            onClick={() => setWe(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {Th == true ? (
                        <Button
                            text="Th"
                            onClick={() => setTh(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Th"
                            onClick={() => setTh(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {Fr == true ? (
                        <Button
                            text="Fr"
                            onClick={() => setFr(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Fr"
                            onClick={() => setFr(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
                <div className="w-[32px]">
                    {Sa == true ? (
                        <Button
                            text="Sa"
                            onClick={() => setSa(false)}
                            className="border-2 border-gray-300 rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="[#0247FF]"
                        />
                    ) : (
                        <Button
                            text="Sa"
                            onClick={() => setSa(true)}
                            className="border-2 border-gray-300 w-[32px] rounded-md text-[12px] font-extrabold text-white"
                            size="32px"
                            bgColor="white"
                        />
                    )}
                </div>
            </div>
            <div className="w-full flex flex-row justify-between items-center gap-2 mt-4">
                <div className="flex gap-1 justify-between items-center w-full">
                    <div className="flex flex-row justify-center items-center w-full">
                        <div className="relative w-1/2">
                            <SelectBox_
                                onChange={(e) => {
                                    setFromTime(e.target.value);
                                }}
                                options={times}
                                className={
                                    "rounded-r-none appearance-none text-[12px] font-extrabold px-0 pl-2 max-[350px]:pl-1 sm:pl-4 pr-3 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"
                                }
                            />
                            <div className="absolute top-2 right-0">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                        <div className="relative w-1/2">
                            <SelectBox_
                                onChange={(e) => setFromZone(` ${e.target.value}`)}
                                options={zones}
                                className={"rounded-l-none text-[12px] appearance-none font-extrabold px-0 pl-1 max-[350px]:pr-4 pr-5 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"}
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <span className="text-[14.4px] font-bold">To</span>
                    <div className="flex flex-row justify-center items-center w-full">
                    <div className="relative w-1/2">
                            <SelectBox_
                                onChange={(e) => {
                                    setToTime(e.target.value);
                                }}
                                options={times}
                                className={
                                    "rounded-r-none appearance-none text-[12px] font-extrabold px-0 pl-2 max-[350px]:pl-1 sm:pl-4 pr-3 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"
                                }
                            />
                            <div className="absolute top-2 right-0">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                        <div className="relative w-1/2">
                            <SelectBox_
                                onChange={(e) => setToZone(` ${e.target.value}`)}
                                options={zones}
                                className={"rounded-l-none text-[12px] appearance-none font-extrabold px-0 pl-1 max-[350px]:pr-4 pr-5 py-1 w-full border-2 border-[#0247FF7A] focus:border-[#000] h-[36px]"}
                            />
                            <div className="absolute top-2 right-1">
                                <svg
                                    className={`w-6 h-6 fill-current text-[#0247FF]`}
                                    viewBox="0 0 20 20"
                                >
                                    <path
                                        fillRule="evenodd"
                                        d="M10 12l-6-6h12l-6 6z"
                                    />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="">
                    <Button
                        onClick={() => {
                            setTimes([
                                ...arrayTimes,
                                `${fromTime}${fromZone},${toTime}${toZone}`,
                            ]);
                        }}
                        text="Add"
                        bgColor=" from-[#02227E] to-[#0247FF]"
                        className="px-3 bg-gradient-to-b text-white text-[12.6px] font-extrabold rounded-xl"
                        size="36px"
                    />
                </div>
            </div>
            <div className="w-full py-3 mt-4 bg-[#3760CB6B]"></div>
            <div className="w-full mx-auto flex flex-col justify-center items-center mt-4">
                <div className="flex w-full items-start justify-center">
                    <div className="w-full">
                        <div className="w-full mx-auto flex justify-between items-center">
                            <div className="mr-6">
                                <span className="font-extrabold text-[18px] text-[#026EFF]">Name</span>
                            </div>
                            <div className="font-extrabold text-[18px]">
                                <span>{event?.title}</span>
                            </div>
                        </div>
                        <div className="w-full mx-auto flex justify-start items-center mt-4">
                            <div className="mr-6">
                                <span className="font-extrabold text-[18px] text-[#026EFF]">
                                    Location
                                </span>
                            </div>
                            <div className="font-extrabold text-[18px]">
                                <span>New York</span>
                            </div>
                        </div>
                        <div className="w-full mx-auto flex justify-start items-center mt-4">
                            <div className="mr-6">
                                <span className="font-extrabold text-[18px] text-[#026EFF]">Date</span>
                            </div>
                            <div className="font-extrabold text-[18px]">
                                <span>
                                    {fromDay}/{fromMonth} - {toDay}/{toMonth}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-col justify-center items-center">
                        <img
                            src={`${import.meta.env.BASE_URL}images/Calendar.png`}
                            alt=""
                            width={26}
                        />
                        <p className="text-[10px] font-extrabold whitespace-pre">Delete Schedule </p>
                    </div>
                </div>
                <div className="w-full mx-auto flex flex-col justify-between items-start mt-4">
                    <div>
                        <span className="text-[18px] font-extrabold text-[#026EFF]">Day</span>
                    </div>
                    <div className="flex justify-between w-full">
                        <div className="w-[45px] h-[45px]">
                            {Su == true ? (
                                <Button
                                    text="Su"
                                    onClick={() => setSu(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Su"
                                    onClick={() => setSu(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {Mo == true ? (
                                <Button
                                    text="Mo"
                                    onClick={() => setMo(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Mo"
                                    onClick={() => setMo(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {Tu == true ? (
                                <Button
                                    text="Tu"
                                    onClick={() => setTu(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Tu"
                                    onClick={() => setTu(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {We == true ? (
                                <Button
                                    text="We"
                                    onClick={() => setWe(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="We"
                                    onClick={() => setWe(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {Th == true ? (
                                <Button
                                    text="Th"
                                    onClick={() => setTh(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Th"
                                    onClick={() => setTh(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {Fr == true ? (
                                <Button
                                    text="Fr"
                                    onClick={() => setFr(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Fr"
                                    onClick={() => setFr(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                        <div className="w-[45px] h-[45px]">
                            {Sa == true ? (
                                <Button
                                    text="Sa"
                                    onClick={() => setSa(false)}
                                    className="border-2 border-[#CFCFCF] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="[#01195C]"
                                />
                            ) : (
                                <Button
                                    text="Sa"
                                    onClick={() => setSa(true)}
                                    className="border-2 border-[#CFCFCF] w-[45px] rounded-md text-[18px] font-extrabold text-white"
                                    size="45px"
                                    bgColor="white"
                                />
                            )}
                        </div>
                    </div>
                </div>
                <div className="w-full mx-auto flex flex-col justify-start items-start mt-4">
                    <div className="mr-6">
                        <span className="font-extrabold text-[20px] text-[#026EFF]">Time</span>
                    </div>
                    <div className="w-full flex justify-start flex-wrap gap-[9px]">
                        {arrayTimes.map((t, index) => (
                            <div key={index} className="flex flex-col gap-1">
                                <button className="w-[42px] h-[42px] bg-[#01195C] border-2 border-[#ffffff] rounded-md text-[11px] font-extrabold leading-3 text-white">
                                    {t.split(",")[0]?.split(" ")[0]}
                                    <br />
                                    {t.split(",")[0]?.split(" ")[1]}
                                </button>
                                <button className="w-[42px] h-[42px] bg-[#01195C] border-2 border-[#ffffff] rounded-md text-[11px] font-extrabold leading-3 text-white">
                                    {t.split(",")[1]?.split(" ")[0]}
                                    <br />
                                    {t.split(",")[1]?.split(" ")[1]}
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <div className="w-full mx-auto flex flex-row justify-between items-center mb-2 mt-6">
                <Button
                    onClick={() => handleNavigateToCalendar()}
                    text="Calendar"
                    className={"font-bold text-[18px] from-0% to-65% from-[#0CA36C] to-[#08FA5A] bg-gradient-to-b text-[#040C50] mr-6 rounded-2xl shadow-[1px_3px_3px_rgba(0,0,0,0.7)]"}
                    size={"40px"}
                />
                <Button
                    onClick={() => openModal()}
                    text="Review Schedule"
                    className={"font-bold text-[18px] from-0% to-65% from-[#0CA36C] to-[#08FA5A] bg-gradient-to-b text-[#040C50] rounded-2xl shadow-[1px_3px_3px_rgba(0,0,0,0.7)]"}
                    size={"40px"}
                />
            </div>
        </div>
    );
}
