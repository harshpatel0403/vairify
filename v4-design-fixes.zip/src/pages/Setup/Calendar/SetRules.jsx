import React, { useEffect, useState } from "react";
import InputText from "../../../components/InputText";
import Button from "../../../components/Button";
import { useNavigate } from "react-router-dom";
import SelectBox from "../../../components/SelectBox";
import { Select, MenuItem } from "@mui/material";
import Modal from "react-modal";
import axios from "axios";

const customStyles = {
    content: {
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        backgroundColor: "#3760CB",
        width: "90vw",
        height: "229px",
        zIndex: 20,
        borderRadius: "30px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "start",
        padding: "20px 15px",
    },
};

export default function SetRules() {
    const navigate = useNavigate();
    const [status, setStatus] = useState(1);
    const [isOpen, setIsOpen] = useState(false);
    const requestOptions = [
        "Cancellation" + "\n" + "Request",
        "Request 1",
        "Request 2",
        "Request 3",
    ];
    const [bufferDay, setBufferDay] = useState("00");
    const [bufferHr, setBufferHr] = useState("00");
    const [bufferMin, setBufferMin] = useState("15");

    const [apptDay, setApptDay] = useState("00");
    const [apptHr, setApptHr] = useState("00");
    const [apptMin, setApptMin] = useState("15");
    const [requestType, setRequestType] = useState(0);
    const [event, setEvents] = useState({});

    useEffect(() => {
        axios.get("/api/calendar/events").then((res) => {
            const _events = res.data.events.map((e) => {
                e.start = new Date(e.start);
                e.end = new Date(e.end);
                return e;
            });
            setEvents(_events);
        });
    }, []);

    const handleDurationDownBuffer = () => {
        const bufferMinInt = parseInt(bufferMin);
        const bufferHrInt = parseInt(bufferHr);
        const bufferDayInt = parseInt(bufferDay);
        const decreasedBufferMinInt = bufferMinInt - 15;
        if (decreasedBufferMinInt == 0 && bufferHrInt == 0 && bufferDayInt == 0) {
            setBufferMin("00");
        } else if (decreasedBufferMinInt == 0 && bufferHrInt > 0) {
            const decreasedBufferHrInt = bufferHrInt - 1;
            if (decreasedBufferHrInt > 9) {
                setBufferHr(decreasedBufferHrInt.toString());
            } else {
                setBufferHr("0" + decreasedBufferHrInt.toString());
            }
            setBufferMin("60");
        } else if (
            decreasedBufferMinInt == 0 &&
            bufferHrInt == 0 &&
            bufferDayInt > 0
        ) {
            const decreasedBufferDayInt = bufferDayInt - 1;
            if (decreasedBufferDayInt > 9) {
                setBufferDay(decreasedBufferDayInt.toString());
            } else {
                setBufferDay("0" + decreasedBufferDayInt.toString());
            }
            setBufferHr("24");
            setBufferMin("60");
        } else {
            if (decreasedBufferMinInt > 9) {
                setBufferMin(decreasedBufferMinInt.toString());
            } else {
                setBufferMin("0" + decreasedBufferMinInt.toString());
            }
        }
    };

    const handleDurationUpBuffer = () => {
        const bufferMinInt = parseInt(bufferMin);
        const bufferHrInt = parseInt(bufferHr);
        const bufferDayInt = parseInt(bufferDay);
        const increasedBufferMinInt = bufferMinInt + 15;
        if (increasedBufferMinInt >= 60 && bufferHrInt >= 24) {
            const increasedBufferDayInt = bufferDayInt + 1;

            if (increasedBufferDayInt > 9) {
                setBufferDay(increasedBufferDayInt.toString());
            } else {
                setBufferDay("0" + increasedBufferDayInt.toString());
            }
            setBufferHr("00");
            setBufferMin("00");
        } else if (increasedBufferMinInt > 60 && bufferHrInt <= 24) {
            const increasedBufferHrInt = bufferHrInt + 1;

            if (increasedBufferHrInt > 9) {
                setBufferHr(increasedBufferHrInt.toString());
            } else {
                setBufferHr("0" + increasedBufferHrInt.toString());
            }
            setBufferMin("00");
        } else {
            setBufferMin(increasedBufferMinInt.toString());
        }
    };

    const handleDurationDownBlackOut = () => {
        const apptMinInt = parseInt(apptMin);
        const apptHrInt = parseInt(apptHr);
        const apptDayInt = parseInt(apptDay);
        const decreasedApptMinInt = apptMinInt - 15;
        if (decreasedApptMinInt == 0 && apptHrInt == 0 && apptDayInt == 0) {
            setApptMin("00");
        } else if (decreasedApptMinInt == 0 && apptHrInt > 0) {
            const decreasedApptHrInt = apptHrInt - 1;
            if (decreasedApptHrInt > 9) {
                setApptHr(decreasedApptHrInt.toString());
            } else {
                setApptHr("0" + decreasedApptHrInt.toString());
            }
            setApptMin("60");
        } else if (decreasedApptMinInt == 0 && apptHrInt == 0 && apptDayInt > 0) {
            const decreasedApptDayInt = apptDayInt - 1;
            if (decreasedApptDayInt > 9) {
                setApptDay(decreasedApptDayInt.toString());
            } else {
                setApptDay("0" + decreasedApptDayInt.toString());
            }
            setApptHr("24");
            setApptMin("60");
        } else {
            if (decreasedApptMinInt > 9) {
                setApptMin(decreasedApptMinInt.toString());
            } else {
                setApptMin("0" + decreasedApptMinInt.toString());
            }
        }
    };

    const handleDurationUpBlackOut = () => {
        const apptMinInt = parseInt(apptMin);
        const apptHrInt = parseInt(apptHr);
        const apptDayInt = parseInt(apptDay);
        const increasedApptMinInt = apptMinInt + 15;
        if (increasedApptMinInt >= 60 && apptHrInt >= 24) {
            const increasedApptDayInt = apptDayInt + 1;

            if (increasedApptDayInt > 9) {
                setApptDay(increasedApptDayInt.toString());
            } else {
                setApptDay("0" + increasedApptDayInt.toString());
            }
            setApptHr("00");
            setApptMin("00");
        } else if (increasedApptMinInt > 60 && apptHrInt <= 24) {
            const increasedApptHrInt = apptHrInt + 1;

            if (increasedApptHrInt > 9) {
                setApptHr(increasedApptHrInt.toString());
            } else {
                setApptHr("0" + increasedApptHrInt.toString());
            }
            setApptMin("00");
        } else {
            setApptMin(increasedApptMinInt.toString());
        }
    };

    const handleNavigateToCalendar = () => {
        navigate("/calendar");
    };
    const closeModal = () => {
        setIsOpen(false);
    };

    return (
        <div className="main-container pb-2">
            <div className="w-full mx-auto flex flex-col justify-center items-center pt-5">
                <div className="w-full mx-auto flex justify-center items-center">
                    <span className="text-[27px] font-extrabold">Calendar Settings</span>
                </div>
                <div className="w-[100vw] flex justify-center items-center py-2 mt-4 bg-[#3760CB6B] h-[25px]">
                    <span className="font-extrabold text-[20px] text-[#01195C]">
                        Request Rules
                    </span>
                </div>
                <div className="w-full mx-auto flex flex-row justify-center items-center mt-4">
                    <div className="flex flex-row justify-center items-center">
                        <input
                            type="radio"
                            className="form-radio text-indigo-600 accent-[#DFFF1A] h-[18px] w-[18px]"
                            id="scheduled"
                            checked={requestType == 0}
                            onChange={() => setRequestType(0)}
                        />
                        <label
                            className="ml-2 block text-black font-extrabold text-[20px] text-center"
                            for="scheduled"
                        >
                            Scheduled
                        </label>
                    </div>
                    <div className="flex flex-row justify-center items-center mx-5">
                        <input
                            type="radio"
                            className="form-radio text-indigo-600 accent-[#DFFF1A] h-[18px] w-[18px]"
                            id="request"
                            checked={requestType == 1}
                            onChange={() => setRequestType(1)}
                        />
                        <label
                            className="ml-2 block text-black font-extrabold text-[20px] text-center"
                            for="request"
                        >
                            Request
                        </label>
                    </div>
                    <div className="flex flex-row justify-center items-center">
                        <input
                            type="radio"
                            className="form-radio text-indigo-600 accent-[#DFFF1A] h-[18px] w-[18px]"
                            id="both"
                            checked={requestType == 2}
                            onChange={() => setRequestType(2)}
                        />
                        <label
                            className="ml-2 block text-black font-extrabold text-[20px] text-center"
                            for="both"
                        >
                            Both
                        </label>
                    </div>
                </div>
                <div className="w-[100vw] flex justify-center items-center py-2 mt-4 bg-[#3760CB6B] h-[25px]">
                    <span className="font-extrabold text-[20px] text-[#01195C]">
                        Notification Rules
                    </span>
                </div>
                <div className="w-full mx-auto flex flex-row justify-around items-center mt-4 h-[45.34px]">
                    <div className="max-w-[196px] h-[45.34px]">
                        <SelectBox
                            rounded={"rounded-xl"}
                            className1={"rounded-xl py-px px-2 leading-[20px]"}
                            options={requestOptions}
                            backgroundColor={"bg-[#01195C]"}
                            textSize={"text-[18px]"}
                            textColor={"text-white"}
                            fontWeight={"font-extrabold"}
                            size="45.34px"
                            setRules="true"
                            iconColor="text-white"
                        />
                    </div>
                    <div className="ml-8 w-[100px] h-[45.34px]">
                        <Select
                            value={status}
                            rounded="rounded-xl"
                            className="rounded-[8px!important] w-[90px] h-[43px] flex justify-center items-center bg-[#01195C]"
                        >
                            <MenuItem onClick={() => setStatus(1)} value={1}>
                                <div className="mx-auto flex justify-center items-center w-[31px] h-[31px] bg-red-500"></div>
                            </MenuItem>
                            <MenuItem onClick={() => setStatus(2)} value={2}>
                                <div className="mx-auto flex justify-center items-center w-[31px] h-[31px] bg-green-500"></div>
                            </MenuItem>
                            <MenuItem onClick={() => setStatus(3)} value={3}>
                                <div className="mx-auto flex justify-center items-center w-[31px] h-[31px] bg-yellow-500"></div>
                            </MenuItem>
                        </Select>
                    </div>
                </div>
                <div className="w-full mx-auto flex flex-row justify-center items-center mt-4 gap-5">
                    <div className="flex flex-row justify-center items-center">
                        <div className="w-[18px] h-[18px] border-2 border-black bg-yellow-500"></div>
                        <div>
                            <span className="ml-2 font-extrabold text-[14.4px] text-black">
                                Pending
                            </span>
                        </div>
                    </div>
                    <div className="flex flex-row justify-center items-center">
                        <div className="w-[18px] h-[18px] border-2 border-black bg-green-500"></div>
                        <div>
                            <span className="ml-2 font-extrabold text-[14.4px] text-black">
                                Confirmed
                            </span>
                        </div>
                    </div>
                    <div className="flex flex-row justify-center items-center">
                        <div className="w-[18px] h-[18px] border-2 border-black bg-red-500"></div>
                        <div>
                            <span className="ml-2 font-extrabold text-[14.4px] text-black">
                                Cancellation <br />
                                Request
                            </span>
                        </div>
                    </div>
                </div>
                <div className="w-[100vw] flex justify-center items-center py-2 mt-4 bg-[#3760CB6B] h-[25px]">
                    <span className="font-extrabold text-[20px] text-[#01195C]">
                        Buffer Time
                    </span>
                </div>
                <div className="w-full mx-auto flex flex-row justify-around items-center mt-4">
                    <div className="flex flex-row justify-around items-end duration-row">
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Day</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {bufferDay}
                                </span>
                            </div>
                        </div>
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Hr</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {bufferHr}
                                </span>
                            </div>
                        </div>
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Min</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {bufferMin}
                                </span>
                            </div>
                        </div>
                        {parseInt(bufferDay) == 0 &&
                            parseInt(bufferHr) == 0 &&
                            parseInt(bufferMin) == 0 ? (
                            <div className="flex flex-col justify-center items-center bg-gray-300 w-[45px] h-[45px] rounded-md border-2 border-gray-200 mr-2">
                                <button
                                    disabled
                                    className="w-full h-full flex flex-col justify-center items-center"
                                >
                                    <img
                                        src={`${import.meta.env.BASE_URL}images/VectorDown.png`}
                                        alt="Time Duration Down"
                                    />
                                </button>
                            </div>
                        ) : (
                            <div className="flex flex-col justify-center items-center bg-white w-[45px] h-[45px] rounded-md border-2 border-gray-200 mr-2">
                                <button
                                    onClick={() => handleDurationDownBuffer()}
                                    className="w-full h-full flex flex-col justify-center items-center"
                                >
                                    <img
                                        src={`${import.meta.env.BASE_URL}images/VectorDown.png`}
                                        alt="Time Duration Down"
                                    />
                                </button>
                            </div>
                        )}
                        <div className="flex flex-col justify-center items-center bg-white w-[45px] h-[45px] rounded-md border-2 border-gray-200">
                            <button
                                onClick={() => handleDurationUpBuffer()}
                                className="w-full h-full flex flex-col justify-center items-center"
                            >
                                <img
                                    src={`${import.meta.env.BASE_URL}images/VectorUp.png`}
                                    alt="Time Duration Up"
                                />
                            </button>
                        </div>
                    </div>
                </div>
                <div className="w-[100vw] flex justify-center items-center py-2 mt-4 bg-[#3760CB6B] h-[25px]">
                    <span className="font-extrabold text-[20px] text-[#01195C]">
                        Black Out Period
                    </span>
                </div>
                <div className="w-full mx-auto flex flex-col justify-around items-center">
                    <div className="flex flex-row justify-around items-end mt-4">
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Day</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {apptDay}
                                </span>
                            </div>
                        </div>
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Hr</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {apptHr}
                                </span>
                            </div>
                        </div>
                        <div className="flex flex-col justify-center items-center mr-2">
                            <span className="text-[10.8px] font-extrabold pb-[4px]">Min</span>
                            <div className="bg-[#02227E] w-[45px] h-[45px] rounded-md flex flex-col justify-center items-center">
                                <span className="text-[18px] font-extrabold text-white">
                                    {apptMin}
                                </span>
                            </div>
                        </div>
                        {parseInt(apptDay) == 0 &&
                            parseInt(apptHr) == 0 &&
                            parseInt(apptMin) == 0 ? (
                            <div className="flex flex-col justify-center items-center bg-gray-300 w-[45px] h-[45px] rounded-md border-2 border-gray-200 mr-2">
                                <button
                                    disabled
                                    className="w-full h-full flex flex-col justify-center items-center"
                                >
                                    <img
                                        src={`${import.meta.env.BASE_URL}images/VectorDown.png`}
                                        alt="Time Duration Down"
                                    />
                                </button>
                            </div>
                        ) : (
                            <div className="flex flex-col justify-center items-center bg-white w-[45px] h-[45px] rounded-md border-2 border-gray-200 mr-2">
                                <button
                                    onClick={() => handleDurationDownBlackOut()}
                                    className="w-full h-full flex flex-col justify-center items-center"
                                >
                                    <img
                                        src={`${import.meta.env.BASE_URL}images/VectorDown.png`}
                                        alt="Time Duration Down"
                                    />
                                </button>
                            </div>
                        )}
                        <div className="flex flex-col justify-center items-center bg-white w-[45px] h-[45px] rounded-md border-2 border-gray-200">
                            <button
                                onClick={() => handleDurationUpBlackOut()}
                                className="w-full h-full flex flex-col justify-center items-center"
                            >
                                <img
                                    src={`${import.meta.env.BASE_URL}images/VectorUp.png`}
                                    alt="Time Duration Up"
                                />
                            </button>
                        </div>
                    </div>
                </div>
                <div className="w-full mx-auto flex flex-row justify-around items-center mt-6">
                    <div className="max-w-[124px] text-center">
                        <span className="text-[20px] font-extrabold leading-5">
                            Member Exemptions
                        </span>
                    </div>
                    <div>
                        <InputText
                            className="rounded-md h-[26px]"
                            placeholder="Enter Varify ID"
                            size="35px"
                        />
                    </div>
                </div>
                <div className="w-full mx-auto flex flex-row justify-center items-center mt-4 gap-5">
                    <Button
                        onClick={() => handleNavigateToCalendar()}
                        className={
                            "flex items-center px-[10px] py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px]"
                        }
                        text={"Calendar"}
                        size="45px"
                    />
                    <Button
                        onClick={() => setIsOpen(true)}
                        className={
                            "flex items-center px-[10px] py-2 my-2 justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px]"
                        }
                        text={"Save Rules"}
                        size="45px"
                    />
                </div>
            </div>
            <Modal
                isOpen={isOpen}
                onRequestClose={closeModal}
                style={customStyles}
                contentLabel=""
            >
                <div className="w-full mx-auto flex flex-col justify-center items-cener ">
                    <div className="font-bold text-[36px] text-white text-center leading-9">
                        Rules
                    </div>
                    <div className="font-bold text-[36px] text-white text-center leading-9">
                        Saved
                    </div>
                    <div className="font-bold text-[36px] text-white text-center leading-9">
                        successfully
                    </div>
                    <Button
                        className={"mt-6 text-[#040C50] font-[800] from-0% to-65% from-[#0CA36C] to-[#08FA5A] bg-gradient-to-b text-[24px]"}
                        onClick={() => navigate("/cal-setting")}
                        text="Calendar"
                    />
                </div>
            </Modal>
        </div>
    );
}
