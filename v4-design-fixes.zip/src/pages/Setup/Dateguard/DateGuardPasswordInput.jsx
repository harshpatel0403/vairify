import React from 'react';
import Button from '../../../components/Button';


export default function DateGuardPasswordInput() {
    return (
        <div className='main-container form-field-container'>
            <div className='w-full mx-auto flex flex-col justify-center items-center pt-2'>
                <div className='w-full mx-auto flex items-center justify-center'><span className='font-bold text-[30px] text-[#05B7FD] change-font-family'>Date Guard</span></div>
                <div className='w-full mx-auto flex items-center justify-center mt-4'><div className='w-[67px] h-[82px]'><img src={'/images/DateGuardMask.png'} alt="Date Guard Mask" /></div></div>
                <div className='w-full mx-auto flex items-center justify-center mt-9'><span className='text-center text-white font-bold text-[24px] change-font-family'>We were not able to complete your Facial ID. please enter your password</span></div>
                <div className='w-full mx-auto flex items-center justify-center mt-9 mb-24'>
                    <input className='focus:outline-none focus:shadow-none border-2 border-[white] border-dashed border-t-0 border-l-0 border-r-0 h-[78px] max-w-[317px] bg-transparent text-[35px] text-center text-white' type="text" id="password" />
                </div>
                <div className='w-full mx-auto flex flex-col justify-center items-center mt-6'>
                    <div className='w-[142px]'><Button text="Enter" className='bg-[#05B7FD] rounded-[10px] font-bold text-[30px] h-[41px] flex items-center justify-center change-font-family' size="41px" /></div>
                </div>
            </div>
        </div>
    );
}