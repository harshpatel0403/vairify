import React from 'react';
import SearchBox from '../../../components/DateguardSearchbox';

export default function InviteMemberToGroup() {
    const handleSearch = (e) => {
        console.log("Handle Search Event => ", e);
    }
    return (
        <div className='main-container form-field-container'>
            <div className='mx-auto flex flex-col justify-center items-center pt-2 form-field-container'>
                <div className='mx-auto flex items-center justify-center'><span className='font-bold text-[20px] text-white'>Invite to Group Atlantaa</span></div>
                <div className='flex items-center justify-center bg-[#6e6880] py-2 mt-4 form-field-container' style={{border:'1px solid #0247FF'}}><SearchBox onSearch={handleSearch} bgColor={'[#6e6880]'} classname={'border-none focus:outline-none focus:shadow-none font-medium text-[25px] py-0 px-0 pr-11 text-white'} placeholder="Search Contacts" /></div>
                <div className='flex flex-col justify-start items-center max-h-[450px] overflow-scroll form-field-container'>
                    
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-4 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem1.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Halley Smith</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-4 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem5.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Gloria</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-2 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem3.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Robert Fox</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-2 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem2.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Jane Cooper</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-2 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem4.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Jacob Jones</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2'>
                        <div className='w-full flex flex-row justify-between items-center py-2 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem1.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Brandie Riley</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                    <div className='w-full mx-auto flex flex-col justify-center items-center mt-2 mb-4'>
                        <div className='w-full flex flex-row justify-between items-center py-2 px-4 h-[77px] hover:bg-[#6e6880]'>
                            <div className='flex items-center justify-center'>
                                <div className='mr-4'><img src={'/images/SearchItem5.png'} alt="Search Member" /></div>
                                <div className=''><span className='font-medium text-[18px] text-white'>Crystal Galley</span></div>
                            </div>
                            <div className='bg-[#02227E] p-2 text-white rounded-[4px]'><button><span className='font-black text-[14px] text-[#fff] '>Invite</span></button></div>
                        </div>
                    </div>
                </div>               
            </div>
        </div>
    );
}