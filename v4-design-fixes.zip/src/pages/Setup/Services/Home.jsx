import React from 'react'
import Escort from './Escort'
// import Massage from './Massage'

export default function Home() {
    return (
        <div className='main-container px-0'>
            <h1 className="text-[32px] text-[#02227E] font-bold text-center font-roboto-serif py-2">
                Services
            </h1>
            <p className="bg-gradient-to-t from-[#0247FF] to-[#02227EAD] h-[27px]" />
            <Escort />
            {/* <Massage /> */}
        </div>
    )
}
