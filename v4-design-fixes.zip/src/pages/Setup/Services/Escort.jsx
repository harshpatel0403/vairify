import React, { useState } from "react";
import Button from "../../../components/Button";
import Massage from "../../../components/Services/Massage";
import ExoticDance from "../../../components/Services/ExoticDance";
import SensualServices from "../../../components/Services/SensualServices";
import { useNavigate } from "react-router";
import { useSelector } from "react-redux";

export default function Escort() {
  const service = useSelector((state) => state?.Services?.selectServices);

  const navigate = useNavigate();
  const [escort, setEscort] = useState(false);
  const [massage, setMassage] = useState(false);
  const [exotic, setExotic] = useState(false);
  const [sensual, setSensual] = useState(false);

  // Function to handle the toggle for all states
  const handleToggle = (selectedState) => {
    // setEscort(false);
    setMassage(false);
    setExotic(false);
    // setSensual(false);
    selectedState(true);
  };

  const HandleOnClick = () => {
    navigate("/service/extras", {
      state: service,
    });
  };

  return (
    <div>
      <div className="flex flex-col items-center justify-between">
        <div className="px-5 w-full mx-auto text-center">
          <div
            className="border-2 border-[#CCCCCC] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-2xl flex flex-row items-center justify-start px-6 pl-16 py-2 h-[60px] relative mt-5"
            onClick={() => {
              setEscort(!escort);
              setSensual(!sensual);
            }}
          >
            <div className="flex items-center justify-center absolute left-3">
              <button
                className={`w-[31px] h-[31px] rounded-[100%] border-2 border-[#0CA36C] ${
                  escort ? "bg-[#08FA5A]" : "bg-[#D9D9D9]"
                }`}
              ></button>
            </div>
            <div className="flex items-center w-[100px] leading-4 w-full">
              <span className="font-bold text-[26px] text-white">Escort</span>
            </div>
          </div>

          <div
            className="border-2 border-[#CCCCCC] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-2xl flex flex-row items-center justify-start px-6 pl-16 py-2 h-[60px] relative mt-5"
            onClick={() => {
              setMassage(!massage);
              setExotic(false);
              // setSensual(false);
              // setEscort(false);
            }}
          >
            <div className="flex items-center justify-center absolute left-3">
              <button
                className={`w-[31px] h-[31px] rounded-[100%] border-2 border-[#0CA36C] ${
                  massage ? "bg-[#08FA5A]" : "bg-[#D9D9D9]"
                }`}
              ></button>
            </div>
            <div className="flex items-center w-[100px] leading-4 w-full">
              <span className="font-bold text-[26px] text-white">Massage</span>
            </div>
          </div>
          {massage && <Massage />}

          <div
            className="border-2 border-[#CCCCCC] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-2xl flex flex-row items-center justify-start px-6 pl-16 py-2 h-[60px] relative mt-5"
            onClick={() => {
              setMassage(false);
              setExotic(!exotic);
              // setSensual(false);
              // setEscort(false);
            }}
          >
            <div className="flex items-center justify-center absolute left-3">
              <button
                className={`w-[31px] h-[31px] rounded-[100%] border-2 border-[#0CA36C] ${
                  exotic ? "bg-[#08FA5A]" : "bg-[#D9D9D9]"
                }`}
              ></button>
            </div>
            <div className="flex items-center w-[100px] leading-4 w-full">
              <span className="font-bold text-[26px] text-white">
                Exotic Dance
              </span>
            </div>
          </div>
          {exotic && <ExoticDance />}

          <div
            className="border-2 border-[#CCCCCC] bg-gradient-to-b from-[#02227E] to-[#0247FF] rounded-2xl flex flex-row items-center justify-start px-6 pl-16 py-2 h-[60px] relative mt-5"
            onClick={() => {
              setSensual(!sensual);
              setEscort(!escort);
            }}
          >
            <div className="flex items-center justify-center absolute left-3">
              <button
                className={`w-[31px] h-[31px] rounded-[100%] border-2 border-[#0CA36C] ${
                  sensual ? "bg-[#08FA5A]" : "bg-[#D9D9D9]"
                }`}
              ></button>
            </div>
            <div className="flex items-center w-[100px] leading-4  w-full">
              <span className="font-bold text-[26px] text-white">
                Sensual Services
              </span>
            </div>
          </div>
        </div>
        {sensual && <SensualServices />}
        <div className="flex items-center justify-center px-5">
          <div className="flex items-center justify-center w-full max-w-[420px] my-5">
            <Button
              className={
                "flex items-center w-[249px] mt-[45px] px-[40px] py-2 my-2 w-fit max-w-[270px] justify-center bg-gradient-to-b from-[#0CA36C] to-[#08FA5A] text-[#01195C] font-bold text-[24px] py-2 rounded-xl"
              }
              text={"Submit>>"}
              size="42px"
              onClick={HandleOnClick}
              disabled={service?.length <= 0}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
