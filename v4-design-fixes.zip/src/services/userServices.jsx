import requests from "./httpService";

const UserService = {
  generateToekn(body) {
    return requests.post(`/coupons/generate-coupons`, body);
  },
  getUserCoupons(id, body) {
    return requests.get(`/coupons/${id}`, body);
  },
  createPaymentContent(body) {
    return requests.get(`/create-payment-intent-customers`, body);
  },
  getUserTokens(id, body) {
    return requests.get(`/users/tokens/${id}`, body);
  },
  addUserTokens(id, body) {
    return requests.post(`/users/tokens/${id}`, body);
  },
  uploadProfileImage(body) {
    return requests.post(`/users/profileUpload`, body);
  },

};

export default UserService;
